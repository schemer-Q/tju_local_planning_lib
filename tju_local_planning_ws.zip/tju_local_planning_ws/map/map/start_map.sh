#!/bin/bash
#echo "启动 RViz2..."
#rviz2 &

#echo "启动 map_server..."
#ros2 run nav2_map_server map_server --ros-args --param yaml_filename:=map.yaml &

#sleep 2  # 等待 map_server 启动

#echo "配置 map_server..."
#ros2 lifecycle set /map_server configure
#ros2 lifecycle set /map_server activate

#echo "启动完成！"
#!/bin/bash

# 关闭旧节点（如果存在）
echo "检查并关闭旧的 /map_server 节点..."
ros2 lifecycle set /map_server shutdown 2>/dev/null || true
pkill -f "map_server" || true

# 给系统一点时间清理
sleep 1

# 启动 RViz2
echo "启动 RViz2..."
rviz2 -d /home/nvidia/tju_local_planning_ws/map/map/io.rviz &
#ros2 launch global_planning rviz.launch  &

# 启动新的 map_server
echo "启动 map_server..."
ros2 run nav2_map_server map_server --ros-args --param yaml_filename:=map.yaml &

# 等待节点完全启动
sleep 3

# 激活 map_server
echo "配置 map_server..."
ros2 lifecycle set /map_server configure
ros2 lifecycle set /map_server activate

echo "启动完成！"
