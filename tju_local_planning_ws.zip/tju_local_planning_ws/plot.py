import matplotlib.pyplot as plt
import numpy as np

# 读取txt文件，假设每行格式为: x y z
data = np.loadtxt('trajectory_points.txt')

# 拆分三列
x = data[0:1000, 0]
y = data[0:1000, 1]
yaw = data[:, 2]

# 绘制二维轨迹（x-y）
plt.figure()
#plt.scatter(x, y, marker='o')
plt.plot(x,y,'ro')
plt.xlabel('X')
plt.ylabel('Y')
plt.title('Trajectory (X-Y)')
plt.axis('equal')
plt.grid(True)
plt.show()

# 如需三维绘图，可取消下方注释
# from mpl_toolkits.mplot3d import Axes3D
# fig = plt.figure()
# ax = fig.add_subplot(111, projection='3d')
# ax.plot(x, y, z, marker='o')
# ax.set_xlabel('X')
# ax.set_ylabel('Y')
# ax.set_zlabel('Z')
# plt.title('Trajectory (3D)')
# plt.show()
