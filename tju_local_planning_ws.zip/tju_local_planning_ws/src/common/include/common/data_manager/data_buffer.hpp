#pragma once

#include <sys/types.h>
#include <cstddef>
#include <cstdint>
#include <iostream>
#include <mutex>
#include <deque>
#include <common/log/t_log.hpp>
#include <common/util/error_code.h>
#include "nav_msgs/msg/odometry.hpp"
#include "control_task_msgs/msg/task_goal_data.hpp"
#include "sensor_msgs/msg/image.hpp"
#include "sensor_msgs/msg/point_cloud2.hpp"
#include "sensing_msgs/msg/imu_data.hpp"
#include "sensing_msgs/msg/rtk_data.hpp"
#include "planning_msgs/msg/trajectory_points.hpp"
#include "chassis_msgs/msg/car_ori_interface.hpp"
#include "chassis_msgs/msg/arm_data.hpp"
#include "chassis_msgs/msg/fork_control.hpp"
#include "perception_msgs/msg/ogm_points.hpp"
#include "perception_msgs/msg/objects.hpp"
#include "perception_task_msgs/msg/target_pose.hpp"
#include "control_msgs/msg/cross_goal.hpp"
#include "control_msgs/msg/pathspeedctrl_interface.hpp"
#include "control_task_msgs/msg/task_state.hpp"
#include "planning_msgs/msg/local_trajectory_points.hpp"
#include "control_task_msgs/msg/task_type.hpp"
#include "planning_msgs/msg/trajectory_state.hpp"

namespace tju {
namespace common {

#define EPSILON 1e-6

template <typename T>
struct SensorData {
  double time;
  T data;

  explicit SensorData(const double& time = 0.0, const T& data = nullptr) : time(time), data(data) {}

  bool operator<(const SensorData& other) const {
    if (std::abs(time - other.time) < EPSILON) {
      return false;
    }
    return time < other.time;
  }
};

/**
 * @brief 数据缓存器，管理当前车型所有传感器数据和多线程缓存数据
 */
template<typename MsgType>
class DataBuffer {
public:
  DataBuffer(const uint32_t& buffer_size, const std::string& name = "", const double& max_time_delay = 0.5,
                    const uint32_t& max_dropped_times = 2) 
  : buffer_size_(buffer_size),
  max_time_delay_(max_time_delay),
  name_(name),
  max_dropped_times_(max_dropped_times){}

  /**
   * @brief 析构函数
   */
  ~DataBuffer() = default;

  // 向数据管理者中添加消息
  uint32_t push(const MsgType& msg){
    std::lock_guard<std::mutex> lock(mutex_);
    buffer_.push_back(msg);  // 将数据存储到 buffer_ 中

    if (buffer_.size() > buffer_size_) {
        buffer_.pop_front();
    }

    if (!buffer_.empty() && buffer_.front().time > msg.time) {
        NTWARNING << "Buffer: " << name_  << " roll back. New data time: " << msg.time
                           << " is earlier than old data time: " << buffer_.front().time;
        if (++dropped_times_ > max_dropped_times_) {
            buffer_.clear();
            dropped_times_ = 0;
        }
        return ErrorCode::DATA_BUFFER_ROLLBACK;
    }

    return ErrorCode::OK;
  }

  // 获取数据管理者中的所有消息
  std::deque<std::shared_ptr<MsgType>> getMessages() const {
      return buffer_;
  }

  /**
   * @brief 从缓冲区移除指定的数据
   *
   * @param data 要移除的数据
   */
  uint32_t extractByTime(const double& time, MsgType& data){
    std::lock_guard<std::mutex> lock(mutex_);

    if (buffer_.empty()) {
      NTERROR << "Buffer: " << name_ << " is empty.";
      return ErrorCode::DATA_BUFFER_EXTRACT_FAILED_FOR_EMPTY;
    }

    auto it = std::lower_bound(buffer_.begin(), buffer_.end(), MsgType(time),
    [](const MsgType& a, const MsgType& b) {
        return a.time < b.time;
    });

    if (it == buffer_.end()) {
      // 如果所有数据都早于请求时间
      auto last = buffer_.back();
      if (time - last.time > max_time_delay_) {
        NTERROR << "Buffer: " << name_ << " extract failed for timeout. Time: " << time
                << " is later than old data time: " << last.time;
        return ErrorCode::DATA_BUFFER_EXTRACT_FAILED_FOR_TIMEOUT;
      }
      data = last;
    } else if (it == buffer_.begin()) {
      // 如果所有数据都晚于请求时间
      auto first = buffer_.front();
      if (first.time - time > max_time_delay_) {
        NTERROR << "Buffer: " << name_ << " extract failed for timeout. Time: " << time
                << " is earlier than earliest data time: " << first.time;
        return ErrorCode::DATA_BUFFER_EXTRACT_FAILED_FOR_TIMEOUT;
      }
      data = first;
    } else {
        // 找到了两个相邻的数据点
        auto prev = std::prev(it);
        if (it->time - time < time - prev->time) {
            data = *it;
        } else {
            data = *prev;
        }
    }
    return ErrorCode::OK;
  }

  void clear(){
    std::lock_guard<std::mutex> lock(mutex_);
    buffer_.clear();
    dropped_times_ = 0;
  }

  void setMaxTimeDelay(const double& max_time_delay) { max_time_delay_ = max_time_delay; }

  void setMaxDroppedTimes(const uint32_t& max_dropped_times) { max_dropped_times_ = max_dropped_times; }

  void setBufferSize(const uint32_t& buffer_size) { buffer_size_ = buffer_size; }

  const std::string& name() const { return name_; }

  uint32_t size() const { return buffer_.size(); }

  /**
   * @brief 打印缓冲区中数据的起止时间和个数
   */
  void printBuffer() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (buffer_.empty()) {
      std::cout << "Buffer: " << name_ << " is empty." << std::endl;
      return;
    }
    std::cout << "Buffer: " << name_ << std::endl;
    std::cout << "Start time: " << buffer_.front().time << std::endl;
    std::cout << "End time: " << buffer_.back().time << std::endl;
    std::cout << "Size: " << buffer_.size() << std::endl;
  }

  /**
   * @brief 获取最新数据的时间
   *
   * @return double 时间
   */
  double getLatestDataTime(){
    std::lock_guard<std::mutex> lock(mutex_);
    if (buffer_.empty()) {
      NTERROR << "Buffer: " << name_ << " is empty, getLatestDataTime failed!";
      return -1.0;
    }

    return buffer_.back().time;
  }
private:

  uint32_t buffer_size_;                                ///< 缓冲区的最大容量
  std::deque<MsgType> buffer_;     ///< 容器
  double max_time_delay_;                               ///< 最大时间延迟，单位秒
  std::string name_;                                    ///< 缓冲区的名称
  std::mutex mutex_;                                    ///< 互斥锁
  uint32_t dropped_times_;                              ///< 当时间回滚时，丢弃的数据数量
  uint32_t max_dropped_times_;                          ///< 最大丢弃次数, 当丢弃次数超过该值时，清空缓冲区

};
}}

/**
 * @brief 注册传感器数据类型(将数据用传感器统一接口封装便于统一管理)
 * @tparam DataType 传感器数据类型
 * @note DataType 需要满足以下条件:
 * 1. 指针类型
 */
#define REGISTOR_SENSOR_DATA(DataName, DataType)                                          \
  struct DataName : public tju::common::SensorData<DataType> { \
    using tju::common::SensorData<DataType>::SensorData;       \
  };                                                                                      \
  typedef tju::common::DataBuffer<DataName> DataName##Buffer;  \
  typedef std::shared_ptr<DataName##Buffer> DataName##BufferPtr;

REGISTOR_SENSOR_DATA(OdometryData, nav_msgs::msg::Odometry::ConstPtr)
REGISTOR_SENSOR_DATA(GoalData, control_task_msgs::msg::TaskGoalData::ConstPtr)
REGISTOR_SENSOR_DATA(ImageData, sensor_msgs::msg::Image::ConstPtr)
REGISTOR_SENSOR_DATA(PointCloudData, sensor_msgs::msg::PointCloud2::ConstPtr)
REGISTOR_SENSOR_DATA(ImuData, sensing_msgs::msg::ImuData::ConstPtr)
REGISTOR_SENSOR_DATA(RtkData, sensing_msgs::msg::RtkData::ConstPtr)
REGISTOR_SENSOR_DATA(GlobalPathData, planning_msgs::msg::TrajectoryPoints::ConstPtr)
REGISTOR_SENSOR_DATA(CarOriData, chassis_msgs::msg::CarOriInterface::ConstPtr)
REGISTOR_SENSOR_DATA(OgmPointsData, perception_msgs::msg::OgmPoints::ConstPtr)
REGISTOR_SENSOR_DATA(ObjectsData, perception_msgs::msg::Objects::ConstPtr)
REGISTOR_SENSOR_DATA(TargetPoseData, perception_task_msgs::msg::TargetPose::ConstPtr)
REGISTOR_SENSOR_DATA(CrossGoalData, control_msgs::msg::CrossGoal::ConstPtr)
REGISTOR_SENSOR_DATA(LocalPathData, planning_msgs::msg::LocalTrajectoryPoints::ConstPtr)
REGISTOR_SENSOR_DATA(TaskTypeData, control_task_msgs::msg::TaskType::ConstPtr)
REGISTOR_SENSOR_DATA(LocalStatusData, planning_msgs::msg::TrajectoryState::ConstPtr)
REGISTOR_SENSOR_DATA(ArmOriData, chassis_msgs::msg::ArmData::ConstPtr)
REGISTOR_SENSOR_DATA(ControlData, control_msgs::msg::PathspeedctrlInterface::ConstPtr)
REGISTOR_SENSOR_DATA(ForkControlData, chassis_msgs::msg::ForkControl::ConstPtr)
REGISTOR_SENSOR_DATA(ForkTaskStateData, control_task_msgs::msg::TaskState::ConstPtr)