/**
 * @file data_manager.hpp
 * @brief 数据管理器，管理当前车型所有传感器数据
 */

#pragma once
#include <iostream>
#include <sys/types.h>
#include <yaml-cpp/yaml.h>
#include <Eigen/Geometry>
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
#include <typeindex>
#include <vector>

#include "common/log/t_log.hpp"
#include "common/util/error_code.h"
#include "common/util/util.hpp"
#include "common/data_manager/data_buffer.hpp"
#include "common/data_manager/sensor_wrapper/camera.hpp"
#include "common/data_manager/sensor_wrapper/lidar.hpp"


namespace tju {
namespace common {

enum SensorType {
  UNKNOWN,
  LIDAR,
  CAMERA,
  OTHER,
};

static std::unordered_map<std::string, SensorType> sensor_type_map = {
    {"UNKNOWN", SensorType::UNKNOWN},
    {"LIDAR", SensorType::LIDAR},
    {"CAMERA", SensorType::CAMERA},
    {"OTHER", SensorType::OTHER},
};

static SensorType stringToSensorType(const std::string& type) {
  if (sensor_type_map.find(type) == sensor_type_map.end()) {
    NTERROR << "Invalid sensor type: " << type;
    return SensorType::UNKNOWN;
  }
  return sensor_type_map[type];
}


/**
 * @brief 数据管理器，管理当前车型所有传感器数据和多线程共享数据
 */
class DataManager {
public:
  /**
   * @brief 获取数据管理器的单例实例
   * @return 数据管理器的引用
   */
  static DataManager& instance() {
    static DataManager instance;
    return instance;
  }

  ~DataManager() = default;
  uint32_t registerSensor(const SensorType& type, const std::string& name, const std::vector<std::string>& types,
                          const uint32_t& buffer_size, const double& max_time_delay);
  /**
   * @brief 初始化数据管理器
   * @return 初始化结果，0 表示成功，非 0 表示失败
   */
  uint32_t registerSensorsByConfig(const YAML::Node& config);

  uint32_t registerSensorsByFile(const std::string& file_path);

  /**
   * @brief 获取车辆名称
   * @return 车辆名称
   */
  std::string getVehicleName() const;

  /**
   * @brief 设置车辆名称
   * @param vehicle_name 要设置的车辆名称
   */
  void setVehicleName(const std::string& vehicle_name);

  /**
   * @brief 设置使用节点名称
   * @param node_name 要设置的使用节点名称
   */
  void setNodeName(const std::string& node_name);

  /**
   * @brief 获取使用节点名称
   * @return 使用节点名称
   */
  std::string getNodeName() const;

  
  uint32_t push(const std::string& sensor_name, const std::string& data_type, const double& timestamp,
                const std::shared_ptr<sensor_msgs::msg::PointCloud2>& data);

  uint32_t push(const std::string& sensor_name, const std::string& data_type, const double& timestamp,
                const std::shared_ptr<sensor_msgs::msg::Image>& data);
  
  template<typename T>
  uint32_t push(const std::string& sensor_name, const std::shared_ptr<T>& data){
    if(!other_buffer_map_.count(sensor_name)){
      NTERROR << "Node: " << node_name_ << " Other " << sensor_name << " does not exist.";
      return ErrorCode::PARAMETER_ERROR;
    }
    // 检查类型一致性
    auto it = type_registry_.find(sensor_name);
    if (it == type_registry_.end()) {
        NTERROR << "Node: " << node_name_ << " Other " << sensor_name << " data type is not register!";
        return ErrorCode::PARAMETER_ERROR;
    }
    const std::type_index& type_index = it->second;
    if (type_index != std::type_index(typeid(DataBuffer<T>))) {
        NTERROR << "Node: " << node_name_ << " Other " << sensor_name << " data type is not match!";
        return ErrorCode::PARAMETER_ERROR;
    }
    auto buffer = std::static_pointer_cast<DataBuffer<T>>(other_buffer_map_[sensor_name]);
    return buffer->push(*data);
  }

  uint32_t extractByTime(const std::string& sensor_name, const std::string& data_type, const double& timestamp,
                         std::shared_ptr<PointCloudData>& data);

  uint32_t extractByTime(const std::string& sensor_name, const std::string& data_type, const double& timestamp,
                         std::shared_ptr<ImageData>& data);

  template<typename T>
  uint32_t extractByTime(const std::string& sensor_name, const double& timestamp, std::shared_ptr<T>& data){
    if(!other_buffer_map_.count(sensor_name)){
      NTERROR << "Node: " << node_name_ << " Other " << sensor_name << " does not exist.";
      return ErrorCode::PARAMETER_ERROR;
    }
    // 检查类型一致性
    auto it = type_registry_.find(sensor_name);
    if (it == type_registry_.end()) {
        NTERROR << "Node: " << node_name_ << " Other " << sensor_name << " data type is not register!";
        return ErrorCode::PARAMETER_ERROR;
    }
    const std::type_index& type_index = it->second;
    if (type_index != std::type_index(typeid(DataBuffer<T>))) {
        NTERROR << "Node: " << node_name_ << " Other " << sensor_name << " data type is not match!";
        return ErrorCode::PARAMETER_ERROR;
    }
    auto buffer = std::static_pointer_cast<DataBuffer<T>>(other_buffer_map_[sensor_name]);
    return buffer->extractByTime(timestamp, *data);
  }
  
  uint32_t setSensorPose(const std::string& sensor_name, const Eigen::Isometry3f& pose);

  std::shared_ptr<const Eigen::Isometry3f> getSensorPose(const std::string& sensor_name) const;

  uint32_t setCameraIntrinsics(const std::string& sensor_name, const std::shared_ptr<sensor_msgs::msg::CameraInfo>& camera_info);

  std::shared_ptr<sensor_msgs::msg::CameraInfo> getCameraIntrinsics(const std::string& sensor_name) const;

  uint32_t getMetaInfo(const std::string& sensor_name, std::shared_ptr<CameraMetaInfo>& meta);
  
  template<typename T>
  double getLatestSensorDataTime(const std::string& sensor_name, const std::shared_ptr<T>& data = T()) {
    if (m_name_to_type_.find(sensor_name) == m_name_to_type_.end()) {
      NTERROR << "Node: " << node_name_ << " Sensor " << sensor_name << " does not exist.";
      return -1.0;  // 传感器不存在，返回异常值-1.0
    }

    switch (m_name_to_type_.at(sensor_name)) {
      case SensorType::LIDAR:
        return lidars_[sensor_name]->getLatestOriginDataTime();
      case SensorType::CAMERA:
        return cameras_[sensor_name]->getLatestOriginDataTime();
      case SensorType::OTHER:{
        // 检查类型一致性
        auto it = type_registry_.find(sensor_name);
        if (it == type_registry_.end()) {
            NTERROR << "Node: " << node_name_ << " Other " << sensor_name << " data type is not register!";
            return ErrorCode::PARAMETER_ERROR;
        }
        const std::type_index& type_index = it->second;
        if (type_index != std::type_index(typeid(DataBuffer<T>))) {
            NTERROR << "Node: " << node_name_ << " Other " << sensor_name << " data type is not match!";
            return ErrorCode::PARAMETER_ERROR;
        }
        auto buffer = std::static_pointer_cast<DataBuffer<T>>(other_buffer_map_[sensor_name]);
        if (!buffer) {
            NTERROR << "Node: " << node_name_ << " Function: getLatestSensorDataTime : Failed to cast buffer for sensor: " << sensor_name;
            return -1.0;
        }
        //buffer->printBuffer();
        return buffer->getLatestDataTime();
      }
      default:
        NTFATAL << "Node: " << node_name_ << " Invalid sensor type: " << m_name_to_type_[sensor_name];
        return -1.0;  // 无效传感器类型，返回异常值-1.0
    }
  }

private:
  // 私有构造函数，确保单例模式
  DataManager() = default;

  // 车辆名称
  std::string vehicle_name_ = "";
  std::string node_name_ = "";
  std::unordered_map<std::string, std::shared_ptr<Lidar>> lidars_;
  std::unordered_map<std::string, std::shared_ptr<Camera>> cameras_;
  std::unordered_map<std::string, SensorType> m_name_to_type_;
  std::unordered_map<std::string, std::type_index> type_registry_;
  std::unordered_map<std::string, std::shared_ptr<void>> other_buffer_map_;
};

}}
/**
 * @def DATA_MANAGER
 * @brief 获取DataManager的单例实例
 */
#define DATA_MANAGER tju::common::DataManager::instance()

/**
 * @def REGISTER_SENSORS_BY_CONFIG
 * @brief 通过YAML配置节点注册传感器
 * @param config YAML配置节点
 * @return 错误码(0表示成功)
 */
#define REGISTER_SENSORS_BY_CONFIG(config) \
  DATA_MANAGER.registerSensorsByConfig(config)

/**
 * @def REGISTER_SENSORS_BY_FILE
 * @brief 通过配置文件路径注册传感器
 * @param file_path 配置文件路径
 * @return 错误码(0表示成功)
 */
#define REGISTER_SENSORS_BY_FILE(file_path) \
  DATA_MANAGER.registerSensorsByFile(file_path)

/**
 * @def GET_VEHICLE_NAME
 * @brief 获取当前车辆名称
 * @return 车辆名称字符串
 */
#define GET_VEHICLE_NAME() \
  DATA_MANAGER.getVehicleName()

/**
 * @def SET_VEHICLE_NAME
 * @brief 设置当前车辆名称
 * @param vehicle_name 车辆名称字符串
 */
#define SET_VEHICLE_NAME(vehicle_name) \
  DATA_MANAGER.setVehicleName(vehicle_name)

/**
 * @def GET_NODE_NAME
 * @brief 获取当前node名称
 * @return node名称字符串
 */
#define GET_NODE_NAME() \
  DATA_MANAGER.getNodeName()

/**
 * @def SET_NODE_NAME
 * @brief 设置当前node名称
 * @param node_name node名称字符串
 */
#define SET_NODE_NAME(node_name) \
  DATA_MANAGER.setNodeName(node_name)

/**
 * @def PUSH_SENSOR_DATA
 * @brief 推送点云数据到指定传感器
 * @param sensor_name 传感器名称
 * @param data_type 数据类型字符串
 * @param timestamp 时间戳(秒)
 * @param data 点云数据智能指针
 * @return 错误码(0表示成功)
 */
#define PUSH_SENSOR_DATA(sensor_name, data_type, timestamp, data) \
  DATA_MANAGER.push(sensor_name, data_type, timestamp, data)

/**
 * @def PUSH_GENERIC_DATA
 * @brief 推送通用类型数据到指定传感器
 * @tparam DataType 数据类型（如ImuData、LaserScan等）
 * @param sensor_name 传感器名称
 * @param data 数据智能指针
 * @return 错误码(0表示成功)
 */
#define PUSH_GENERIC_DATA(DataType, sensor_name, data) \
  DATA_MANAGER.push<DataType>(sensor_name, data)

/**
 * @def EXTRACT_SENSOR_DATA_BY_TIME
 * @brief 按时间提取雷达相机数据
 * @param sensor_name 传感器名称
 * @param data_type 数据类型字符串
 * @param timestamp 时间戳(秒)
 * @param data 输出的点云数据智能指针
 * @return 错误码(0表示成功)
 */
#define EXTRACT_SENSOR_DATA_BY_TIME(sensor_name, data_type, timestamp, data) \
  DATA_MANAGER.extractByTime(sensor_name, data_type, timestamp, data)


/**
 * @def EXTRACT_GENERIC_BY_TIME
 * @brief 按时间提取通用类型数据
 * @tparam DataType 数据类型（如ImuData、LaserScan等）
 * @param sensor_name 传感器名称
 * @param timestamp 时间戳(秒)
 * @param data 输出的数据智能指针
 * @return 错误码(0表示成功)
 */
#define EXTRACT_GENERIC_BY_TIME(DataType, sensor_name, timestamp, data) \
  DATA_MANAGER.extractByTime<DataType>(sensor_name, timestamp, data)

/**
 * @def SET_SENSOR_POSE
 * @brief 设置传感器位姿
 * @param sensor_name 传感器名称
 * @param pose 位姿变换矩阵
 * @return 错误码(0表示成功)
 */
#define SET_SENSOR_POSE(sensor_name, pose) \
  DATA_MANAGER.setSensorPose(sensor_name, pose)

/**
 * @def GET_SENSOR_POSE
 * @brief 获取传感器位姿
 * @param sensor_name 传感器名称
 * @return 位姿变换矩阵智能指针
 */
#define GET_SENSOR_POSE(sensor_name) \
  DATA_MANAGER.getSensorPose(sensor_name)

/**
 * @def SET_CAMERA_INTRINSICS
 * @brief 设置相机内参
 * @param sensor_name 传感器名称
 * @param camera_info 相机内参信息智能指针
 * @return 错误码(0表示成功)
 */
#define SET_CAMERA_INTRINSICS(sensor_name, camera_info) \
  DATA_MANAGER.setCameraIntrinsics(sensor_name, camera_info)

/**
 * @def GET_CAMERA_INTRINSICS
 * @brief 获取相机内参
 * @param sensor_name 传感器名称
 * @return 相机内参信息智能指针
 */
#define GET_CAMERA_INTRINSICS(sensor_name) \
  DATA_MANAGER.getCameraIntrinsics(sensor_name)

/**
 * @def GET_CAMERA_META_INFO
 * @brief 获取相机元信息
 * @param sensor_name 传感器名称
 * @param meta 输出的相机元信息智能指针
 * @return 错误码(0表示成功)
 */
#define GET_CAMERA_META_INFO(sensor_name, meta) \
  DATA_MANAGER.getMetaInfo(sensor_name, meta)

/**
 * @def GET_LATEST_SENSOR_DATA_TIME
 * @brief 获取传感器最新数据时间
 * @tparam DataType 数据类型（如ImuData、LaserScan等）
 * @param sensor_name 传感器名称
 * @param data 可选数据参数(默认构造)
 * @return 最新数据时间戳(秒)，失败时返回-1.0
 */
#define GET_LATEST_SENSOR_DATA_TIME(DataType, sensor_name, ...) \
  DATA_MANAGER.getLatestSensorDataTime<DataType>(sensor_name, ##__VA_ARGS__)
