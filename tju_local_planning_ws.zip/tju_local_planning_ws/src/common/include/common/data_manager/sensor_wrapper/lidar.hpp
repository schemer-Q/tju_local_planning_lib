#pragma once

#include <sys/types.h>
#include <Eigen/Dense>
#include <cstdint>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

#include "common/log/t_log.hpp"
#include "common/data_manager/sensor_wrapper/base.h"
#include "common/data_manager/data_buffer.hpp"

namespace tju{
namespace common{
class LidarMetaInfo {
 public:
  std::shared_ptr<Eigen::Isometry3f> pose_ptr;
};

class Lidar : public SensorWrapper<sensor_msgs::msg::PointCloud2, PointCloudData, LidarMetaInfo> {
 public:
  Lidar() = default;
  ~Lidar() = default;

  /**
   * @brief 激光雷达支持有类型列表初始化
   */
  uint32_t init(const std::string& name, const std::vector<std::string>& types, const uint32_t& buffer_size,
                const double& max_time_delay) override;

  /**
   * @brief 将数据推入缓冲区
   *
   * @param type [in] 数据类型
   * @param timestamp [in] 时间戳, 单位为秒
   * @param data [in] 原始数据指针
   * @return uint32_t 错误码
   */
  uint32_t push(const std::string& type, const double& timestamp, const std::shared_ptr<sensor_msgs::msg::PointCloud2>& data) override;

  /**
   * @brief 按照时间戳提取数据
   *
   * @param type [in] 数据类型
   * @param timestamp [in] 时间戳, 单位为秒
   * @param data [out] 传感器数据
   * @return uint32_t 错误码
   */
  uint32_t extractByTime(const std::string& type, const double& timestamp,
                         std::shared_ptr<PointCloudData>& data) override;

  /**
   * @brief 更新传感器元数据
   *
   * @param meta [in] 传感器元数据指针, e.g. std::shared_ptr<SensorMeta>
   * @return uint32_t 错误码
   */
  uint32_t updateMeta(const std::shared_ptr<LidarMetaInfo>& meta) override;

  /**
   * @brief 更新传感器元数据
   *
   * @param name [in] info名称
   * @param info [in] info数据指针, e.g. std::shared_ptr<Eigen::Isometry3f>
   * @return uint32_t 错误码
   */
  uint32_t updateMeta(const std::string& name, const std::shared_ptr<void>& info) override;

  /**
   * @brief 获取传感器元数据
   *
   * @param meta [out] 传感器元数据指针, e.g. std::shared_ptr<SensorMeta>
   * @return uint32_t 错误码
   */
  uint32_t getMeta(std::shared_ptr<LidarMetaInfo>& meta) override;

  /**
   * @brief 设置传感器位姿, 线程不安全
   *
   * @param pose [in] 位姿
   * @return 错误码
   */
  uint32_t setPose(const Eigen::Isometry3f& pose) override;
  /**
   * @brief 获取传感器位姿, 线程不安全
   *
   * @return 位姿
   */
  std::shared_ptr<const Eigen::Isometry3f> pose() const override;

  /**
   * @brief 获取传感器名称
   *
   * @return 传感器名称
   */
  const std::string& name() const override;

  /**
   * @brief 获取传感器原始数据最新时间
   *
   * @return double 时间
   */
  double getLatestOriginDataTime();

 private:
  std::string name_;                           ///< 传感器名称
  uint32_t buffer_size_;                       ///< 数据缓冲区大小
  double max_time_delay_;                      ///< 数据缓冲区最大时间延迟
  std::vector<std::string> pointcloud_types_;  ///< 点云类型, 如: orig, tf, preprocessed, etc.

  std::unordered_map<std::string, PointCloudDataBufferPtr> m_type_buffer_;
  std::shared_ptr<LidarMetaInfo> meta_;  ///< 传感器元数据
};
}
}