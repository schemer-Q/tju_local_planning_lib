#include "common/data_manager/sensor_wrapper/camera.hpp"

namespace tju{
namespace common{
  uint32_t Camera::init(const std::string& name, const std::vector<std::string>& types, const uint32_t& buffer_size,
                const double& max_time_delay) {
    name_ = name;
    buffer_size_ = buffer_size;
    max_time_delay_ = max_time_delay;
    types_ = types;
    for (const auto& type : types_) {
      m_type_buffer_[type] = std::make_shared<ImageDataBuffer>(buffer_size, name_, max_time_delay);
    }
    meta_ = std::make_shared<CameraMetaInfo>();
    return tju::common::ErrorCode::OK;
  }

  uint32_t Camera::push(const std::string& type, const double& timestamp, const std::shared_ptr<sensor_msgs::msg::Image>& data) {
    auto it = m_type_buffer_.find(type);
    if (it == m_type_buffer_.end()) {  // 没有找到对应的类型
      NTERROR << "Camera: " << name_ << " push failed for type not found.";
      return tju::common::ErrorCode::SENSOR_DATA_TYPE_NOT_FOUND;
    }
    if (!data) {
      NTFATAL << "Camera: " << name_ << " push failed for data is nullptr.";
      return tju::common::ErrorCode::PARAMETER_ERROR;
    }
    return it->second->push(ImageData(timestamp, data));
  }

  uint32_t Camera::extractByTime(const std::string& type, const double& timestamp, std::shared_ptr<ImageData>& data) {
    auto it = m_type_buffer_.find(type);
    if (it == m_type_buffer_.end()) {  // 没有找到对应的类型
      NTERROR << "Camera: " << name_ << " extractByTime failed for type not found.";
      return tju::common::ErrorCode::SENSOR_DATA_TYPE_NOT_FOUND;
    }
    data = std::make_shared<ImageData>();
    uint32_t result = it->second->extractByTime(timestamp, *data);
    if (result != tju::common::ErrorCode::OK) {
      NTERROR << "Camera: " << name_ << " extractByTime failed for extract failed.";
      data = nullptr;
    }
    return result;
  }

  uint32_t Camera::updateMeta(const std::shared_ptr<CameraMetaInfo>& meta) {
    if (!meta) {
      NTFATAL << "Camera: " << name_ << " updateMeta failed for input meta is nullptr.";
      return tju::common::ErrorCode::PARAMETER_ERROR;
    }
    if (!meta_) {
      NTERROR << "Camera: " << name_ << " updateMeta failed for meta is nullptr.";
      return tju::common::ErrorCode::UNINITIALIZED;
    }
    meta_ = meta;
    //initProjection();
    //initUndistort();
    return tju::common::ErrorCode::OK;
  }

  uint32_t Camera::updateMeta(const std::string& name, const std::shared_ptr<void>& info) {
    if (!meta_) {
      NTERROR << "Camera: " << name_ << " updateMeta failed for meta is nullptr.";
      return tju::common::ErrorCode::UNINITIALIZED;
    }
    if (!info) {
      NTERROR << "Camera: " << name_ << " updateMeta failed for info is nullptr.";
      return tju::common::ErrorCode::PARAMETER_ERROR;
    }

    if (name == "pose") {
      const auto pose_ptr = std::static_pointer_cast<Eigen::Isometry3f>(info);
      if (!pose_ptr) {
        NTERROR << "Camera: " << name_ << " updateMeta failed for pose_ptr is nullptr.";
        return tju::common::ErrorCode::PARAMETER_ERROR;
      }
      meta_->pose_ptr = pose_ptr;
    } else if (name == "camera_info") {
      const auto camera_info_ptr = std::static_pointer_cast<sensor_msgs::msg::CameraInfo>(info);
      if (!camera_info_ptr) {
        NTERROR << "Camera: " << name_ << " updateMeta failed for camera_info_ptr is nullptr.";
        return tju::common::ErrorCode::PARAMETER_ERROR;
      }
      meta_->camera_info_ptr = camera_info_ptr;
    } else {
      NTERROR << "Camera: " << name_ << " updateMeta failed for name not found.";
      return tju::common::ErrorCode::PARAMETER_ERROR;
    }
    //initProjection();
    //initUndistort();
    return tju::common::ErrorCode::OK;
  }

  uint32_t Camera::getMeta(std::shared_ptr<CameraMetaInfo>& meta) {
    if (!meta_) {
      NTERROR << "Camera: " << name_ << " getMeta failed for meta is nullptr.";
      return tju::common::ErrorCode::UNINITIALIZED;
    }
    meta = std::make_shared<CameraMetaInfo>(*meta_);
    return tju::common::ErrorCode::OK;
  }

  uint32_t Camera::setPose(const Eigen::Isometry3f& pose) {
    meta_->pose_ptr = std::make_shared<Eigen::Isometry3f>(pose);
    //initProjection();
    return tju::common::ErrorCode::OK;
  }

  double Camera::getLatestOriginDataTime() {
    const std::string type = "origin";
    auto it = m_type_buffer_.find(type);
    if (it == m_type_buffer_.end()) {  // 没有找到对应的类型，返回异常值-1.0
      NTERROR << "Camera: " << name_ << " getLatestOriginDataTime failed for type not found.";
      return -1.0;
    }

    return m_type_buffer_[type]->getLatestDataTime();
  }
}
}