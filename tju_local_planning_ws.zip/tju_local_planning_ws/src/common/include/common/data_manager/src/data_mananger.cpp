#include "common/data_manager/data_manager.hpp"

namespace tju {
namespace common {
uint32_t DataManager::registerSensor(const SensorType& type, const std::string& name, const std::vector<std::string>& types,
                        const uint32_t& buffer_size, const double& max_time_delay){
  uint32_t ret = ErrorCode::OK;
  
  switch (type) {
    case SensorType::LIDAR:
      if (lidars_.find(name) != lidars_.end()) {
        NTERROR << "Node: " << node_name_ << " Lidar " << name << " already exists.";
        return ErrorCode::PARAMETER_ERROR;
      }
      lidars_[name] = std::make_shared<Lidar>();
      ret = lidars_[name]->init(name, types, buffer_size, max_time_delay);
      if (ret != ErrorCode::OK) {
        NTERROR << "Node: " << node_name_ << " Failed to register sensor " << name << " of type LIDAR.";
      }
      m_name_to_type_[name] = SensorType::LIDAR;
      break;
    case SensorType::CAMERA:
      if (cameras_.find(name) != cameras_.end()) {
        NTERROR << "Node: " << node_name_ << " Camera " << name << " already exists.";
        return ErrorCode::PARAMETER_ERROR;
      }
      cameras_[name] = std::make_shared<Camera>();
      ret = cameras_[name]->init(name, types, buffer_size, max_time_delay);
      if (ret != ErrorCode::OK) {
        NTERROR << "Node: " << node_name_ << " Failed to register sensor " << name << " of type CAMERA.";
      }
      m_name_to_type_[name] = SensorType::CAMERA;
      break;
    case SensorType::OTHER:{
      bool registered = false;
      // 定义一个宏来简化缓冲区创建逻辑
      #define CREATE_BUFFER(TYPE, NAME) \
        if (name == NAME) { \
          auto buffer = std::make_shared<TYPE>(buffer_size, name, max_time_delay); \
          type_registry_.emplace(name, std::type_index(typeid(TYPE))); \
          other_buffer_map_[name] = buffer; \
          m_name_to_type_[name] = SensorType::OTHER; \
          registered = true; \
        }

      // 根据类型参数创建对应的缓冲区
      CREATE_BUFFER(ImuDataBuffer, "IMU");
      CREATE_BUFFER(OgmPointsDataBuffer, "OGMPOINTS");
      CREATE_BUFFER(ObjectsDataBuffer, "OBJECTS");
      CREATE_BUFFER(TargetPoseDataBuffer, "LOCALPERCEPTION");
      CREATE_BUFFER(RtkDataBuffer, "GPSLOCATION");
      CREATE_BUFFER(OdometryDataBuffer, "SLAMLOCATION");
      CREATE_BUFFER(OdometryDataBuffer, "FUSIONLOCATION");
      CREATE_BUFFER(GlobalPathDataBuffer, "GLOBALPATH");
      CREATE_BUFFER(LocalPathDataBuffer, "LOCALPATH");
      CREATE_BUFFER(LocalStatusDataBuffer, "LOCALPATHSTATE");
      CREATE_BUFFER(ControlDataBuffer, "CONTROL");
      CREATE_BUFFER(CarOriDataBuffer, "CARORI");
      CREATE_BUFFER(CrossGoalDataBuffer, "CROSSGOAL");
      CREATE_BUFFER(ArmOriDataBuffer, "ARMINFO");
      CREATE_BUFFER(ForkTaskStateDataBuffer, "ARMTASKSTATE");
      CREATE_BUFFER(ForkControlDataBuffer, "ARMCONTROL");
      CREATE_BUFFER(GoalDataBuffer, "TASKGOAL");
      CREATE_BUFFER(TaskTypeDataBuffer, "TASKTYPE");

      #undef CREATE_BUFFER

      if(!registered){
        NTERROR << "Node: " << node_name_ << " Unknown sensor name: " << name;
        return ErrorCode::PARAMETER_ERROR;
      }
    }
      break;
    default:
      NTFATAL << "Node: " << node_name_ << " Invalid sensor type: " << type;
      ret = ErrorCode::PARAMETER_ERROR;
      break;
  }
  #undef CREATE_BUFFER
  return ret;
}
/**
 * @brief 初始化数据管理器
 * @return 初始化结果，0 表示成功，非 0 表示失败
 */
uint32_t DataManager::registerSensorsByConfig(const YAML::Node& config){
  try {
    if (config["VEHICLE_NAME"]) {
      vehicle_name_ = config["VEHICLE_NAME"].as<std::string>();
    }
    if (config["Sensors"]) {
      for (const auto& sensor : config["Sensors"]) {
        std::string type = sensor["Type"].as<std::string>();
        SensorType sensor_type = stringToSensorType(type);
        std::string name = sensor["Name"].as<std::string>();
        std::vector<std::string> sub_types;
        if (sensor["SubTypes"]) {
          sub_types = sensor["SubTypes"].as<std::vector<std::string>>();
        }
        uint32_t buffer_size = sensor["BufferSize"].as<uint32_t>();
        double max_time_delay = sensor["MaxTimeDelay"].as<double>();
        registerSensor(sensor_type, name, sub_types, buffer_size, max_time_delay);
      }
    } else {
      NTERROR << "Node: " << node_name_ << " No Sensors found in config.";
      return ErrorCode::PARAMETER_ERROR;
    }
  } catch (const YAML::Exception& e) {
    NTERROR << "Node: " << node_name_ << " Failed to register sensors by config: " << e.what();
  }
  return ErrorCode::OK;
}

uint32_t DataManager::registerSensorsByFile(const std::string& file_path){
  if (!is_file_exist(file_path)) {
    NTFATAL << "Node: " << node_name_ << " File " << file_path << " does not exist.";
    return ErrorCode::PARAMETER_ERROR;
  }
  YAML::Node config = YAML::LoadFile(file_path);
  return registerSensorsByConfig(config);
}

/**
 * @brief 获取车辆名称
 * @return 车辆名称
 */
std::string DataManager::getVehicleName() const {
  return vehicle_name_;
}

/**
 * @brief 设置车辆名称
 * @param vehicle_name 要设置的车辆名称
 */
void DataManager::setVehicleName(const std::string& vehicle_name) {
  vehicle_name_ = vehicle_name;
}

/**
 * @brief 设置使用节点名称
 * @param node_name 要设置的使用节点名称
 */
void DataManager::setNodeName(const std::string& node_name) {
  node_name_ = node_name;
}

/**
 * @brief 获取使用节点名称
 * @return 使用节点名称
 */
std::string DataManager::getNodeName() const {
  return node_name_;
}

uint32_t DataManager::push(const std::string& sensor_name, const std::string& data_type, const double& timestamp,
              const std::shared_ptr<sensor_msgs::msg::PointCloud2>& data){
  if (lidars_.find(sensor_name) == lidars_.end()) {
    NTERROR << "Node: " << node_name_ << " Lidar " << sensor_name << " does not exist.";
    return ErrorCode::PARAMETER_ERROR;
  }
  return lidars_[sensor_name]->push(data_type, timestamp, data);
}

uint32_t DataManager::push(const std::string& sensor_name, const std::string& data_type, const double& timestamp,
              const std::shared_ptr<sensor_msgs::msg::Image>& data){
  if (cameras_.find(sensor_name) == cameras_.end()) {
    NTERROR << "Node: " << node_name_ << " Camera " << sensor_name << " does not exist.";
    return ErrorCode::PARAMETER_ERROR;
  }
  return cameras_[sensor_name]->push(data_type, timestamp, data);
}

uint32_t DataManager::extractByTime(const std::string& sensor_name, const std::string& data_type, const double& timestamp,
                        std::shared_ptr<PointCloudData>& data){
  if (lidars_.find(sensor_name) == lidars_.end()) {
    NTERROR << "Node: " << node_name_ << " Lidar " << sensor_name << " does not exist.";
    return ErrorCode::PARAMETER_ERROR;
  }
  return lidars_[sensor_name]->extractByTime(data_type, timestamp, data);
}

uint32_t DataManager::extractByTime(const std::string& sensor_name, const std::string& data_type, const double& timestamp,
                        std::shared_ptr<ImageData>& data){
  if (cameras_.find(sensor_name) == cameras_.end()) {
    NTERROR << "Node: " << node_name_ << " Camera " << sensor_name << " does not exist.";
    return ErrorCode::PARAMETER_ERROR;
  }
  return cameras_[sensor_name]->extractByTime(data_type, timestamp, data);               
}

uint32_t DataManager::setSensorPose(const std::string& sensor_name, const Eigen::Isometry3f& pose){
  if (m_name_to_type_.find(sensor_name) == m_name_to_type_.end()) {
    NTERROR << "Node: " << node_name_ << " Sensor " << sensor_name << " does not exist.";
    return ErrorCode::PARAMETER_ERROR;
  }
  switch (m_name_to_type_.at(sensor_name)) {
    case SensorType::LIDAR:
      return lidars_[sensor_name]->setPose(pose);
    case SensorType::CAMERA:
      return cameras_[sensor_name]->setPose(pose);
    default:
      NTFATAL << "Node: " << node_name_ << " Invalid sensor type: " << m_name_to_type_[sensor_name];
      return ErrorCode::PARAMETER_ERROR;
  }
  return ErrorCode::OK;
}

std::shared_ptr<const Eigen::Isometry3f> DataManager::getSensorPose(const std::string& sensor_name) const{
  if (m_name_to_type_.find(sensor_name) == m_name_to_type_.end()) {
    NTERROR << "Node: " << node_name_ << " Sensor " << sensor_name << " does not exist.";
    return nullptr;
  }
  switch (m_name_to_type_.at(sensor_name)) {
    case SensorType::LIDAR:
      return lidars_.at(sensor_name)->pose();
    case SensorType::CAMERA:
      return cameras_.at(sensor_name)->pose();
    default:
      NTFATAL << "Node: " << node_name_ << " Invalid sensor type: " << m_name_to_type_.at(sensor_name);
      return nullptr;
  }
}

uint32_t DataManager::setCameraIntrinsics(const std::string& sensor_name, const std::shared_ptr<sensor_msgs::msg::CameraInfo>& camera_info){
  if (cameras_.find(sensor_name) == cameras_.end()) {
    NTERROR << "Node: " << node_name_ << " Camera " << sensor_name << " does not exist.";
    return ErrorCode::PARAMETER_ERROR;
  }
  return cameras_[sensor_name]->updateMeta("camera_info", camera_info);
}

std::shared_ptr<sensor_msgs::msg::CameraInfo> DataManager::getCameraIntrinsics(const std::string& sensor_name) const{
  if (cameras_.find(sensor_name) == cameras_.end()) {
    NTERROR << "Node: " << node_name_ << " Sensor " << sensor_name << " does not exist.";
    return nullptr;
  }
  std::shared_ptr<CameraMetaInfo> meta = nullptr;
  cameras_.at(sensor_name)->getMeta(meta);
  return meta->camera_info_ptr;
}

uint32_t DataManager::getMetaInfo(const std::string& sensor_name, std::shared_ptr<CameraMetaInfo>& meta){
  if (cameras_.find(sensor_name) == cameras_.end()) {
    NTERROR << "Node: " << node_name_ << " Sensor " << sensor_name << " does not exist.";
    return ErrorCode::PARAMETER_ERROR;
  }
  return cameras_[sensor_name]->getMeta(meta);
}

}
}