#pragma once

#include "jian/jian.h"
namespace tju{
namespace common {
/**
 * @brief trace level log, e.g. NTTRACE << "trace info";
 * @ingroup tools_t_log
 */
#define NTTRACE JLOGGER_TRACE_S("common")
/**
 * @brief debug level log, e.g. NTDEBUG << "debug info";
 * @ingroup tools_t_log
 */
#define NTDEBUG JLOGGER_DEBUG_S("common")
/**
 * @brief info level log, e.g. NTINFO << "info info";
 *  @ingroup tools_t_log
 */
#define NTINFO JLOGGER_INFO_S("common")
/**
 * @brief warning level log, e.g. NTWARNING << "info info";
 * @ingroup tools_t_log
 */
#define NTWARNING JLOGGER_WARN_S("common")
/**
 * @brief error level log, e.g. NTERROR << "error info";
 * @ingroup tools_t_log
 */
#define NTERROR JLOGGER_ERROR_S("common")
/**
 * @brief fatal level log, e.g. NTFATAL << "fatal info";
 * @ingroup tools_t_log
 */
#define NTFATAL JLOGGER_CRITICAL_S("common")
}
}
