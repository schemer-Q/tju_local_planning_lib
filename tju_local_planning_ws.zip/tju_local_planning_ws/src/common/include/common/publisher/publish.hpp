#pragma once

#include <chrono>
#include <condition_variable>
#include <functional>
#include <memory>
#include <mutex>
#include <utility>
#include <unordered_map>
#include <any>
#include <typeindex>

#include "rclcpp/rclcpp.hpp"
#include "yaml-cpp/yaml.h"

#include "common/util/diagnosis.h"
#include "common/log/t_log.hpp"

#include "nav_msgs/msg/odometry.hpp"
#include "control_task_msgs/msg/task_goal_data.hpp"
#include "sensor_msgs/msg/image.hpp"
#include "sensor_msgs/msg/point_cloud2.hpp"
#include "sensing_msgs/msg/imu_data.hpp"
#include "sensing_msgs/msg/rtk_data.hpp"
#include "planning_msgs/msg/trajectory_points.hpp"
#include "chassis_msgs/msg/car_ori_interface.hpp"
#include "chassis_msgs/msg/arm_data.hpp"
#include "chassis_msgs/msg/fork_control.hpp"
#include "perception_msgs/msg/ogm_points.hpp"
#include "perception_msgs/msg/objects.hpp"
#include "perception_task_msgs/msg/target_pose.hpp"
#include "control_msgs/msg/cross_goal.hpp"
#include "control_msgs/msg/pathspeedctrl_interface.hpp"
#include "control_task_msgs/msg/task_state.hpp"
#include "planning_msgs/msg/local_trajectory_points.hpp"
#include "control_task_msgs/msg/task_type.hpp"
#include "planning_msgs/msg/trajectory_state.hpp"

namespace tju {
namespace common {

class Publisher {
 public:
  explicit Publisher(rclcpp::Node::SharedPtr node) : node_(std::move(node)) {}
  ~Publisher() = default;

  // 注册发布者，返回错误码
  uint32_t registerByYaml(const YAML::Node &config) {
    std::string node_name = node_->get_name();
    try {
      if (!config.IsSequence()) {
        NTFATAL << "Node: " << node_name << " [Init][Publisher] group has no member!";
        return ErrorCode::PARAMETER_ERROR;
      }
      
      for (const auto &node : config) {
        auto name = node["Name"].as<std::string>();
        std::string topic;
        if (node["Topic"].IsDefined()) {
          topic = node["Topic"].as<std::string>();
        } else {
          NTERROR << "Node: " << node_name << " Publisher " << name << " has no topic defined";
          continue;
        }
        
        // 根据类型参数创建对应的发布者
        bool registered = false;
        
        // 使用宏简化重复代码
        #define REGISTER_PUBLISHER(NAME, MSG_TYPE) \
          if (name == NAME) { \
            auto publisher = node_->create_publisher<MSG_TYPE>(topic, 10); \
            publishers_[name] = publisher; \
            publisher_types_.emplace(name, std::type_index(typeid(MSG_TYPE))); \
            registered = true; \
          }
        
        REGISTER_PUBLISHER("IMU", sensing_msgs::msg::ImuData)
        REGISTER_PUBLISHER("OGMPOINTS", perception_msgs::msg::OgmPoints)
        REGISTER_PUBLISHER("OBJECTS", perception_msgs::msg::Objects)
        REGISTER_PUBLISHER("LOCALPERCEPTION", perception_task_msgs::msg::TargetPose)
        REGISTER_PUBLISHER("GPSLOCATION", sensing_msgs::msg::RtkData)
        REGISTER_PUBLISHER("SLAMLOCATION", nav_msgs::msg::Odometry)
        REGISTER_PUBLISHER("FUSIONLOCATION", nav_msgs::msg::Odometry)
        REGISTER_PUBLISHER("GLOBALPATH", planning_msgs::msg::TrajectoryPoints)
        REGISTER_PUBLISHER("LOCALPATH", planning_msgs::msg::LocalTrajectoryPoints)
        REGISTER_PUBLISHER("LOCALPATHSTATE", planning_msgs::msg::TrajectoryState)
        REGISTER_PUBLISHER("CONTROL", control_msgs::msg::PathspeedctrlInterface)
        REGISTER_PUBLISHER("CARORI", chassis_msgs::msg::CarOriInterface)
        REGISTER_PUBLISHER("CROSSGOAL", control_msgs::msg::CrossGoal)
        REGISTER_PUBLISHER("ARMINFO", chassis_msgs::msg::ArmData)
        REGISTER_PUBLISHER("ARMTASKSTATE", control_task_msgs::msg::TaskState)
        REGISTER_PUBLISHER("ARMCONTROL", chassis_msgs::msg::ForkControl)
        REGISTER_PUBLISHER("TASKGOAL", control_task_msgs::msg::TaskGoalData)
        REGISTER_PUBLISHER("TASKTYPE", control_task_msgs::msg::TaskType)
        
        #undef REGISTER_PUBLISHER
        
        if (!registered) {
          NTERROR << "Node: " << node_name << " Unknown publisher name: " << name;
          return ErrorCode::PARAMETER_ERROR;
        }
      }
    } catch (const std::exception &e) {
      NTFATAL << "Node: " << node_name << " [Init][Publisher] Failed to init publishers: " << e.what();
      return ErrorCode::PARAMETER_ERROR;
    }
    
    return ErrorCode::OK;
  }

  // 发布消息的模板函数
  template<typename MessageT>
  uint32_t publish(const std::string& name, const MessageT& message) {
    if (!publishers_.count(name)) {
      NTERROR << "Node: " << node_->get_name() << " Publisher " << name << " not found";
      return ErrorCode::PARAMETER_ERROR;;
    }
    
    // 检查类型一致性
    auto it = publisher_types_.find(name);
    if (it == publisher_types_.end()) {
        NTERROR << "Node: " << node_->get_name() << " Publisher sensor name :" << name 
             << "  mismatch!";
        return ErrorCode::PARAMETER_ERROR;
    }
    const std::type_index& type_index = it->second;
    if (type_index != std::type_index(typeid(MessageT))) {
        NTERROR << "Node: " << node_->get_name() << " Publisher " << name 
             << " type mismatch. Expected: " << type_index.name() 
             << ", Got: " << std::type_index(typeid(MessageT)).name();
        return ErrorCode::PARAMETER_ERROR;
    }
    
    try {
      // 安全地转换为正确的发布者类型
      auto publisher = std::any_cast<std::shared_ptr<rclcpp::Publisher<MessageT>>>(publishers_[name]);
      publisher->publish(message);
      return ErrorCode::OK;
    } catch (const std::bad_any_cast& e) {
      NTERROR << "Node: " << node_->get_name() << " Publisher " << name 
             << " cast error: " << e.what();
      return ErrorCode::PARAMETER_ERROR;;
    }
  }

 private:
  rclcpp::Node::SharedPtr node_;
  std::unordered_map<std::string, std::any> publishers_;
  std::unordered_map<std::string, std::type_index> publisher_types_; // 存储发布者的类型信息
};

}}

