#pragma once
#include <functional>
#include <map>
#include <memory>
#include <rclcpp/clock.hpp>
#include <rclcpp/rclcpp.hpp>
#include <string>

#include "common/util/diagnosis.h"
#include "common/log/t_log.hpp"

namespace tju {
namespace common {
extern std::mutex lock;
extern std::condition_variable cv;
extern std::chrono::steady_clock::time_point last_trigger_time;
extern bool ready;
class SingleSubscriber {
 public:
  explicit SingleSubscriber(rclcpp::Node::SharedPtr node);
  virtual ~SingleSubscriber() = default;
  [[nodiscard]] virtual std::string get_class_name() const = 0;
  
  // NOTE: if more params is required in the future, variadic template is a good choice
  // This a sub for a SubscriberCls using different key-topic
  virtual void sub(const std::string &topic, const std::string &key, const float &latency,
                   const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) = 0;
                   
  // This a sub for a SubscriberCls using different key-topic with trigger
  virtual void sub_and_trigger(const std::string &topic, const std::string &key, 
                                const float &latency, const float& frame_time_diff = 0.04);

  // This a sub for a SubscriberCls using pre-defined topic
  virtual void sub(const float latency, const float frame_time_diff) = 0; 
  
  // This a sub for a SubscriberCls using specific topic
  virtual void sub(const std::string topic, const float latency, const float frame_time_diff) = 0; 

  /**
   * @brief 诊断消息数据时间戳异常
   *
   * @param msg_time 消息数据时间戳node
   * @param code 故障码
   */
  void diagnostic(const double &msg_time, const int32_t &code);

  /**
   * @brief 诊断消息数据时间戳延迟过大
   *
   * @param msg_time 消息数据时间戳
   * @param latency 延迟阈值(sec)
   * @param code 故障码
   */
  void diagnostic(const double &msg_time, const float &latency, const int32_t &code);

  /**
   * @brief 诊断消息数据异常
   *
   * @param data_error 消息数据异常标识
   * @param code 故障码
   */
  void diagnostic(const bool data_error, const int32_t &code);

 protected:
  std::string key_;
  float latency_;
  rclcpp::Node::SharedPtr node_;
};

class SingleSubscriberRegistry {
 public:
  static SingleSubscriberRegistry &Get();

  void Register(const std::string &name,
                std::function<std::unique_ptr<SingleSubscriber>(rclcpp::Node::SharedPtr)> factory);

  std::unique_ptr<SingleSubscriber> Create(const std::string &name, rclcpp::Node::SharedPtr node);

 private:
  std::map<std::string, std::function<std::unique_ptr<SingleSubscriber>(rclcpp::Node::SharedPtr)>> factories_;
  std::mutex mutex_;  // 添加互斥锁保证线程安全
};

#define REGISTER_SUBSCRIBER(NAME, TYPE)                                                                                \
  namespace {                                                                                                          \
  struct Register##TYPE {                                                                                              \
    Register##TYPE() {                                                                                                 \
      SingleSubscriberRegistry::Get().Register(NAME,                                                                   \
                                               [](rclcpp::Node::SharedPtr node) -> std::unique_ptr<SingleSubscriber> { \
                                                 return std::make_unique<TYPE>(std::move(node));                       \
                                               });                                                                     \
    }                                                                                                                  \
  };                                                                                                                   \
  static Register##TYPE staticRegister##TYPE;                                                                          \
  }
}}