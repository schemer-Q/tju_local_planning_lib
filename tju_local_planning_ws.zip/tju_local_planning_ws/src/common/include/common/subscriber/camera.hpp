#pragma once

#include "base_subscriber.hpp"
#include "common/log/t_log.hpp"
#include "common/data_manager/data_manager.hpp"

namespace tju {
namespace common {
// Camera
class CameraSubscriber : public SingleSubscriber {
public:
  explicit CameraSubscriber(rclcpp::Node::SharedPtr node);
  ~CameraSubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub_and_trigger(const std::string &topic, const std::string &key, const float &latency, 
                       const float &frame_time_diff = 0.04) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;

private:
  rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr subscriber_;

  void callback(const sensor_msgs::msg::Image::SharedPtr msg);
  void callback_with_trigger(const sensor_msgs::msg::Image::SharedPtr &msg);
};

REGISTER_SUBSCRIBER("CameraSubscriber", CameraSubscriber)

// CameraInfo
class CameraInfoSubscriber : public SingleSubscriber {
public:
  explicit CameraInfoSubscriber(rclcpp::Node::SharedPtr node);
  ~CameraInfoSubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;

private:
  rclcpp::Subscription<sensor_msgs::msg::CameraInfo>::SharedPtr subscriber_;

  void callback(const sensor_msgs::msg::CameraInfo::SharedPtr &msg);
};
REGISTER_SUBSCRIBER("CameraInfoSubscriber", CameraInfoSubscriber)

}
}
