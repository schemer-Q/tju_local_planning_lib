#pragma once
#include "common/data_manager/data_manager.hpp"
#include "common/subscriber/base_subscriber.hpp"
#include "common/util/diagnosis.h"
#include "common/log/t_log.hpp"
#include "common/util/timer.hpp"


namespace tju {
namespace common {

class LidarSubscriber : public SingleSubscriber {
public:
  explicit LidarSubscriber(rclcpp::Node::SharedPtr node);
  ~LidarSubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub_and_trigger(const std::string &topic, const std::string &key, const float &latency, 
                       const float &frame_time_diff = 0.04) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;

private:
  rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr subscriber_;
  Timer timer_;

  void callback(const sensor_msgs::msg::PointCloud2::SharedPtr msg);
  void callback_with_trigger(const sensor_msgs::msg::PointCloud2::SharedPtr &msg);
};
REGISTER_SUBSCRIBER("LidarSubscriber", LidarSubscriber)

}} 
