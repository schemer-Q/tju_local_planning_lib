#pragma once
#include "common/subscriber/base_subscriber.hpp"
#include "common/log/t_log.hpp"
#include "common/data_manager/data_manager.hpp"
#include "common/data_manager/data_buffer.hpp"

namespace tju {
namespace common {

class ImuSubscriber : public SingleSubscriber {
public:
  explicit ImuSubscriber(rclcpp::Node::SharedPtr node);
  ~ImuSubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;
  void sub_and_trigger(const std::string &topic, const std::string &key, const float &latency, 
                      const float &frame_time_diff) override;

private:
  float frame_time_diff_ = 0.04F;
  size_t counter = 0UL;
  rclcpp::Subscription<sensing_msgs::msg::ImuData>::SharedPtr subscriber_;

  void callback(const sensing_msgs::msg::ImuData::SharedPtr msg);
  void callback_with_trigger(const sensing_msgs::msg::ImuData::SharedPtr &msg);
};

class OgmPointsSubscriber : public SingleSubscriber {
public:
  explicit OgmPointsSubscriber(rclcpp::Node::SharedPtr node);
  ~OgmPointsSubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;
  void sub_and_trigger(const std::string &topic, const std::string &key, const float &latency, 
                      const float &frame_time_diff) override;

private:
  float frame_time_diff_ = 0.04F;
  size_t counter = 0UL;
  rclcpp::Subscription<perception_msgs::msg::OgmPoints>::SharedPtr subscriber_;

  void callback(const perception_msgs::msg::OgmPoints::SharedPtr msg);
  void callback_with_trigger(const perception_msgs::msg::OgmPoints::SharedPtr &msg);
};

class ObjectsSubscriber : public SingleSubscriber {
public:
  explicit ObjectsSubscriber(rclcpp::Node::SharedPtr node);
  ~ObjectsSubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;
  void sub_and_trigger(const std::string &topic, const std::string &key, const float &latency, 
                      const float &frame_time_diff) override;

private:
  float frame_time_diff_ = 0.04F;
  size_t counter = 0UL;
  rclcpp::Subscription<perception_msgs::msg::Objects>::SharedPtr subscriber_;

  void callback(const perception_msgs::msg::Objects::SharedPtr msg);
  void callback_with_trigger(const perception_msgs::msg::Objects::SharedPtr &msg);
};

class TargetPoseSubscriber : public SingleSubscriber {
public:
  explicit TargetPoseSubscriber(rclcpp::Node::SharedPtr node);
  ~TargetPoseSubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;
  void sub_and_trigger(const std::string &topic, const std::string &key, const float &latency, 
                      const float &frame_time_diff) override;

private:
  float frame_time_diff_ = 0.04F;
  size_t counter = 0UL;
  rclcpp::Subscription<perception_task_msgs::msg::TargetPose>::SharedPtr subscriber_;

  void callback(const perception_task_msgs::msg::TargetPose::SharedPtr msg);
  void callback_with_trigger(const perception_task_msgs::msg::TargetPose::SharedPtr &msg);
};

class GpsSubscriber : public SingleSubscriber {
public:
  explicit GpsSubscriber(rclcpp::Node::SharedPtr node);
  ~GpsSubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;
  void sub_and_trigger(const std::string &topic, const std::string &key, const float &latency, 
                      const float &frame_time_diff) override;

private:
  float frame_time_diff_ = 0.04F;
  size_t counter = 0UL;
  rclcpp::Subscription<sensing_msgs::msg::RtkData>::SharedPtr subscriber_;

  void callback(const sensing_msgs::msg::RtkData::SharedPtr msg);
  void callback_with_trigger(const sensing_msgs::msg::RtkData::SharedPtr &msg);
};

class SlamOdometrySubscriber : public SingleSubscriber {
public:
  explicit SlamOdometrySubscriber(rclcpp::Node::SharedPtr node);
  ~SlamOdometrySubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;
  void sub_and_trigger(const std::string &topic, const std::string &key, const float &latency, 
                      const float &frame_time_diff) override;

private:
  float frame_time_diff_ = 0.04F;
  size_t counter = 0UL;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr subscriber_;

  void callback(const nav_msgs::msg::Odometry::SharedPtr msg);
  void callback_with_trigger(const nav_msgs::msg::Odometry::SharedPtr &msg);
};

class FusionOdometrySubscriber : public SingleSubscriber {
public:
  explicit FusionOdometrySubscriber(rclcpp::Node::SharedPtr node);
  ~FusionOdometrySubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;
  void sub_and_trigger(const std::string &topic, const std::string &key, const float &latency, 
                      const float &frame_time_diff) override;

private:
  float frame_time_diff_ = 0.04F;
  size_t counter = 0UL;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr subscriber_;

  void callback(const nav_msgs::msg::Odometry::SharedPtr msg);
  void callback_with_trigger(const nav_msgs::msg::Odometry::SharedPtr &msg);
};

class GlobalPathSubscriber : public SingleSubscriber {
public:
  explicit GlobalPathSubscriber(rclcpp::Node::SharedPtr node);
  ~GlobalPathSubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;
  void sub_and_trigger(const std::string &topic, const std::string &key, const float &latency, 
                      const float &frame_time_diff) override;

private:
  float frame_time_diff_ = 0.04F;
  size_t counter = 0UL;
  rclcpp::Subscription<planning_msgs::msg::TrajectoryPoints>::SharedPtr subscriber_;

  void callback(const planning_msgs::msg::TrajectoryPoints::SharedPtr msg);
  void callback_with_trigger(const planning_msgs::msg::TrajectoryPoints::SharedPtr &msg);
};

class LocalPathSubscriber : public SingleSubscriber {
public:
  explicit LocalPathSubscriber(rclcpp::Node::SharedPtr node);
  ~LocalPathSubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;
  void sub_and_trigger(const std::string &topic, const std::string &key, const float &latency, 
                      const float &frame_time_diff) override;

private:
  float frame_time_diff_ = 0.04F;
  size_t counter = 0UL;
  rclcpp::Subscription<planning_msgs::msg::LocalTrajectoryPoints>::SharedPtr subscriber_;

  void callback(const planning_msgs::msg::LocalTrajectoryPoints::SharedPtr msg);
  void callback_with_trigger(const planning_msgs::msg::LocalTrajectoryPoints::SharedPtr &msg);
};

class LocalStatusSubscriber : public SingleSubscriber {
public:
  explicit LocalStatusSubscriber(rclcpp::Node::SharedPtr node);
  ~LocalStatusSubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;
  void sub_and_trigger(const std::string &topic, const std::string &key, const float &latency, 
                      const float &frame_time_diff) override;

private:
  float frame_time_diff_ = 0.04F;
  size_t counter = 0UL;
  rclcpp::Subscription<planning_msgs::msg::TrajectoryState>::SharedPtr subscriber_;

  void callback(const planning_msgs::msg::TrajectoryState::SharedPtr msg);
  void callback_with_trigger(const planning_msgs::msg::TrajectoryState::SharedPtr &msg);
};

class ControlSubscriber : public SingleSubscriber {
public:
  explicit ControlSubscriber(rclcpp::Node::SharedPtr node);
  ~ControlSubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;
  void sub_and_trigger(const std::string &topic, const std::string &key, const float &latency, 
                      const float &frame_time_diff) override;

private:
  float frame_time_diff_ = 0.04F;
  size_t counter = 0UL;
  rclcpp::Subscription<control_msgs::msg::PathspeedctrlInterface>::SharedPtr subscriber_;

  void callback(const control_msgs::msg::PathspeedctrlInterface::SharedPtr msg);
  void callback_with_trigger(const control_msgs::msg::PathspeedctrlInterface::SharedPtr &msg);
};

class CarOriSubscriber : public SingleSubscriber {
public:
  explicit CarOriSubscriber(rclcpp::Node::SharedPtr node);
  ~CarOriSubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;
  void sub_and_trigger(const std::string &topic, const std::string &key, const float &latency, 
                      const float &frame_time_diff) override;

private:
  float frame_time_diff_ = 0.04F;
  size_t counter = 0UL;
  rclcpp::Subscription<chassis_msgs::msg::CarOriInterface>::SharedPtr subscriber_;

  void callback(const chassis_msgs::msg::CarOriInterface::SharedPtr msg);
  void callback_with_trigger(const chassis_msgs::msg::CarOriInterface::SharedPtr &msg);
};

class CrossGoalSubscriber : public SingleSubscriber {
public:
  explicit CrossGoalSubscriber(rclcpp::Node::SharedPtr node);
  ~CrossGoalSubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;
  void sub_and_trigger(const std::string &topic, const std::string &key, const float &latency, 
                      const float &frame_time_diff) override;

private:
  float frame_time_diff_ = 0.04F;
  size_t counter = 0UL;
  rclcpp::Subscription<control_msgs::msg::CrossGoal>::SharedPtr subscriber_;

  void callback(const control_msgs::msg::CrossGoal::SharedPtr msg);
  void callback_with_trigger(const control_msgs::msg::CrossGoal::SharedPtr &msg);
};

class ArmOriSubscriber : public SingleSubscriber {
public:
  explicit ArmOriSubscriber(rclcpp::Node::SharedPtr node);
  ~ArmOriSubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;
  void sub_and_trigger(const std::string &topic, const std::string &key, const float &latency, 
                      const float &frame_time_diff) override;

private:
  float frame_time_diff_ = 0.04F;
  size_t counter = 0UL;
  rclcpp::Subscription<chassis_msgs::msg::ArmData>::SharedPtr subscriber_;

  void callback(const chassis_msgs::msg::ArmData::SharedPtr msg);
  void callback_with_trigger(const chassis_msgs::msg::ArmData::SharedPtr &msg);
};

class ForkTaskStateSubscriber : public SingleSubscriber {
public:
  explicit ForkTaskStateSubscriber(rclcpp::Node::SharedPtr node);
  ~ForkTaskStateSubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;
  void sub_and_trigger(const std::string &topic, const std::string &key, const float &latency, 
                      const float &frame_time_diff) override;

private:
  float frame_time_diff_ = 0.04F;
  size_t counter = 0UL;
  rclcpp::Subscription<control_task_msgs::msg::TaskState>::SharedPtr subscriber_;

  void callback(const control_task_msgs::msg::TaskState::SharedPtr msg);
  void callback_with_trigger(const control_task_msgs::msg::TaskState::SharedPtr &msg);
};

class ForkControlSubscriber : public SingleSubscriber {
public:
  explicit ForkControlSubscriber(rclcpp::Node::SharedPtr node);
  ~ForkControlSubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;
  void sub_and_trigger(const std::string &topic, const std::string &key, const float &latency, 
                      const float &frame_time_diff) override;

private:
  float frame_time_diff_ = 0.04F;
  size_t counter = 0UL;
  rclcpp::Subscription<chassis_msgs::msg::ForkControl>::SharedPtr subscriber_;

  void callback(const chassis_msgs::msg::ForkControl::SharedPtr msg);
  void callback_with_trigger(const chassis_msgs::msg::ForkControl::SharedPtr &msg);
};
 
class GoalSubscriber : public SingleSubscriber {
public:
  explicit GoalSubscriber(rclcpp::Node::SharedPtr node);
  ~GoalSubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;
  void sub_and_trigger(const std::string &topic, const std::string &key, const float &latency, 
                      const float &frame_time_diff) override;

private:
  float frame_time_diff_ = 0.04F;
  size_t counter = 0UL;
  rclcpp::Subscription<control_task_msgs::msg::TaskGoalData>::SharedPtr subscriber_;

  void callback(const control_task_msgs::msg::TaskGoalData::SharedPtr msg);
  void callback_with_trigger(const control_task_msgs::msg::TaskGoalData::SharedPtr &msg);
};

class TaskTypeSubscriber : public SingleSubscriber {
public:
  explicit TaskTypeSubscriber(rclcpp::Node::SharedPtr node);
  ~TaskTypeSubscriber() override = default;
  [[nodiscard]] std::string get_class_name() const override;

  void sub(const std::string &topic, const std::string &key, const float &latency,
           const rclcpp::QoS &qos = rclcpp::SensorDataQoS()) override;

  void sub(const float latency, const float frame_time_diff) override;
  void sub(const std::string topic, const float latency, const float frame_time_diff) override;
  void sub_and_trigger(const std::string &topic, const std::string &key, const float &latency, 
                      const float &frame_time_diff) override;

private:
  float frame_time_diff_ = 0.04F;
  size_t counter = 0UL;
  rclcpp::Subscription<control_task_msgs::msg::TaskType>::SharedPtr subscriber_;

  void callback(const control_task_msgs::msg::TaskType::SharedPtr msg);
  void callback_with_trigger(const control_task_msgs::msg::TaskType::SharedPtr &msg);
};

// REGISTER_SUBSCRIBER("ImuSubscriber", ImuSubscriber)
REGISTER_SUBSCRIBER("IMU", ImuSubscriber)

// REGISTER_SUBSCRIBER("OgmPointsSubscriber", OgmPointsSubscriber)
REGISTER_SUBSCRIBER("OGMPOINTS", OgmPointsSubscriber)

// REGISTER_SUBSCRIBER("ObjectsSubscriber", ObjectsSubscriber)
REGISTER_SUBSCRIBER("OBJECTS", ObjectsSubscriber)

// REGISTER_SUBSCRIBER("TargetPoseSubscriber", TargetPoseSubscriber)
REGISTER_SUBSCRIBER("LOCALPERCEPTION", TargetPoseSubscriber)

// REGISTER_SUBSCRIBER("GpsSubscriber", GpsSubscriber)
REGISTER_SUBSCRIBER("GPSLOCATION", GpsSubscriber)

// REGISTER_SUBSCRIBER("SlamOdometrySubscriber", SlamOdometrySubscriber)
REGISTER_SUBSCRIBER("SLAMLOCATION", SlamOdometrySubscriber)

// REGISTER_SUBSCRIBER("FusionOdometrySubscriber", FusionOdometrySubscriber)
REGISTER_SUBSCRIBER("FUSIONLOCATION", FusionOdometrySubscriber)

// REGISTER_SUBSCRIBER("GlobalPathSubscriber", GlobalPathSubscriber)
REGISTER_SUBSCRIBER("GLOBALPATH", GlobalPathSubscriber)

// REGISTER_SUBSCRIBER("LocalPathSubscriber", LocalPathSubscriber)
REGISTER_SUBSCRIBER("LOCALPATH", LocalPathSubscriber)

// REGISTER_SUBSCRIBER("LocalStatusSubscriber", LocalStatusSubscriber)
REGISTER_SUBSCRIBER("LOCALPATHSTATE", LocalStatusSubscriber)

// REGISTER_SUBSCRIBER("ControlSubscriber", ControlSubscriber)
REGISTER_SUBSCRIBER("CONTROL", ControlSubscriber)

// REGISTER_SUBSCRIBER("CarOriSubscriber", CarOriSubscriber)
REGISTER_SUBSCRIBER("CARORI", CarOriSubscriber)

// REGISTER_SUBSCRIBER("CrossGoalSubscriber", CrossGoalSubscriber)
REGISTER_SUBSCRIBER("CROSSGOAL", CrossGoalSubscriber)

// REGISTER_SUBSCRIBER("ArmOriSubscriber", ArmOriSubscriber)
REGISTER_SUBSCRIBER("ARMINFO", ArmOriSubscriber)

// REGISTER_SUBSCRIBER("ForkTaskStateSubscriber", ForkTaskStateSubscriber)
REGISTER_SUBSCRIBER("ARMTASKSTATE", ForkTaskStateSubscriber)

// REGISTER_SUBSCRIBER("ForkControlSubscriber", ForkControlSubscriber)
REGISTER_SUBSCRIBER("ARMCONTROL", ForkControlSubscriber)

// REGISTER_SUBSCRIBER("GoalSubscriber", GoalSubscriber)
REGISTER_SUBSCRIBER("TASKGOAL", GoalSubscriber)

// REGISTER_SUBSCRIBER("TaskTypeSubscriber", TaskTypeSubscriber)
REGISTER_SUBSCRIBER("TASKTYPE", TaskTypeSubscriber)
}
}