#include "common/subscriber/base_subscriber.hpp"

namespace tju {
namespace common {
std::mutex lock;
std::condition_variable cv;
std::chrono::steady_clock::time_point last_trigger_time;
bool ready = false;
// SingleSubscriber 实现
SingleSubscriber::SingleSubscriber(rclcpp::Node::SharedPtr node)
    : latency_(0.2), node_(std::move(node)) {}

void SingleSubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                      const float &latency, const float& frame_time_diff) {
  // NTWARNING << "Only Lidar subscriber support trigger";
  NTINFO << "Node: " << node_->get_name() << " [Init] Subscriber  using trigger mode: " << key;
}

void SingleSubscriber::diagnostic(const double &msg_time, const int32_t &code) {
  const double time_now = node_->get_clock()->now().seconds();
  if (msg_time > time_now) {
    tju::diagnosis::report(code);
    NTWARNING << "Node: " << std::string(node_->get_name()) << " [" << get_class_name() << "] " << key_ 
             << " msgs time: " << msg_time << " > " << " time now: " << time_now;
  } else {
    tju::diagnosis::restore(code);
  }
}

void SingleSubscriber::diagnostic(const double &msg_time, const float &latency, const int32_t &code) {
  double c_time = node_->get_clock()->now().seconds();
  if (c_time - msg_time > latency) {
    tju::diagnosis::report(code);
    NTWARNING << "Node: " << std::string(node_->get_name()) << "[" << get_class_name() << "] " << key_ 
             << " latency: " << c_time - msg_time << "s" << " > " << latency << "s" << "     " << code;
  } else {
    tju::diagnosis::restore(code);
  }
}

void SingleSubscriber::diagnostic(const bool data_error, const int32_t &code) {
  if (data_error) {
    tju::diagnosis::report(code);
    NTWARNING << "Node: " << std::string(node_->get_name()) << "[" << get_class_name() << "] " << key_ 
             << " msgs data error!";
  } else {
    tju::diagnosis::restore(code);
  }
}

// SingleSubscriberRegistry 实现
SingleSubscriberRegistry &SingleSubscriberRegistry::Get() {
  static SingleSubscriberRegistry instance;
  return instance;
}

void SingleSubscriberRegistry::Register(const std::string &name,
                                       std::function<std::unique_ptr<SingleSubscriber>(rclcpp::Node::SharedPtr)> factory) {
  std::lock_guard<std::mutex> lock(mutex_);
  factories_[name] = std::move(factory);
}

std::unique_ptr<SingleSubscriber> SingleSubscriberRegistry::Create(const std::string &name, 
                                                                    rclcpp::Node::SharedPtr node) {
  std::lock_guard<std::mutex> lock(mutex_);
  if (auto it = factories_.find(name); it != factories_.end()) {
    return it->second(std::move(node));
  }
  NTWARNING << "No factory for " << name;
  return nullptr;
}

}  // namespace common
}  // namespace tju