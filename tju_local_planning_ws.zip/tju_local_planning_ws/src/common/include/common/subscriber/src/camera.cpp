#include "common/subscriber/camera.hpp"

namespace tju {
namespace common {

// --------------------------- CameraSubscriber 实现 ---------------------------
CameraSubscriber::CameraSubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

std::string CameraSubscriber::get_class_name() const {
    return "CameraSubscriber";
}

void CameraSubscriber::sub(const std::string &topic, const std::string &key, const float &latency, 
                           const rclcpp::QoS &qos) {
    key_ = key;
    latency_ = latency;
    subscriber_ = node_->create_subscription<sensor_msgs::msg::Image>(
        topic, qos,
        [this](const sensor_msgs::msg::Image::SharedPtr msg) { this->callback(msg); });
}

void CameraSubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                       const float &latency, const float &frame_time_diff) {
    key_ = key;
    latency_ = latency;
    subscriber_ = node_->create_subscription<sensor_msgs::msg::Image>(
        topic, rclcpp::QoS(1),
        [this](const sensor_msgs::msg::Image::SharedPtr msg) { this->callback_with_trigger(msg); });
}

void CameraSubscriber::sub(const float latency, const float frame_time_diff) {
    NTFATAL << "Node: " << GET_NODE_NAME() << " [Init] No pre-defined topic for CameraSubscriber";
}

void CameraSubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    NTFATAL << "Node: " << GET_NODE_NAME() << " [Init] No frame_time_diff for CameraSubscriber";
}

void CameraSubscriber::callback(const sensor_msgs::msg::Image::SharedPtr msg) {
    const double t = rclcpp::Time(msg->header.stamp).seconds();
    this->diagnostic(t, ErrorCode::DATA_IMAGE_TIME_ABNORMAL);
    this->diagnostic(t, latency_, ErrorCode::DATA_IMAGE_TIME_DELAY);
    this->diagnostic(msg->data.empty(), ErrorCode::DATA_IMAGE_EMPTY);
    PUSH_SENSOR_DATA(key_, "origin", t, msg);
}

void CameraSubscriber::callback_with_trigger(const sensor_msgs::msg::Image::SharedPtr &msg) {
    this->callback(msg);
    std::lock_guard<std::mutex> lk(lock);
    last_trigger_time = std::chrono::steady_clock::now();
    ready = true;
    cv.notify_all();
}


// --------------------------- CameraInfoSubscriber 实现 ---------------------------
CameraInfoSubscriber::CameraInfoSubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

std::string CameraInfoSubscriber::get_class_name() const {
    return "-";
}

void CameraInfoSubscriber::sub(const std::string &topic, const std::string &key, const float &latency, 
                               const rclcpp::QoS &qos) {
    key_ = key;
    latency_ = latency;
    subscriber_ = node_->create_subscription<sensor_msgs::msg::CameraInfo>(
        topic, qos,
        [this](const sensor_msgs::msg::CameraInfo::SharedPtr msg) { this->callback(msg); });
}

void CameraInfoSubscriber::sub(const float latency, const float frame_time_diff) {
    NTFATAL << "Node: " << GET_NODE_NAME() << " [Init] No pre-defined topic for CameraInfoSubscriber";
}

void CameraInfoSubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    NTFATAL << "Node: " << GET_NODE_NAME() << " [Init] No frame_time_diff for CameraInfoSubscriber";
}

void CameraInfoSubscriber::callback(const sensor_msgs::msg::CameraInfo::SharedPtr &msg) {
    auto ret = SET_CAMERA_INTRINSICS(key_, msg);
    if (ret != ErrorCode::OK) {
        NTFATAL << "Node: " << GET_NODE_NAME() << " [Run][CameraInfoSubscriber] Camera info" << key_ << " set failed: " << ret;
    } else {
        NTINFO << "Node: " << GET_NODE_NAME() << " [Run][CameraInfoSubscriber] Camera info " << key_ << " set successfully. Sub shutdown.";
        subscriber_.reset();
    }
}

}  // namespace common
}  // namespace tju