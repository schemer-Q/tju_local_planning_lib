#include "common/subscriber/lidar_subscriber.hpp"

namespace tju {
namespace common {

// --------------------------- LidarSubscriber 构造函数 ---------------------------
LidarSubscriber::LidarSubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

// --------------------------- 虚函数实现 ---------------------------
std::string LidarSubscriber::get_class_name() const {
    return "LidarSubscriber";
}

void LidarSubscriber::sub(const std::string &topic, const std::string &key, const float &latency, 
                          const rclcpp::QoS &qos) {
    key_ = key;
    latency_ = latency;
    subscriber_ = node_->create_subscription<sensor_msgs::msg::PointCloud2>(
        topic, qos,
        [this](const sensor_msgs::msg::PointCloud2::SharedPtr msg) { this->callback(msg); });
}

void LidarSubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                      const float &latency, const float &frame_time_diff) {
    key_ = key;
    latency_ = latency;
    subscriber_ = node_->create_subscription<sensor_msgs::msg::PointCloud2>(
        topic, rclcpp::QoS(1),
        [this](const sensor_msgs::msg::PointCloud2::SharedPtr msg) { this->callback_with_trigger(msg); });
}

void LidarSubscriber::sub(const float latency, const float frame_time_diff) {
    NTFATAL << "Node: " << GET_NODE_NAME() << " [Init] No pre-defined topic for LidarSubscriber";
}

void LidarSubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    NTFATAL << "Node: " << GET_NODE_NAME() << " [Init] No frame_time_diff topic for LidarSubscriber";
}

// --------------------------- 私有成员函数实现 ---------------------------
void LidarSubscriber::callback(const sensor_msgs::msg::PointCloud2::SharedPtr msg) {
    timer_.Reset();
    const double msg_time = rclcpp::Time(msg->header.stamp).seconds();
    
    // 诊断时间戳异常
    this->diagnostic(msg_time, ErrorCode::DATA_POINTCLOUD_TIME_ABNORMAL);
    // 诊断时间延迟过大
    this->diagnostic(msg_time, latency_, ErrorCode::DATA_POINTCLOUD_TIME_DELAY);
    // 诊断点云数据异常（数据为空）
    this->diagnostic(msg->data.empty(), ErrorCode::DATA_POINTCLOUD_POINT_NUM_ABNORMAL);
    
    const auto elapsed_time = timer_.Elapsed();
    // NTINFO << "LidarSubscriber: " << key_ << ", cloud size: " << msg->data.size() << ", time: " << elapsed_time << " ms";
    PUSH_SENSOR_DATA(key_, "origin", msg_time, msg);
}

void LidarSubscriber::callback_with_trigger(const sensor_msgs::msg::PointCloud2::SharedPtr &msg) {
    this->callback(msg);
    std::lock_guard<std::mutex> lk(lock);
    last_trigger_time = std::chrono::steady_clock::now();
    ready = true;
    cv.notify_all();
}

}  // namespace common
}  // namespace tju