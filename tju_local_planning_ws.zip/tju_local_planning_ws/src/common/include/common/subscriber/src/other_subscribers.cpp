#include "common/subscriber/other_subscribers.hpp"

namespace tju {
namespace common {

//***********************************************************************
ImuSubscriber::ImuSubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

// 获取类名实现
std::string ImuSubscriber::get_class_name() const {
    return "ImuSubscriber";
}

// 订阅函数实现
void ImuSubscriber::sub(const std::string &topic, const std::string &key, const float &latency,
                       const rclcpp::QoS &qos) {
    std::cout << "Node: " << node_->get_name() << " [Init] ImuSubscriber only support using pre-defined topic.";
    sub(latency, 0.04F);
}

void ImuSubscriber::sub(const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    std::string topic = "/location/odometry";
    std::string key = "/smartcar/sensors/rtk/gnss_topic";
    
    if (node_->has_parameter(key)) {
        topic = node_->get_parameter(key).as_string();
    }
    
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();

    subscriber_ = node_->create_subscription<sensing_msgs::msg::ImuData>(
        topic, qos,
        [this](const sensing_msgs::msg::ImuData::SharedPtr msg) { this->callback(msg); });
}

void ImuSubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    std::cout << "Node: " << node_->get_name() << " [Init] ImuSubscriber.";
    
    subscriber_ = node_->create_subscription<sensing_msgs::msg::ImuData>(
        topic, qos,
        [this](const sensing_msgs::msg::ImuData::SharedPtr msg) { this->callback(msg); });
}

void ImuSubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                    const float &latency, const float &frame_time_diff) {
    key_ = key;
    latency_ = latency;
    
    subscriber_ = node_->create_subscription<sensing_msgs::msg::ImuData>(
        topic, rclcpp::QoS(1),
        [this](const sensing_msgs::msg::ImuData::SharedPtr msg) { this->callback_with_trigger(msg); });
}

// 回调函数实现
void ImuSubscriber::callback(const sensing_msgs::msg::ImuData::SharedPtr msg) {
    const double msg_t = rclcpp::Time(msg->header.stamp).seconds();

    counter += 1UL;
    if (counter % 10 == 0) {
        this->diagnostic(msg_t, ErrorCode::DATA_IMU_TIME_ABNORMAL);
        this->diagnostic(msg_t, latency_, ErrorCode::DATA_IMU_TIME_DELAY);
    }

    std::shared_ptr<ImuData> data = std::make_shared<ImuData>(msg_t, msg);
    const double latest_time = GET_LATEST_SENSOR_DATA_TIME(ImuData, "IMU", data);
    const double dt = msg_t - latest_time;
    
    if (dt > frame_time_diff_) {
        diagnosis::report(ErrorCode::DATA_IMU_FRAME_TIME_ERROR);
        NTWARNING << "Node: " << node_->get_name() << " [" << get_class_name() << "] frame time diff:" << dt;
    } else {
        diagnosis::restore(ErrorCode::DATA_IMU_FRAME_TIME_ERROR);
    }
    
    PUSH_GENERIC_DATA(ImuData, "IMU", data);
}

void ImuSubscriber::callback_with_trigger(const sensing_msgs::msg::ImuData::SharedPtr &msg) {
    this->callback(msg);
    
    std::lock_guard<std::mutex> lk(lock);
    last_trigger_time = std::chrono::steady_clock::now();
    ready = true;
    cv.notify_all();
}

//***********************************************************************

// 构造函数实现
OgmPointsSubscriber::OgmPointsSubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

// 获取类名实现
std::string OgmPointsSubscriber::get_class_name() const {
    return "OgmPointsSubscriber";
}

// 订阅函数实现
void OgmPointsSubscriber::sub(const std::string &topic, const std::string &key, const float &latency,
                             const rclcpp::QoS &qos) {
    std::cout << "Node: " << node_->get_name() << " [Init] OgmPointsSubscriber only support using pre-defined topic.";
    sub(latency, 0.04F);
}

void OgmPointsSubscriber::sub(const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    std::string topic = "/location/odometry";
    std::string key = "/smartcar/sensors/rtk/gnss_topic";
    
    if (node_->has_parameter(key)) {
        topic = node_->get_parameter(key).as_string();
    }
    
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();

    subscriber_ = node_->create_subscription<perception_msgs::msg::OgmPoints>(
        topic, qos,
        [this](const perception_msgs::msg::OgmPoints::SharedPtr msg) { this->callback(msg); });
}

void OgmPointsSubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    std::cout << "Node: " << node_->get_name() << " [Init] OgmPointsSubscriber.";
    
    subscriber_ = node_->create_subscription<perception_msgs::msg::OgmPoints>(
        topic, qos,
        [this](const perception_msgs::msg::OgmPoints::SharedPtr msg) { this->callback(msg); });
}

void OgmPointsSubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                         const float &latency, const float &frame_time_diff) {
    key_ = key;
    latency_ = latency;
    
    subscriber_ = node_->create_subscription<perception_msgs::msg::OgmPoints>(
        topic, rclcpp::QoS(1),
        [this](const perception_msgs::msg::OgmPoints::SharedPtr msg) { this->callback_with_trigger(msg); });
}

// 回调函数实现
void OgmPointsSubscriber::callback(const perception_msgs::msg::OgmPoints::SharedPtr msg) {
    const double msg_t = rclcpp::Time(msg->header.stamp).seconds();

    counter += 1UL;
    if (counter % 10 == 0) {
        this->diagnostic(msg_t, ErrorCode::DATA_OGM_DETECTION_TIME_ABNORMAL);
        this->diagnostic(msg_t, latency_, ErrorCode::DATA_OGM_DETECTION_TIME_DELAY);
    }

    std::shared_ptr<OgmPointsData> data = std::make_shared<OgmPointsData>(msg_t, msg);
    const double latest_time = GET_LATEST_SENSOR_DATA_TIME(OgmPointsData, "OGMPOINTS", data);
    const double dt = msg_t - latest_time;
    
    if (dt > frame_time_diff_) {
        diagnosis::report(ErrorCode::DATA_OGM_DETECTION_FRAME_TIME_ERROR);
        NTWARNING << "Node: " << node_->get_name() << " [" << get_class_name() << "] frame time diff:" << dt;
    } else {
        diagnosis::restore(ErrorCode::DATA_OGM_DETECTION_FRAME_TIME_ERROR);
    }
    
    PUSH_GENERIC_DATA(OgmPointsData, "OGMPOINTS", data);
}

void OgmPointsSubscriber::callback_with_trigger(const perception_msgs::msg::OgmPoints::SharedPtr &msg) {
    this->callback(msg);
    
    std::lock_guard<std::mutex> lk(lock);
    last_trigger_time = std::chrono::steady_clock::now();
    ready = true;
    cv.notify_all();
}
//***********************************************************************
// 构造函数实现
ObjectsSubscriber::ObjectsSubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

// 获取类名实现
std::string ObjectsSubscriber::get_class_name() const {
    return "ObjectsSubscriber";
}

// 订阅函数实现
void ObjectsSubscriber::sub(const std::string &topic, const std::string &key, const float &latency,
                           const rclcpp::QoS &qos) {
    std::cout << "Node: " << node_->get_name() << " [Init] ObjectsSubscriber only support using pre-defined topic.";
    sub(latency, 0.04F);
}

void ObjectsSubscriber::sub(const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    std::string topic = "/location/odometry";
    std::string key = "/smartcar/sensors/rtk/gnss_topic";
    
    if (node_->has_parameter(key)) {
        topic = node_->get_parameter(key).as_string();
    }
    
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();

    subscriber_ = node_->create_subscription<perception_msgs::msg::Objects>(
        topic, qos,
        [this](const perception_msgs::msg::Objects::SharedPtr msg) { this->callback(msg); });
}

void ObjectsSubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    std::cout << "Node: " << node_->get_name() << " [Init] ObjectsSubscriber.";
    
    subscriber_ = node_->create_subscription<perception_msgs::msg::Objects>(
        topic, qos,
        [this](const perception_msgs::msg::Objects::SharedPtr msg) { this->callback(msg); });
}

void ObjectsSubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                        const float &latency, const float &frame_time_diff) {
    key_ = key;
    latency_ = latency;
    
    subscriber_ = node_->create_subscription<perception_msgs::msg::Objects>(
        topic, rclcpp::QoS(1),
        [this](const perception_msgs::msg::Objects::SharedPtr msg) { this->callback_with_trigger(msg); });
}

// 回调函数实现
void ObjectsSubscriber::callback(const perception_msgs::msg::Objects::SharedPtr msg) {
    const double msg_t = rclcpp::Time(msg->header.stamp).seconds();

    counter += 1UL;
    if (counter % 10 == 0) {
        this->diagnostic(msg_t, ErrorCode::DATA_OBJECTS_DETECTION_TIME_ABNORMAL);
        this->diagnostic(msg_t, latency_, ErrorCode::DATA_OBJECTS_DETECTION_TIME_DELAY);
    }

    std::shared_ptr<ObjectsData> data = std::make_shared<ObjectsData>(msg_t, msg);
    const double latest_time = GET_LATEST_SENSOR_DATA_TIME(ObjectsData, "OBJECTS", data);
    const double dt = msg_t - latest_time;
    
    if (dt > frame_time_diff_) {
        diagnosis::report(ErrorCode::DATA_OBJECTS_DETECTION_FRAME_TIME_ERROR);
        NTWARNING << "Node: " << node_->get_name() << " [" << get_class_name() << "] frame time diff:" << dt;
    } else {
        diagnosis::restore(ErrorCode::DATA_OBJECTS_DETECTION_FRAME_TIME_ERROR);
    }
    
    PUSH_GENERIC_DATA(ObjectsData, "OBJECTS", data);
}

void ObjectsSubscriber::callback_with_trigger(const perception_msgs::msg::Objects::SharedPtr &msg) {
    this->callback(msg);
    
    std::lock_guard<std::mutex> lk(lock);
    last_trigger_time = std::chrono::steady_clock::now();
    ready = true;
    cv.notify_all();
}

//***********************************************************************
// 构造函数实现
TargetPoseSubscriber::TargetPoseSubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

// 获取类名实现
std::string TargetPoseSubscriber::get_class_name() const {
    return "TargetPoseSubscriber";
}

// 订阅函数实现
void TargetPoseSubscriber::sub(const std::string &topic, const std::string &key, const float &latency,
                               const rclcpp::QoS &qos) {
    std::cout << "Node: " << node_->get_name() << " [Init] TargetPoseSubscriber only support using pre-defined topic.";
    sub(latency, 0.04F);
}

void TargetPoseSubscriber::sub(const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    std::string topic = "/location/odometry";
    std::string key = "/smartcar/sensors/rtk/gnss_topic";
    
    if (node_->has_parameter(key)) {
        topic = node_->get_parameter(key).as_string();
    }
    
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();

    subscriber_ = node_->create_subscription<perception_task_msgs::msg::TargetPose>(
        topic, qos,
        [this](const perception_task_msgs::msg::TargetPose::SharedPtr msg) { this->callback(msg); });
}

void TargetPoseSubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    std::cout << "Node: " << node_->get_name() << " [Init] TargetPoseSubscriber.";
    
    subscriber_ = node_->create_subscription<perception_task_msgs::msg::TargetPose>(
        topic, qos,
        [this](const perception_task_msgs::msg::TargetPose::SharedPtr msg) { this->callback(msg); });
}

void TargetPoseSubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                           const float &latency, const float &frame_time_diff) {
    key_ = key;
    latency_ = latency;
    
    subscriber_ = node_->create_subscription<perception_task_msgs::msg::TargetPose>(
        topic, rclcpp::QoS(1),
        [this](const perception_task_msgs::msg::TargetPose::SharedPtr msg) { this->callback_with_trigger(msg); });
}

// 回调函数实现
void TargetPoseSubscriber::callback(const perception_task_msgs::msg::TargetPose::SharedPtr msg) {
    const double msg_t = rclcpp::Time(msg->header.stamp).seconds();

    counter += 1UL;
    if (counter % 10 == 0) {
        this->diagnostic(msg_t, ErrorCode::DATA_LOCAL_DETECTION_TIME_ABNORMAL);
        this->diagnostic(msg_t, latency_, ErrorCode::DATA_LOCAL_DETECTION_TIME_DELAY);
    }

    std::shared_ptr<TargetPoseData> data = std::make_shared<TargetPoseData>(msg_t, msg);
    const double latest_time = GET_LATEST_SENSOR_DATA_TIME(TargetPoseData, "LOCALPERCEPTION", data);
    const double dt = msg_t - latest_time;
    
    if (dt > frame_time_diff_) {
        diagnosis::report(ErrorCode::DATA_LOCAL_DETECTION_FRAME_TIME_ERROR);
        NTWARNING << "Node: " << node_->get_name() << " [" << get_class_name() << "] frame time diff:" << dt;
    } else {
        diagnosis::restore(ErrorCode::DATA_LOCAL_DETECTION_FRAME_TIME_ERROR);
    }
    
    PUSH_GENERIC_DATA(TargetPoseData, "LOCALPERCEPTION", data);
}

void TargetPoseSubscriber::callback_with_trigger(const perception_task_msgs::msg::TargetPose::SharedPtr &msg) {
    this->callback(msg);
    
    std::lock_guard<std::mutex> lk(lock);
    last_trigger_time = std::chrono::steady_clock::now();
    ready = true;
    cv.notify_all();
}
//***********************************************************************
// 构造函数实现
GpsSubscriber::GpsSubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

// 获取类名实现
std::string GpsSubscriber::get_class_name() const {
    return "GpsSubscriber";
}

// 订阅函数实现
void GpsSubscriber::sub(const std::string &topic, const std::string &key, const float &latency,
                       const rclcpp::QoS &qos) {
    std::cout << "Node: " << node_->get_name() << " [Init] GpsSubscriber only support using pre-defined topic.";
    sub(latency, 0.04F);
}

void GpsSubscriber::sub(const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    std::string topic = "/location/odometry";
    std::string key = "/smartcar/sensors/rtk/gnss_topic";
    
    if (node_->has_parameter(key)) {
        topic = node_->get_parameter(key).as_string();
    }
    
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();

    subscriber_ = node_->create_subscription<sensing_msgs::msg::RtkData>(
        topic, qos,
        [this](const sensing_msgs::msg::RtkData::SharedPtr msg) { this->callback(msg); });
}

void GpsSubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    std::cout << "Node: " << node_->get_name() << " [Init] GpsSubscriber.";
    
    subscriber_ = node_->create_subscription<sensing_msgs::msg::RtkData>(
        topic, qos,
        [this](const sensing_msgs::msg::RtkData::SharedPtr msg) { this->callback(msg); });
}

void GpsSubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                    const float &latency, const float &frame_time_diff) {
    key_ = key;
    latency_ = latency;
    
    subscriber_ = node_->create_subscription<sensing_msgs::msg::RtkData>(
        topic, rclcpp::QoS(1),
        [this](const sensing_msgs::msg::RtkData::SharedPtr msg) { this->callback_with_trigger(msg); });
}

// 回调函数实现
void GpsSubscriber::callback(const sensing_msgs::msg::RtkData::SharedPtr msg) {
    const double msg_t = rclcpp::Time(msg->header.stamp).seconds();

    counter += 1UL;
    if (counter % 10 == 0) {
        this->diagnostic(msg_t, ErrorCode::DATA_LOCATION_TIME_ABNORMAL);
        this->diagnostic(msg_t, latency_, ErrorCode::DATA_LOCATION_TIME_DELAY);
    }

    std::shared_ptr<RtkData> data = std::make_shared<RtkData>(msg_t, msg);
    const double latest_time = GET_LATEST_SENSOR_DATA_TIME(RtkData, "GPSLOCATION", data);
    const double dt = msg_t - latest_time;
    
    if (dt > frame_time_diff_) {
        diagnosis::report(ErrorCode::DATA_LOCATION_FRAME_TIME_ERROR);
        NTWARNING << "Node: " << node_->get_name() << " [" << get_class_name() << "] frame time diff:" << dt;
    } else {
        diagnosis::restore(ErrorCode::DATA_LOCATION_FRAME_TIME_ERROR);
    }
    
    PUSH_GENERIC_DATA(RtkData, "GPSLOCATION", data);
}

void GpsSubscriber::callback_with_trigger(const sensing_msgs::msg::RtkData::SharedPtr &msg) {
    this->callback(msg);
    
    std::lock_guard<std::mutex> lk(lock);
    last_trigger_time = std::chrono::steady_clock::now();
    ready = true;
    cv.notify_all();
}

//***********************************************************************
// 构造函数实现
SlamOdometrySubscriber::SlamOdometrySubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

// 获取类名实现
std::string SlamOdometrySubscriber::get_class_name() const {
    return "SlamOdometrySubscriber";
}

// 订阅函数实现
void SlamOdometrySubscriber::sub(const std::string &topic, const std::string &key, const float &latency,
                                 const rclcpp::QoS &qos) {
    std::cout << "Node: " << node_->get_name() << " [Init] SlamOdometrySubscriber only support using pre-defined topic.";
    sub(latency, 0.04F);
}

void SlamOdometrySubscriber::sub(const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    std::string topic = "/location/odometry";
    std::string key = "/smartcar/sensors/rtk/gnss_topic";
    
    if (node_->has_parameter(key)) {
        topic = node_->get_parameter(key).as_string();
    }
    
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();

    subscriber_ = node_->create_subscription<nav_msgs::msg::Odometry>(
        topic, qos,
        [this](const nav_msgs::msg::Odometry::SharedPtr msg) { this->callback(msg); });
}

void SlamOdometrySubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    std::cout << "Node: " << node_->get_name() << " [Init] SlamOdometrySubscriber.";
    
    subscriber_ = node_->create_subscription<nav_msgs::msg::Odometry>(
        topic, qos,
        [this](const nav_msgs::msg::Odometry::SharedPtr msg) { this->callback(msg); });
}

void SlamOdometrySubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                            const float &latency, const float &frame_time_diff) {
    key_ = key;
    latency_ = latency;
    
    subscriber_ = node_->create_subscription<nav_msgs::msg::Odometry>(
        topic, rclcpp::QoS(1),
        [this](const nav_msgs::msg::Odometry::SharedPtr msg) { this->callback_with_trigger(msg); });
}

// 回调函数实现
void SlamOdometrySubscriber::callback(const nav_msgs::msg::Odometry::SharedPtr msg) {
    const double msg_t = rclcpp::Time(msg->header.stamp).seconds();

    counter += 1UL;
    if (counter % 10 == 0) {
        this->diagnostic(msg_t, ErrorCode::DATA_LOCATION_TIME_ABNORMAL);
        this->diagnostic(msg_t, latency_, ErrorCode::DATA_LOCATION_TIME_DELAY);
    }

    std::shared_ptr<OdometryData> data = std::make_shared<OdometryData>(msg_t, msg);
    const double latest_time = GET_LATEST_SENSOR_DATA_TIME(OdometryData, "SLAMLOCATION", data);
    const double dt = msg_t - latest_time;
    
    if (dt > frame_time_diff_) {
        diagnosis::report(ErrorCode::DATA_LOCATION_FRAME_TIME_ERROR);
        NTWARNING << "Node: " << node_->get_name() << " [" << get_class_name() << "] frame time diff:" << dt;
    } else {
        diagnosis::restore(ErrorCode::DATA_LOCATION_FRAME_TIME_ERROR);
    }
    
    PUSH_GENERIC_DATA(OdometryData, "SLAMLOCATION", data);
}

void SlamOdometrySubscriber::callback_with_trigger(const nav_msgs::msg::Odometry::SharedPtr &msg) {
    this->callback(msg);
    
    std::lock_guard<std::mutex> lk(lock);
    last_trigger_time = std::chrono::steady_clock::now();
    ready = true;
    cv.notify_all();
}

//***********************************************************************
// 构造函数实现
FusionOdometrySubscriber::FusionOdometrySubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

// 获取类名实现
std::string FusionOdometrySubscriber::get_class_name() const {
    return "FusionOdometrySubscriber";
}

// 订阅函数实现
void FusionOdometrySubscriber::sub(const std::string &topic, const std::string &key, const float &latency,
                                   const rclcpp::QoS &qos) {
    std::cout << "Node: " << node_->get_name() << " [Init] FusionOdometrySubscriber only support using pre-defined topic.";
    sub(latency, 0.04F);
}

void FusionOdometrySubscriber::sub(const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    std::string topic = "/location/odometry";
    std::string key = "/smartcar/sensors/rtk/gnss_topic";
    
    if (node_->has_parameter(key)) {
        topic = node_->get_parameter(key).as_string();
    }
    
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();

    subscriber_ = node_->create_subscription<nav_msgs::msg::Odometry>(
        topic, qos,
        [this](const nav_msgs::msg::Odometry::SharedPtr msg) { this->callback(msg); });
}

void FusionOdometrySubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    std::cout << "Node: " << node_->get_name() << " [Init] FusionOdometrySubscriber.";
    
    subscriber_ = node_->create_subscription<nav_msgs::msg::Odometry>(
        topic, qos,
        [this](const nav_msgs::msg::Odometry::SharedPtr msg) { this->callback(msg); });
}

void FusionOdometrySubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                              const float &latency, const float &frame_time_diff) {
    key_ = key;
    latency_ = latency;
    
    subscriber_ = node_->create_subscription<nav_msgs::msg::Odometry>(
        topic, rclcpp::QoS(1),
        [this](const nav_msgs::msg::Odometry::SharedPtr msg) { this->callback_with_trigger(msg); });
}

// 回调函数实现
void FusionOdometrySubscriber::callback(const nav_msgs::msg::Odometry::SharedPtr msg) {
    const double msg_t = rclcpp::Time(msg->header.stamp).seconds();

    counter += 1UL;
    if (counter % 10 == 0) {
        this->diagnostic(msg_t, ErrorCode::DATA_LOCATION_TIME_ABNORMAL);
        this->diagnostic(msg_t, latency_, ErrorCode::DATA_LOCATION_TIME_DELAY);
    }

    std::shared_ptr<OdometryData> data = std::make_shared<OdometryData>(msg_t, msg);
    const double latest_time = GET_LATEST_SENSOR_DATA_TIME(OdometryData, "FUSIONLOCATION", data);
    const double dt = msg_t - latest_time;
    
    if (dt > frame_time_diff_) {
        diagnosis::report(ErrorCode::DATA_LOCATION_FRAME_TIME_ERROR);
        NTWARNING << "Node: " << node_->get_name() << " [" << get_class_name() << "] frame time diff:" << dt;
    } else {
        diagnosis::restore(ErrorCode::DATA_LOCATION_FRAME_TIME_ERROR);
    }
    
    PUSH_GENERIC_DATA(OdometryData, "FUSIONLOCATION", data);
}

void FusionOdometrySubscriber::callback_with_trigger(const nav_msgs::msg::Odometry::SharedPtr &msg) {
    this->callback(msg);
    
    std::lock_guard<std::mutex> lk(lock);
    last_trigger_time = std::chrono::steady_clock::now();
    ready = true;
    cv.notify_all();
}

//***********************************************************************
// 构造函数实现
GlobalPathSubscriber::GlobalPathSubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

// 获取类名实现
std::string GlobalPathSubscriber::get_class_name() const {
    return "GlobalPathSubscriber";
}

// 订阅函数实现
void GlobalPathSubscriber::sub(const std::string &topic, const std::string &key, const float &latency,
                               const rclcpp::QoS &qos) {
    std::cout << "Node: " << node_->get_name() << " [Init] GlobalPathSubscriber only support using pre-defined topic.";
    sub(latency, 0.04F);
}

void GlobalPathSubscriber::sub(const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    std::string topic = "/location/odometry";
    std::string key = "/smartcar/sensors/rtk/gnss_topic";
    
    if (node_->has_parameter(key)) {
        topic = node_->get_parameter(key).as_string();
    }
    
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();

    subscriber_ = node_->create_subscription<planning_msgs::msg::TrajectoryPoints>(
        topic, qos,
        [this](const planning_msgs::msg::TrajectoryPoints::SharedPtr msg) { this->callback(msg); });
}

void GlobalPathSubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    std::cout << "Node: " << node_->get_name() << " [Init] GlobalPathSubscriber.";
    
    subscriber_ = node_->create_subscription<planning_msgs::msg::TrajectoryPoints>(
        topic, qos,
        [this](const planning_msgs::msg::TrajectoryPoints::SharedPtr msg) { this->callback(msg); });
}

void GlobalPathSubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                          const float &latency, const float &frame_time_diff) {
    key_ = key;
    latency_ = latency;
    
    subscriber_ = node_->create_subscription<planning_msgs::msg::TrajectoryPoints>(
        topic, rclcpp::QoS(1),
        [this](const planning_msgs::msg::TrajectoryPoints::SharedPtr msg) { this->callback_with_trigger(msg); });
}

// 回调函数实现
void GlobalPathSubscriber::callback(const planning_msgs::msg::TrajectoryPoints::SharedPtr msg) {
    const double msg_t = rclcpp::Time(msg->header.stamp).seconds();

    counter += 1UL;
    if (counter % 10 == 0) {
        this->diagnostic(msg_t, ErrorCode::DATA_GLOBAL_TRAJECTORY_TIME_ABNORMAL);
        this->diagnostic(msg_t, latency_, ErrorCode::DATA_GLOBAL_TRAJECTORY_TIME_DELAY);
    }

    std::shared_ptr<GlobalPathData> data = std::make_shared<GlobalPathData>(msg_t, msg);
    const double latest_time = GET_LATEST_SENSOR_DATA_TIME(GlobalPathData, "GLOBALPATH", data);
    const double dt = msg_t - latest_time;
    
    if (dt > frame_time_diff_) {
        diagnosis::report(ErrorCode::DATA_GLOBAL_TRAJECTORY_FRAME_TIME_ERROR);
        NTWARNING << "Node: " << node_->get_name() << " [" << get_class_name() << "] frame time diff:" << dt;
    } else {
        diagnosis::restore(ErrorCode::DATA_GLOBAL_TRAJECTORY_FRAME_TIME_ERROR);
    }
    
    PUSH_GENERIC_DATA(GlobalPathData, "GLOBALPATH", data);
}

void GlobalPathSubscriber::callback_with_trigger(const planning_msgs::msg::TrajectoryPoints::SharedPtr &msg) {
    this->callback(msg);
    
    std::lock_guard<std::mutex> lk(lock);
    last_trigger_time = std::chrono::steady_clock::now();
    ready = true;
    cv.notify_all();
}

//***********************************************************************
// 构造函数实现
LocalPathSubscriber::LocalPathSubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

// 获取类名实现
std::string LocalPathSubscriber::get_class_name() const {
    return "LocalPathSubscriber";
}

// 订阅函数实现
void LocalPathSubscriber::sub(const std::string &topic, const std::string &key, const float &latency,
                             const rclcpp::QoS &qos) {
    std::cout << "Node: " << node_->get_name() << " [Init] LocalPathSubscriber only support using pre-defined topic.";
    sub(latency, 0.04F);
}

void LocalPathSubscriber::sub(const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    std::string topic = "/location/odometry";
    std::string key = "/smartcar/sensors/rtk/gnss_topic";
    
    if (node_->has_parameter(key)) {
        topic = node_->get_parameter(key).as_string();
    }
    
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();

    subscriber_ = node_->create_subscription<planning_msgs::msg::LocalTrajectoryPoints>(
        topic, qos,
        [this](const planning_msgs::msg::LocalTrajectoryPoints::SharedPtr msg) { this->callback(msg); });
}

void LocalPathSubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    std::cout << "Node: " << node_->get_name() << " [Init] LocalPathSubscriber.";
    
    subscriber_ = node_->create_subscription<planning_msgs::msg::LocalTrajectoryPoints>(
        topic, qos,
        [this](const planning_msgs::msg::LocalTrajectoryPoints::SharedPtr msg) { this->callback(msg); });
}

void LocalPathSubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                        const float &latency, const float &frame_time_diff) {
    key_ = key;
    latency_ = latency;
    
    subscriber_ = node_->create_subscription<planning_msgs::msg::LocalTrajectoryPoints>(
        topic, rclcpp::QoS(1),
        [this](const planning_msgs::msg::LocalTrajectoryPoints::SharedPtr msg) { this->callback_with_trigger(msg); });
}

// 回调函数实现
void LocalPathSubscriber::callback(const planning_msgs::msg::LocalTrajectoryPoints::SharedPtr msg) {
    const double msg_t = rclcpp::Time(msg->header.stamp).seconds();

    counter += 1UL;
    if (counter % 10 == 0) {
        this->diagnostic(msg_t, ErrorCode::DATA_LOCAL_TRAJECTORY_TIME_ABNORMAL);
        this->diagnostic(msg_t, latency_, ErrorCode::DATA_LOCAL_TRAJECTORY_TIME_DELAY);
    }

    std::shared_ptr<LocalPathData> data = std::make_shared<LocalPathData>(msg_t, msg);
    const double latest_time = GET_LATEST_SENSOR_DATA_TIME(LocalPathData, "LOCALPATH", data);
    const double dt = msg_t - latest_time;
    
    if (dt > frame_time_diff_) {
        diagnosis::report(ErrorCode::DATA_LOCAL_TRAJECTORY_FRAME_TIME_ERROR);
        NTWARNING << "Node: " << node_->get_name() << " [" << get_class_name() << "] frame time diff:" << dt;
    } else {
        diagnosis::restore(ErrorCode::DATA_LOCAL_TRAJECTORY_FRAME_TIME_ERROR);
    }
    
    PUSH_GENERIC_DATA(LocalPathData, "LOCALPATH", data);
}

void LocalPathSubscriber::callback_with_trigger(const planning_msgs::msg::LocalTrajectoryPoints::SharedPtr &msg) {
    this->callback(msg);
    
    std::lock_guard<std::mutex> lk(lock);
    last_trigger_time = std::chrono::steady_clock::now();
    ready = true;
    cv.notify_all();
}

//***********************************************************************
// 构造函数实现
LocalStatusSubscriber::LocalStatusSubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

// 获取类名实现
std::string LocalStatusSubscriber::get_class_name() const {
    return "LocalStatusSubscriber";
}

// 订阅函数实现
void LocalStatusSubscriber::sub(const std::string &topic, const std::string &key, const float &latency,
                               const rclcpp::QoS &qos) {
    std::cout << "Node: " << node_->get_name() << " [Init] LocalStatusSubscriber only support using pre-defined topic.";
    sub(latency, 0.04F);
}

void LocalStatusSubscriber::sub(const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    std::string topic = "/location/odometry";
    std::string key = "/smartcar/sensors/rtk/gnss_topic";
    
    if (node_->has_parameter(key)) {
        topic = node_->get_parameter(key).as_string();
    }
    
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();

    subscriber_ = node_->create_subscription<planning_msgs::msg::TrajectoryState>(
        topic, qos,
        [this](const planning_msgs::msg::TrajectoryState::SharedPtr msg) { this->callback(msg); });
}

void LocalStatusSubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    std::cout << "Node: " << node_->get_name() << " [Init] LocalStatusSubscriber.";
    
    subscriber_ = node_->create_subscription<planning_msgs::msg::TrajectoryState>(
        topic, qos,
        [this](const planning_msgs::msg::TrajectoryState::SharedPtr msg) { this->callback(msg); });
}

void LocalStatusSubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                           const float &latency, const float &frame_time_diff) {
    key_ = key;
    latency_ = latency;
    
    subscriber_ = node_->create_subscription<planning_msgs::msg::TrajectoryState>(
        topic, rclcpp::QoS(1),
        [this](const planning_msgs::msg::TrajectoryState::SharedPtr msg) { this->callback_with_trigger(msg); });
}

// 回调函数实现
void LocalStatusSubscriber::callback(const planning_msgs::msg::TrajectoryState::SharedPtr msg) {
    const double msg_t = rclcpp::Time(msg->header.stamp).seconds();

    counter += 1UL;
    if (counter % 10 == 0) {
        this->diagnostic(msg_t, ErrorCode::DATA_TRAJECTORY_STATE_TIME_ABNORMAL);
        this->diagnostic(msg_t, latency_, ErrorCode::DATA_TRAJECTORY_STATE_TIME_DELAY);
    }

    std::shared_ptr<LocalStatusData> data = std::make_shared<LocalStatusData>(msg_t, msg);
    const double latest_time = GET_LATEST_SENSOR_DATA_TIME(LocalStatusData, "LOCALPATHSTATE", data);
    const double dt = msg_t - latest_time;
    
    if (dt > frame_time_diff_) {
        diagnosis::report(ErrorCode::DATA_TRAJECTORY_STATE_FRAME_TIME_ERROR);
        NTWARNING << "Node: " << node_->get_name() << " [" << get_class_name() << "] frame time diff:" << dt;
    } else {
        diagnosis::restore(ErrorCode::DATA_TRAJECTORY_STATE_FRAME_TIME_ERROR);
    }
    
    PUSH_GENERIC_DATA(LocalStatusData, "LOCALPATHSTATE", data);
}

void LocalStatusSubscriber::callback_with_trigger(const planning_msgs::msg::TrajectoryState::SharedPtr &msg) {
    this->callback(msg);
    
    std::lock_guard<std::mutex> lk(lock);
    last_trigger_time = std::chrono::steady_clock::now();
    ready = true;
    cv.notify_all();
}

//***********************************************************************
// 构造函数实现
ControlSubscriber::ControlSubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

// 获取类名实现
std::string ControlSubscriber::get_class_name() const {
    return "ControlSubscriber";
}

// 订阅函数实现
void ControlSubscriber::sub(const std::string &topic, const std::string &key, const float &latency,
                           const rclcpp::QoS &qos) {
    std::cout << "Node: " << node_->get_name() << " [Init] ControlSubscriber only support using pre-defined topic.";
    sub(latency, 0.04F);
}

void ControlSubscriber::sub(const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    std::string topic = "/location/odometry";
    std::string key = "/smartcar/sensors/rtk/gnss_topic";
    
    if (node_->has_parameter(key)) {
        topic = node_->get_parameter(key).as_string();
    }
    
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();

    subscriber_ = node_->create_subscription<control_msgs::msg::PathspeedctrlInterface>(
        topic, qos,
        [this](const control_msgs::msg::PathspeedctrlInterface::SharedPtr msg) { this->callback(msg); });
}

void ControlSubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    std::cout << "Node: " << node_->get_name() << " [Init] ControlSubscriber.";
    
    subscriber_ = node_->create_subscription<control_msgs::msg::PathspeedctrlInterface>(
        topic, qos,
        [this](const control_msgs::msg::PathspeedctrlInterface::SharedPtr msg) { this->callback(msg); });
}

void ControlSubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                        const float &latency, const float &frame_time_diff) {
    key_ = key;
    latency_ = latency;
    
    subscriber_ = node_->create_subscription<control_msgs::msg::PathspeedctrlInterface>(
        topic, rclcpp::QoS(1),
        [this](const control_msgs::msg::PathspeedctrlInterface::SharedPtr msg) { this->callback_with_trigger(msg); });
}

// 回调函数实现
void ControlSubscriber::callback(const control_msgs::msg::PathspeedctrlInterface::SharedPtr msg) {
    const double msg_t = msg->timestamp;

    counter += 1UL;
    if (counter % 10 == 0) {
        this->diagnostic(msg_t, ErrorCode::DATA_CONTROL_TIME_ABNORMAL);
        this->diagnostic(msg_t, latency_, ErrorCode::DATA_CONTROL_TIME_DELAY);
    }

    std::shared_ptr<ControlData> data = std::make_shared<ControlData>(msg_t, msg);
    const double latest_time = GET_LATEST_SENSOR_DATA_TIME(ControlData, "CONTROL", data);
    const double dt = msg_t - latest_time;
    
    if (dt > frame_time_diff_) {
        diagnosis::report(ErrorCode::DATA_CONTROL_FRAME_TIME_ERROR);
        NTWARNING << "Node: " << node_->get_name() << " [" << get_class_name() << "] frame time diff:" << dt;
    } else {
        diagnosis::restore(ErrorCode::DATA_CONTROL_FRAME_TIME_ERROR);
    }
    
    PUSH_GENERIC_DATA(ControlData, "CONTROL", data);
}

void ControlSubscriber::callback_with_trigger(const control_msgs::msg::PathspeedctrlInterface::SharedPtr &msg) {
    this->callback(msg);
    
    std::lock_guard<std::mutex> lk(lock);
    last_trigger_time = std::chrono::steady_clock::now();
    ready = true;
    cv.notify_all();
}

//***********************************************************************
// 构造函数实现
CarOriSubscriber::CarOriSubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

// 获取类名实现
std::string CarOriSubscriber::get_class_name() const {
    return "CarOriSubscriber";
}

// 订阅函数实现
void CarOriSubscriber::sub(const std::string &topic, const std::string &key, const float &latency,
                           const rclcpp::QoS &qos) {
    std::cout << "Node: " << node_->get_name() << " [Init] CarOriSubscriber only support using pre-defined topic.";
    sub(latency, 0.04F);
}

void CarOriSubscriber::sub(const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    std::string topic = "/location/odometry";
    std::string key = "/smartcar/sensors/rtk/gnss_topic";
    
    if (node_->has_parameter(key)) {
        topic = node_->get_parameter(key).as_string();
    }
    
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();

    subscriber_ = node_->create_subscription<chassis_msgs::msg::CarOriInterface>(
        topic, qos,
        [this](const chassis_msgs::msg::CarOriInterface::SharedPtr msg) { this->callback(msg); });
}

void CarOriSubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    std::cout << "Node: " << node_->get_name() << " [Init] CarOriSubscriber.";
    
    subscriber_ = node_->create_subscription<chassis_msgs::msg::CarOriInterface>(
        topic, qos,
        [this](const chassis_msgs::msg::CarOriInterface::SharedPtr msg) { this->callback(msg); });
}

void CarOriSubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                      const float &latency, const float &frame_time_diff) {
    key_ = key;
    latency_ = latency;
    
    subscriber_ = node_->create_subscription<chassis_msgs::msg::CarOriInterface>(
        topic, rclcpp::QoS(1),
        [this](const chassis_msgs::msg::CarOriInterface::SharedPtr msg) { this->callback_with_trigger(msg); });
}

// 回调函数实现
void CarOriSubscriber::callback(const chassis_msgs::msg::CarOriInterface::SharedPtr msg) {
    const double msg_t = rclcpp::Time(msg->header.stamp).seconds();

    counter += 1UL;
    if (counter % 10 == 0) {
        this->diagnostic(msg_t, ErrorCode::DATA_CAR_ORI_TIME_ABNORMAL);
        this->diagnostic(msg_t, latency_, ErrorCode::DATA_CAR_ORI_TIME_DELAY);
    }

    std::shared_ptr<CarOriData> data = std::make_shared<CarOriData>(msg_t, msg);
    const double latest_time = GET_LATEST_SENSOR_DATA_TIME(CarOriData, "CARORI", data);
    const double dt = msg_t - latest_time;
    
    if (dt > frame_time_diff_) {
        diagnosis::report(ErrorCode::DATA_CAR_ORI_FRAME_TIME_ERROR);
        NTWARNING << "Node: " << node_->get_name() << " [" << get_class_name() << "] frame time diff:" << dt;
    } else {
        diagnosis::restore(ErrorCode::DATA_CAR_ORI_FRAME_TIME_ERROR);
    }
    
    PUSH_GENERIC_DATA(CarOriData, "CARORI", data);
}

void CarOriSubscriber::callback_with_trigger(const chassis_msgs::msg::CarOriInterface::SharedPtr &msg) {
    this->callback(msg);
    
    std::lock_guard<std::mutex> lk(lock);
    last_trigger_time = std::chrono::steady_clock::now();
    ready = true;
    cv.notify_all();
}

//***********************************************************************
// 构造函数实现
CrossGoalSubscriber::CrossGoalSubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

// 获取类名实现
std::string CrossGoalSubscriber::get_class_name() const {
    return "CrossGoalSubscriber";
}

// 订阅函数实现
void CrossGoalSubscriber::sub(const std::string &topic, const std::string &key, const float &latency,
                             const rclcpp::QoS &qos) {
    std::cout << "Node: " << node_->get_name() << " [Init] CrossGoalSubscriber only support using pre-defined topic.";
    sub(latency, 0.04F);
}

void CrossGoalSubscriber::sub(const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    std::string topic = "/location/odometry";
    std::string key = "/smartcar/sensors/rtk/gnss_topic";
    
    if (node_->has_parameter(key)) {
        topic = node_->get_parameter(key).as_string();
    }
    
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();

    subscriber_ = node_->create_subscription<control_msgs::msg::CrossGoal>(
        topic, qos,
        [this](const control_msgs::msg::CrossGoal::SharedPtr msg) { this->callback(msg); });
}

void CrossGoalSubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    std::cout << "Node: " << node_->get_name() << " [Init] CrossGoalSubscriber.";
    
    subscriber_ = node_->create_subscription<control_msgs::msg::CrossGoal>(
        topic, qos,
        [this](const control_msgs::msg::CrossGoal::SharedPtr msg) { this->callback(msg); });
}

void CrossGoalSubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                         const float &latency, const float &frame_time_diff) {
    key_ = key;
    latency_ = latency;
    
    subscriber_ = node_->create_subscription<control_msgs::msg::CrossGoal>(
        topic, rclcpp::QoS(1),
        [this](const control_msgs::msg::CrossGoal::SharedPtr msg) { this->callback_with_trigger(msg); });
}

// 回调函数实现
void CrossGoalSubscriber::callback(const control_msgs::msg::CrossGoal::SharedPtr msg) {
    const double msg_t = rclcpp::Time(msg->header.stamp).seconds();

    counter += 1UL;
    if (counter % 10 == 0) {
        this->diagnostic(msg_t, ErrorCode::DATA_CROSS_GOAL_TIME_ABNORMAL);
        this->diagnostic(msg_t, latency_, ErrorCode::DATA_CROSS_GOAL_TIME_DELAY);
    }

    std::shared_ptr<CrossGoalData> data = std::make_shared<CrossGoalData>(msg_t, msg);
    const double latest_time = GET_LATEST_SENSOR_DATA_TIME(CrossGoalData, "CROSSGOAL", data);
    const double dt = msg_t - latest_time;
    
    if (dt > frame_time_diff_) {
        diagnosis::report(ErrorCode::DATA_CROSS_GOAL_FRAME_TIME_ERROR);
        NTWARNING << "Node: " << node_->get_name() << " [" << get_class_name() << "] frame time diff:" << dt;
    } else {
        diagnosis::restore(ErrorCode::DATA_CROSS_GOAL_FRAME_TIME_ERROR);
    }
    
    PUSH_GENERIC_DATA(CrossGoalData, "CROSSGOAL", data);
}

void CrossGoalSubscriber::callback_with_trigger(const control_msgs::msg::CrossGoal::SharedPtr &msg) {
    this->callback(msg);
    
    std::lock_guard<std::mutex> lk(lock);
    last_trigger_time = std::chrono::steady_clock::now();
    ready = true;
    cv.notify_all();
}

//***********************************************************************
// 构造函数实现
ArmOriSubscriber::ArmOriSubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

// 获取类名实现
std::string ArmOriSubscriber::get_class_name() const {
    return "ArmOriSubscriber";
}

// 订阅函数实现
void ArmOriSubscriber::sub(const std::string &topic, const std::string &key, const float &latency,
                           const rclcpp::QoS &qos) {
    std::cout << "Node: " << node_->get_name() << " [Init] ArmOriSubscriber only support using pre-defined topic.";
    sub(latency, 0.04F);
}

void ArmOriSubscriber::sub(const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    std::string topic = "/location/odometry";
    std::string key = "/smartcar/sensors/rtk/gnss_topic";
    
    if (node_->has_parameter(key)) {
        topic = node_->get_parameter(key).as_string();
    }
    
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();

    subscriber_ = node_->create_subscription<chassis_msgs::msg::ArmData>(
        topic, qos,
        [this](const chassis_msgs::msg::ArmData::SharedPtr msg) { this->callback(msg); });
}

void ArmOriSubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    std::cout << "Node: " << node_->get_name() << " [Init] ArmOriSubscriber.";
    
    subscriber_ = node_->create_subscription<chassis_msgs::msg::ArmData>(
        topic, qos,
        [this](const chassis_msgs::msg::ArmData::SharedPtr msg) { this->callback(msg); });
}

void ArmOriSubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                      const float &latency, const float &frame_time_diff) {
    key_ = key;
    latency_ = latency;
    
    subscriber_ = node_->create_subscription<chassis_msgs::msg::ArmData>(
        topic, rclcpp::QoS(1),
        [this](const chassis_msgs::msg::ArmData::SharedPtr msg) { this->callback_with_trigger(msg); });
}

// 回调函数实现
void ArmOriSubscriber::callback(const chassis_msgs::msg::ArmData::SharedPtr msg) {
    const double msg_t = rclcpp::Time(msg->header.stamp).seconds();

    counter += 1UL;
    if (counter % 10 == 0) {
        this->diagnostic(msg_t, ErrorCode::DATA_ARM_ORI_TIME_ABNORMAL);
        this->diagnostic(msg_t, latency_, ErrorCode::DATA_ARM_ORI_TIME_DELAY);
    }

    std::shared_ptr<ArmOriData> data = std::make_shared<ArmOriData>(msg_t, msg);
    const double latest_time = GET_LATEST_SENSOR_DATA_TIME(ArmOriData, "ARMINFO", data);
    const double dt = msg_t - latest_time;
    
    if (dt > frame_time_diff_) {
        diagnosis::report(ErrorCode::DATA_ARM_ORI_FRAME_TIME_ERROR);
        NTWARNING << "Node: " << node_->get_name() << " [" << get_class_name() << "] frame time diff:" << dt;
    } else {
        diagnosis::restore(ErrorCode::DATA_ARM_ORI_FRAME_TIME_ERROR);
    }
    
    PUSH_GENERIC_DATA(ArmOriData, "ARMINFO", data);
}

void ArmOriSubscriber::callback_with_trigger(const chassis_msgs::msg::ArmData::SharedPtr &msg) {
    this->callback(msg);
    
    std::lock_guard<std::mutex> lk(lock);
    last_trigger_time = std::chrono::steady_clock::now();
    ready = true;
    cv.notify_all();
}

//***********************************************************************
// 构造函数实现
ForkTaskStateSubscriber::ForkTaskStateSubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

// 获取类名实现
std::string ForkTaskStateSubscriber::get_class_name() const {
    return "ForkTaskStateSubscriber";
}

// 订阅函数实现
void ForkTaskStateSubscriber::sub(const std::string &topic, const std::string &key, const float &latency,
                                 const rclcpp::QoS &qos) {
    std::cout << "Node: " << node_->get_name() << " [Init] ForkTaskStateSubscriber only support using pre-defined topic.";
    sub(latency, 0.04F);
}

void ForkTaskStateSubscriber::sub(const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    std::string topic = "/location/odometry";
    std::string key = "/smartcar/sensors/rtk/gnss_topic";
    
    if (node_->has_parameter(key)) {
        topic = node_->get_parameter(key).as_string();
    }
    
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();

    subscriber_ = node_->create_subscription<control_task_msgs::msg::TaskState>(
        topic, qos,
        [this](const control_task_msgs::msg::TaskState::SharedPtr msg) { this->callback(msg); });
}

void ForkTaskStateSubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    std::cout << "Node: " << node_->get_name() << " [Init] ForkTaskStateSubscriber.";
    
    subscriber_ = node_->create_subscription<control_task_msgs::msg::TaskState>(
        topic, qos,
        [this](const control_task_msgs::msg::TaskState::SharedPtr msg) { this->callback(msg); });
}

void ForkTaskStateSubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                            const float &latency, const float &frame_time_diff) {
    key_ = key;
    latency_ = latency;
    
    subscriber_ = node_->create_subscription<control_task_msgs::msg::TaskState>(
        topic, rclcpp::QoS(1),
        [this](const control_task_msgs::msg::TaskState::SharedPtr msg) { this->callback_with_trigger(msg); });
}

// 回调函数实现
void ForkTaskStateSubscriber::callback(const control_task_msgs::msg::TaskState::SharedPtr msg) {
    const double msg_t = rclcpp::Time(msg->header.stamp).seconds();

    counter += 1UL;
    if (counter % 10 == 0) {
        this->diagnostic(msg_t, ErrorCode::DATA_ARM_TASK_STATE_TIME_ABNORMAL);
        this->diagnostic(msg_t, latency_, ErrorCode::DATA_ARM_TASK_STATE_TIME_DELAY);
    }

    std::shared_ptr<ForkTaskStateData> data = std::make_shared<ForkTaskStateData>(msg_t, msg);
    const double latest_time = GET_LATEST_SENSOR_DATA_TIME(ForkTaskStateData, "ARMTASKSTATE", data);
    const double dt = msg_t - latest_time;
    
    if (dt > frame_time_diff_) {
        diagnosis::report(ErrorCode::DATA_ARM_TASK_STATE_FRAME_TIME_ERROR);
        NTWARNING << "Node: " << node_->get_name() << " [" << get_class_name() << "] frame time diff:" << dt;
    } else {
        diagnosis::restore(ErrorCode::DATA_ARM_TASK_STATE_FRAME_TIME_ERROR);
    }
    
    PUSH_GENERIC_DATA(ForkTaskStateData, "ARMTASKSTATE", data);
}

void ForkTaskStateSubscriber::callback_with_trigger(const control_task_msgs::msg::TaskState::SharedPtr &msg) {
    this->callback(msg);
    
    std::lock_guard<std::mutex> lk(lock);
    last_trigger_time = std::chrono::steady_clock::now();
    ready = true;
    cv.notify_all();
}

//***********************************************************************
ForkControlSubscriber::ForkControlSubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

std::string ForkControlSubscriber::get_class_name() const {
    return "ForkControlSubscriber";
}

void ForkControlSubscriber::sub(const std::string &topic, const std::string &key, const float &latency,
                                const rclcpp::QoS &qos) {
    std::cout << "Node: " << node_->get_name() << " [Init] ForkControlSubscriber only support using pre-defined topic.";
    sub(latency, 0.04F);
}

void ForkControlSubscriber::sub(const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    std::string topic = "/location/odometry";
    std::string key = "/smartcar/sensors/rtk/gnss_topic";
    
    if (node_->has_parameter(key)) {
        topic = node_->get_parameter(key).as_string();
    }
    
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    subscriber_ = node_->create_subscription<chassis_msgs::msg::ForkControl>(
        topic, qos,
        [this](const chassis_msgs::msg::ForkControl::SharedPtr msg) { this->callback(msg); });
}

void ForkControlSubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    std::cout << "Node: " << node_->get_name() << " [Init] ForkControlSubscriber.";
    subscriber_ = node_->create_subscription<chassis_msgs::msg::ForkControl>(
        topic, qos,
        [this](const chassis_msgs::msg::ForkControl::SharedPtr msg) { this->callback(msg); });
}

void ForkControlSubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                           const float &latency, const float &frame_time_diff) {
    key_ = key;
    latency_ = latency;
    subscriber_ = node_->create_subscription<chassis_msgs::msg::ForkControl>(
        topic, rclcpp::QoS(1),
        [this](const chassis_msgs::msg::ForkControl::SharedPtr msg) { this->callback_with_trigger(msg); });
}

void ForkControlSubscriber::callback(const chassis_msgs::msg::ForkControl::SharedPtr msg) {
    const double msg_t = rclcpp::Time(msg->header.stamp).seconds();
    counter += 1UL;
    
    if (counter % 10 == 0) {
        this->diagnostic(msg_t, ErrorCode::DATA_ARM_CONTROL_TIME_ABNORMAL);
        this->diagnostic(msg_t, latency_, ErrorCode::DATA_ARM_CONTROL_TIME_DELAY);
    }

    std::shared_ptr<ForkControlData> data = std::make_shared<ForkControlData>(msg_t, msg);
    const double latest_time = GET_LATEST_SENSOR_DATA_TIME(ForkControlData, "ARMCONTROL", data);
    const double dt = msg_t - latest_time;
    
    if (dt > frame_time_diff_) {
        diagnosis::report(ErrorCode::DATA_ARM_CONTROL_FRAME_TIME_ERROR);
        NTWARNING << "Node: " << node_->get_name() << " [" << get_class_name() << "] frame time diff:" << dt;
    } else {
        diagnosis::restore(ErrorCode::DATA_ARM_CONTROL_FRAME_TIME_ERROR);
    }

    if (ErrorCode::OK != PUSH_GENERIC_DATA(ForkControlData, "ARMCONTROL", data)) {
        NTWARNING << "Node: " << node_->get_name() << " [" << get_class_name() << "] push info buffer failed!";
    }
}

void ForkControlSubscriber::callback_with_trigger(const chassis_msgs::msg::ForkControl::SharedPtr &msg) {
    this->callback(msg);
    std::lock_guard<std::mutex> lk(lock);
    last_trigger_time = std::chrono::steady_clock::now();
    ready = true;
    cv.notify_all();
}

//***********************************************************************
GoalSubscriber::GoalSubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

std::string GoalSubscriber::get_class_name() const {
    return "GoalSubscriber";
}

void GoalSubscriber::sub(const std::string &topic, const std::string &key, const float &latency,
                         const rclcpp::QoS &qos) {
    std::cout << "Node: " << node_->get_name() << " [Init] GoalSubscriber only support using pre-defined topic.";
    sub(latency, 0.04F);
}

void GoalSubscriber::sub(const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    std::string topic = "/location/odometry";
    std::string key = "/smartcar/sensors/rtk/gnss_topic";
    
    if (node_->has_parameter(key)) {
        topic = node_->get_parameter(key).as_string();
    }
    
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    subscriber_ = node_->create_subscription<control_task_msgs::msg::TaskGoalData>(
        topic, qos,
        [this](const control_task_msgs::msg::TaskGoalData::SharedPtr msg) { this->callback(msg); });
}

void GoalSubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    std::cout << "Node: " << node_->get_name() << " [Init] GoalSubscriber.";
    subscriber_ = node_->create_subscription<control_task_msgs::msg::TaskGoalData>(
        topic, qos,
        [this](const control_task_msgs::msg::TaskGoalData::SharedPtr msg) { this->callback(msg); });
}

void GoalSubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                     const float &latency, const float &frame_time_diff) {
    key_ = key;
    latency_ = latency;
    subscriber_ = node_->create_subscription<control_task_msgs::msg::TaskGoalData>(
        topic, rclcpp::QoS(1),
        [this](const control_task_msgs::msg::TaskGoalData::SharedPtr msg) { this->callback_with_trigger(msg); });
}

void GoalSubscriber::callback(const control_task_msgs::msg::TaskGoalData::SharedPtr msg) {
    const double msg_t = rclcpp::Time(msg->header.stamp).seconds();
    counter += 1UL;
    
    if (counter % 10 == 0) {
        this->diagnostic(msg_t, ErrorCode::DATA_TASK_GOAL_TIME_ABNORMAL);
        this->diagnostic(msg_t, latency_, ErrorCode::DATA_TASK_GOAL_TIME_DELAY);
    }

    std::shared_ptr<GoalData> data = std::make_shared<GoalData>(msg_t, msg);
    const double latest_time = GET_LATEST_SENSOR_DATA_TIME(GoalData, "TASKGOAL", data);
    const double dt = msg_t - latest_time;
    
    if (dt > frame_time_diff_) {
        diagnosis::report(ErrorCode::DATA_TASK_GOAL_FRAME_TIME_ERROR);
        NTWARNING << "Node: " << node_->get_name() << " [" << get_class_name() << "] frame time diff:" << dt;
    } else {
        diagnosis::restore(ErrorCode::DATA_TASK_GOAL_FRAME_TIME_ERROR);
    }

    PUSH_GENERIC_DATA(GoalData, "TASKGOAL", data);
}

void GoalSubscriber::callback_with_trigger(const control_task_msgs::msg::TaskGoalData::SharedPtr &msg) {
    this->callback(msg);
    std::lock_guard<std::mutex> lk(lock);
    last_trigger_time = std::chrono::steady_clock::now();
    ready = true;
    cv.notify_all();
}

//***********************************************************************
TaskTypeSubscriber::TaskTypeSubscriber(rclcpp::Node::SharedPtr node)
    : SingleSubscriber(std::move(node)) {}

std::string TaskTypeSubscriber::get_class_name() const {
    return "TaskTypeSubscriber";
}

void TaskTypeSubscriber::sub(const std::string &topic, const std::string &key, const float &latency,
                             const rclcpp::QoS &qos) {
    std::cout << "Node: " << node_->get_name() << " [Init] TaskTypeSubscriber only support using pre-defined topic.";
    sub(latency, 0.04F);
}

void TaskTypeSubscriber::sub(const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    std::string topic = "/location/odometry";
    std::string key = "/smartcar/sensors/rtk/gnss_topic";
    
    if (node_->has_parameter(key)) {
        topic = node_->get_parameter(key).as_string();
    }
    
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    subscriber_ = node_->create_subscription<control_task_msgs::msg::TaskType>(
        topic, qos,
        [this](const control_task_msgs::msg::TaskType::SharedPtr msg) { this->callback(msg); });
}

void TaskTypeSubscriber::sub(const std::string topic, const float latency, const float frame_time_diff) {
    latency_ = latency;
    frame_time_diff_ = frame_time_diff;
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    std::cout << "Node: " << node_->get_name() << " [Init] TaskTypeSubscriber.";
    subscriber_ = node_->create_subscription<control_task_msgs::msg::TaskType>(
        topic, qos,
        [this](const control_task_msgs::msg::TaskType::SharedPtr msg) { this->callback(msg); });
}

void TaskTypeSubscriber::sub_and_trigger(const std::string &topic, const std::string &key, 
                                         const float &latency, const float &frame_time_diff) {
    key_ = key;
    latency_ = latency;
    subscriber_ = node_->create_subscription<control_task_msgs::msg::TaskType>(
        topic, rclcpp::QoS(1),
        [this](const control_task_msgs::msg::TaskType::SharedPtr msg) { this->callback_with_trigger(msg); });
}

void TaskTypeSubscriber::callback(const control_task_msgs::msg::TaskType::SharedPtr msg) {
    const double msg_t = rclcpp::Time(msg->header.stamp).seconds();
    counter += 1UL;
    
    if (counter % 10 == 0) {
        this->diagnostic(msg_t, ErrorCode::DATA_TASK_TYPE_TIME_ABNORMAL);
        this->diagnostic(msg_t, latency_, ErrorCode::DATA_TASK_TYPE_TIME_DELAY);
    }

    std::shared_ptr<TaskTypeData> data = std::make_shared<TaskTypeData>(msg_t, msg);
    const double latest_time = GET_LATEST_SENSOR_DATA_TIME(TaskTypeData, "TASKTYPE", data);
    const double dt = msg_t - latest_time;
    
    if (dt > frame_time_diff_) {
        diagnosis::report(ErrorCode::DATA_TASK_TYPE_FRAME_TIME_ERROR);
        NTWARNING << "Node: " << node_->get_name() << " [" << get_class_name() << "] frame time diff:" << dt;
    } else {
        diagnosis::restore(ErrorCode::DATA_TASK_TYPE_FRAME_TIME_ERROR);
    }
        PUSH_GENERIC_DATA(TaskTypeData, "TASKTYPE", data);
}

void TaskTypeSubscriber::callback_with_trigger(const control_task_msgs::msg::TaskType::SharedPtr &msg) {
    this->callback(msg);
    std::lock_guard<std::mutex> lk(lock);
    last_trigger_time = std::chrono::steady_clock::now();
    ready = true;
    cv.notify_all();
}
}  // namespace common
}  // namespace tju