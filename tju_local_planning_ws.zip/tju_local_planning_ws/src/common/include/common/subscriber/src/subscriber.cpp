#include "common/subscriber/subscribe.hpp"
namespace tju {
namespace common {

Subscriber::Subscriber(rclcpp::Node::SharedPtr node) : node_(std::move(node)) {}

Subscriber::~Subscriber() {
  Stop();
}

bool Subscriber::Start(const YAML::Node &config, const std::string &trigger_name) {
  if(config["Lidar"].IsDefined()){
    if (!StartLidarGroup(config, trigger_name)) return false;
  }

  if(config["Camera"].IsDefined()){
    if (!StartCamera(config, trigger_name)) return false;
  }

  if(config["CameraInfo"].IsDefined()){
    if (!StartCameraInfo(config)) return false;
  }

  if(config["Other"].IsDefined()){
    if (!StartOthers(config, trigger_name)) return false;
  }

  return true;
}

void Subscriber::Stop() {
  node_.reset();
  subscribers_.clear();
}

bool Subscriber::StartLidarGroup(const YAML::Node &config, const std::string &trigger_name) {
  bool task_triggered = false;
  if (trigger_name.empty()) task_triggered = true;
  try {
    if (config["Lidar"].IsDefined()) {
      auto group = config["Lidar"];
      for (const auto &lidar : group) {
        auto name = lidar["Name"].as<std::string>();
        std::string topic = "";
        if (lidar["Topic"].IsDefined()) {
          topic = lidar["Topic"].as<std::string>();
        } 
        float latency_threshold = 0.2;
        if (lidar["Diagnose_MaxLatency"].IsDefined()) {
          latency_threshold = lidar["Diagnose_MaxLatency"].as<float>();
        }

        auto subscriber = SingleSubscriberRegistry::Get().Create("LidarSubscriber", node_);
        if (!subscriber) {
          NTFATAL << "Failed to create subscriber: LidarSubscriber";
          return false;
        }
        if (!task_triggered && trigger_name == name) {
          subscriber->sub_and_trigger(topic, name, latency_threshold);
          task_triggered = true;
        } else {
          subscriber->sub(topic, name, latency_threshold);
        }
        subscribers_.push_back(std::move(subscriber));

        NTINFO << "[Init] Lidar Subscriber: " << name << " from " << topic << " " << latency_threshold << "s";
      }
    } else {
        NTFATAL << "[Init][Subscriber] Lidar group not defined";
    }
  } catch (const std::exception &e) {
      NTFATAL << "[Init][Subscriber] Failed to start Lidar group: " << e.what();
      return false;
  }

  return true;
}

bool Subscriber::StartCamera(const YAML::Node &config, const std::string &trigger_name) {
  bool task_triggered = false;
  if (trigger_name.empty()) task_triggered = true;
  try {
    if (config["Camera"].IsDefined()) {
      auto group = config["Camera"];
      for (const auto &camera : group) {
        auto name = camera["Name"].as<std::string>();
        std::string topic = "";
        if (camera["Topic"].IsDefined()) {
          topic = camera["Topic"].as<std::string>();
        }   

        float latency_threshold = 0.2;
        if (camera["Diagnose_MaxLatency"].IsDefined()) {
          latency_threshold = camera["Diagnose_MaxLatency"].as<float>();
        }

        auto subscriber = SingleSubscriberRegistry::Get().Create("CameraSubscriber", node_);
        if (!subscriber) {
          NTFATAL << "Failed to create subscriber: CameraSubscriber";
          return false;
        }
        if (!task_triggered && trigger_name == name) {
          subscriber->sub_and_trigger(topic, name, latency_threshold);
          task_triggered = true;
        } else {
          subscriber->sub(topic, name, latency_threshold);
        }
        subscribers_.push_back(std::move(subscriber));

        NTINFO << "[Init] Camera Subscriber: " << name << " from " << topic << " " << latency_threshold << "s";
      }
    } else {
      NTFATAL << "[Init][Subscriber] Camera group not defined";
    }
  } catch (const std::exception &e) {
    NTFATAL << "[Init][Subscriber] Failed to start Camera group: " << e.what();
    return false;
  }
  return true;
}

bool Subscriber::StartCameraInfo(const YAML::Node &config) {
  try {
    if (!config["CameraInfo"].IsDefined()) {
      NTFATAL << "[Init][Subscriber] CameraInfo group not defined";
      return true;
    }
    for (const auto &camera : config["CameraInfo"]) {
      auto name = camera["Name"].as<std::string>();
      std::string topic = "";
      if (camera["Topic"].IsDefined()) {
        topic = camera["Topic"].as<std::string>();
      } else {
        NTFATAL << "[Init][Subscriber] CameraInfo key not found in SensorsKeyMap";
        return false;
      }

      auto subscriber = SingleSubscriberRegistry::Get().Create("CameraInfoSubscriber", node_);
      if (!subscriber) {
        NTFATAL << "Failed to create subscriber: CameraInfoSubscriber";
        return false;
      }
    subscriber->sub(topic, name, 0.0);
    subscribers_.push_back(std::move(subscriber));

    NTINFO << "[Init] CameraInfo Subscriber: " << name << " from " << topic;
    }
  } catch (const std::exception &e) {
    NTFATAL << "[Init][Subscriber] Failed to start CameraInfo group: " << e.what();
    return false;
  }
  return true;
}

bool Subscriber::StartOthers(const YAML::Node &config, const std::string &trigger_name) {
  bool task_triggered = false;
  if (trigger_name.empty()) task_triggered = true;
  std::string node_name = std::string(node_->get_name());
  try {
    if (!config["Other"].IsDefined()) {
      NTFATAL << "Node: " + node_name + " [Init][Subscriber] Other group not defined";
      return true;
    }
    for (const auto &other_node : config["Other"]) {
      auto name = other_node["Name"].as<std::string>();
      auto subscriber_cls = name;
      if(other_node["SubscriberCls"].IsDefined()){
        subscriber_cls = other_node["SubscriberCls"].as<std::string>();
      }
      float latency = 0.04F;
      if (other_node["Diagnose_MaxLatency"].IsDefined()) {
        latency = other_node["Diagnose_MaxLatency"].as<float>();
      }
      auto subscriber = SingleSubscriberRegistry::Get().Create(subscriber_cls, node_);
      if (!subscriber) {
        NTFATAL << "Node: " + node_name + " Failed to create subscriber: " << subscriber_cls;
        return false;
      }
      std::string topic;
      if (other_node["Topic"].IsDefined()) {
        topic = other_node["Topic"].as<std::string>();
      }

      float frame_time_diff_threshold = 0.5F;
      if (other_node["Diagnose_FrameTimeDiff"].IsDefined()) {
        frame_time_diff_threshold = other_node["Diagnose_FrameTimeDiff"].as<float>();
      }
      if (!task_triggered && trigger_name == name) {
        subscriber->sub_and_trigger(topic, name, latency, frame_time_diff_threshold);
        task_triggered = true;
      } else {
        subscriber->sub(topic, latency, frame_time_diff_threshold);
      }
      subscribers_.push_back(std::move(subscriber));
      NTINFO << "Node: " + node_name + " [Init] Subscriber: " << name << " " << subscriber_cls << " " << latency << "s";
    }
  } catch (const std::exception &e) {
    NTFATAL << "Node: " + node_name + " [Init][Subscriber] Failed to start Others group: " << e.what();
    return false;
  }
  return true;
}

}  // namespace common
}  // namespace tju