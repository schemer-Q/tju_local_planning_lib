#pragma once

#include <chrono>
#include <condition_variable>
#include <functional>
#include <memory>
#include <mutex>
#include <utility>

#include "rclcpp/rclcpp.hpp"
#include "yaml-cpp/yaml.h"

#include "common/util/diagnosis.h"

#include "common/log/t_log.hpp"

#include "common/subscriber/base_subscriber.hpp"
#include "common/subscriber/lidar_subscriber.hpp"
#include "common/subscriber/camera.hpp"
#include "common/subscriber/other_subscribers.hpp"


namespace tju {
namespace common {

class Subscriber {
 public:
  explicit Subscriber(rclcpp::Node::SharedPtr node);
  ~Subscriber();

  bool Start(const YAML::Node &config, const std::string &trigger_name = "");
  void Stop();
  
  bool StartLidarGroup(const YAML::Node &config, const std::string &trigger_name);
  bool StartCamera(const YAML::Node &config, const std::string &trigger_name);
  bool StartCameraInfo(const YAML::Node &config);
  bool StartOthers(const YAML::Node &config, const std::string &trigger_name);

 private:
  rclcpp::Node::SharedPtr node_;
  std::vector<std::unique_ptr<SingleSubscriber>> subscribers_;
};

}}
