#pragma once

#include <chrono>
#include <mutex>
#include <unordered_set>
#include "diagnose_msgs/msg/error_code.hpp"
#include "common/util/error_code.h"
#include "rclcpp/rclcpp.hpp"
#include "common/util/singleton.hpp"

using namespace std::chrono_literals;

namespace tju {
namespace common {

class DiagnosisReporter : public rclcpp::Node {
 public:
  DiagnosisReporter() : Node("diagnosis_reporter") {
    this->declare_parameter<std::string>("diagnosis_topic", "/diagnosis/error_codes");
  }

  ~DiagnosisReporter() {
    if (heartbeat_timer_) heartbeat_timer_->cancel();
  }

  void Start(const std::string& module_name) {
    if (running_) return;

    module_name_ = module_name;
    std::string topic = this->get_parameter("diagnosis_topic").as_string();
    // if(this->has_parameter("diagnosis_topic")){
    //   topic = this->get_parameter("diagnosis_topic").as_string();
    // }

    pub_ = this->create_publisher<diagnose_msgs::msg::ErrorCode>(topic, rclcpp::QoS(100).reliable());

    heartbeat_timer_ = this->create_wall_timer(100ms, std::bind(&DiagnosisReporter::TimerCallback, this));

    running_ = true;
  }

  void Report(int32_t ec) {
    std::lock_guard<std::mutex> lock(mtx_);
    record_.insert(ec);
  }

  void Restore(int32_t ec) {
    std::lock_guard<std::mutex> lock(mtx_);
    record_.erase(ec);
  }

  void Clear() {
    std::lock_guard<std::mutex> lock(mtx_);
    record_.clear();
  }

 private:
  void TimerCallback() {
    diagnose_msgs::msg::ErrorCode msg;
    msg.module_name = module_name_;

    {
      std::lock_guard<std::mutex> lock(mtx_);
      msg.error_codes.assign(record_.begin(), record_.end());
    }

    pub_->publish(msg);
  }

  rclcpp::Publisher<diagnose_msgs::msg::ErrorCode>::SharedPtr pub_;
  rclcpp::TimerBase::SharedPtr heartbeat_timer_;
  std::string module_name_;
  std::unordered_set<int32_t> record_;
  std::mutex mtx_;
  bool running_ = false;
};

}  // namespace common

namespace diagnosis {

inline void start(const std::string& module_name) {
  tju::common::Singleton<tju::common::DiagnosisReporter>::GetInstance().Start(module_name);
}

inline void report(int32_t ec) {
  tju::common::Singleton<tju::common::DiagnosisReporter>::GetInstance().Report(ec);
}

inline void restore(int32_t ec) {
  tju::common::Singleton<tju::common::DiagnosisReporter>::GetInstance().Restore(ec);
}

inline void clear() { tju::common::Singleton<tju::common::DiagnosisReporter>::GetInstance().Clear(); }

}  // namespace diagnosis
}  // namespace tju