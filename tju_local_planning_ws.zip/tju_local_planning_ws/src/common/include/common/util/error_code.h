#pragma once

#include <cstdint>

namespace tju {
namespace common {

constexpr uint32_t operator"" _l1(unsigned long long code) { return 10000 + code; }

constexpr uint32_t operator"" _l2(unsigned long long code) { return 20000 + code; }

constexpr uint32_t operator"" _l3(unsigned long long code) { return 30000 + code; }

enum ErrorCode : uint32_t {
  OK = 0,                          ///成功返回      
  FUNCTION_NOT_IMPLEMENTED = 1,  ///< 函数未实现
  PARAMETER_ERROR = 2,           ///< 参数错误
  UNINITIALIZED = 3,             ///< 未正确初始化
  YAML_CONFIG_ERROR = 4,         ///< YAML配置文件错误
  
  // 数据缓冲区错误 [10-19]
  DATA_BUFFER_ROLLBACK = 10,
  DATA_BUFFER_EXTRACT_FAILED_FOR_EMPTY = 11,
  DATA_BUFFER_EXTRACT_FAILED_FOR_TIMEOUT = 12,

  // 传感器错误 [20-29]
  SENSOR_DATA_TYPE_NOT_FOUND = 20,
  SENSOR_POSE_NOT_FOUND = 21,
  POINT_CLOUD_INVALID = 22,
  IMAGE_DATA_INVALID = 23,
  ODOMETRY_DATA_INVALID = 24,

  // [1000 - 1049]
  // 1. 软件启动错误
  LAUNCH_ERROR = 1000_l3,

  // [1001 - 1009]
  // 1.1 配置文件加载失败
  LAUNCH_CONFIG_LOAD_FAILED = 1001_l3,
  // 1.1.1 文件不存在
  LAUNCH_CONFIG_FILE_NOT_FOUND = 1002_l3,
  // 1.1.2 文件参数错误
  LAUNCH_CONFIG_FILE_PARAM_ERROR = 1003_l3,

  // [1010 - 1019]
  // 1.2 ROS参数加载失败
  LAUNCH_PARAM_LOAD_FAILED = 1010_l3,
  // 1.2.1 参数获取失败
  LAUNCH_PARAM_GET_FAILED = 1011_l3,
  // 1.2.2 参数值错误
  LAUNCH_PARAM_VALUE_ERROR = 1012_l3,

  // 相机图片数据订阅
  // 数据错误
  DATA_IMAGE_ERROR = 10000_l3,
  // 数据接收超时
  DATA_IMAGE_TIMEOUT = 10001_l3,
  // 数据时间戳异常
  DATA_IMAGE_TIME_ABNORMAL = 10002_l3,
  // 数据延迟过大 (接收时间 - 里程计时间 > 阈值)
  DATA_IMAGE_TIME_DELAY = 10003_l3,
  // 数据前后帧时间差过大 (当前帧时间 - 上一帧时间 >
  // 阈值(默认0.04s))
  DATA_IMAGE_FRAME_TIME_ERROR = 10004_l3,
  DATA_IMAGE_EMPTY = 10005_l3,
  // 激光雷达点云数据订阅
  // 数据错误
  DATA_POINTCLOUD_ERROR = 10010_l3,
  // 数据接收超时
  DATA_POINTCLOUD_TIMEOUT = 10011_l3,
  // 数据时间戳异常
  DATA_POINTCLOUD_TIME_ABNORMAL = 10012_l3,
  // 数据延迟过大 (接收时间 - 里程计时间 > 阈值)
  DATA_POINTCLOUD_TIME_DELAY = 10013_l3,
  // 数据前后帧时间差过大 (当前帧时间 - 上一帧时间 >
  // 阈值(默认0.04s))
  DATA_POINTCLOUD_FRAME_TIME_ERROR = 10014_l3,
  DATA_POINTCLOUD_POINT_NUM_ABNORMAL = 10015_l3,


  // 定位数据订阅
  // 数据错误
  DATA_LOCATION_ERROR = 10020_l3,
  // 数据接收超时
  DATA_LOCATION_TIMEOUT = 10021_l3,
  // 数据时间戳异常
  DATA_LOCATION_TIME_ABNORMAL = 10022_l3,
  // 数据延迟过大 (接收时间 - 里程计时间 > 阈值)
  DATA_LOCATION_TIME_DELAY = 10023_l3,
  // 数据前后帧时间差过大 (当前帧时间 - 上一帧时间 >
  // 阈值(默认0.04s))
  DATA_LOCATION_FRAME_TIME_ERROR = 10024_l3,

  // IMU数据订阅
  // 数据错误
  DATA_IMU_ERROR = 10030_l3,
  // 数据接收超时
  DATA_IMU_TIMEOUT = 10031_l3,
  // 数据时间戳异常
  DATA_IMU_TIME_ABNORMAL = 10032_l3,
  // 数据延迟过大 (接收时间 - 里程计时间 > 阈值)
  DATA_IMU_TIME_DELAY = 10033_l3,
  // 数据前后帧时间差过大 (当前帧时间 - 上一帧时间 >
  // 阈值(默认0.04s))
  DATA_IMU_FRAME_TIME_ERROR = 10034_l3,

  // 动态障碍物检测数据订阅
  // 数据错误
  DATA_OBJECTS_DETECTION_ERROR = 10040_l3,
  // 数据接收超时
  DATA_OBJECTS_DETECTION_TIMEOUT = 10041_l3,
  // 数据时间戳异常
  DATA_OBJECTS_DETECTION_TIME_ABNORMAL = 10042_l3,
  // 数据延迟过大 (接收时间 - 里程计时间 > 阈值)
  DATA_OBJECTS_DETECTION_TIME_DELAY = 10043_l3,
  // 数据前后帧时间差过大 (当前帧时间 - 上一帧时间 >
  // 阈值(默认0.04s))
  DATA_OBJECTS_DETECTION_FRAME_TIME_ERROR = 10044_l3,

  // OGM检测数据订阅
  // 数据错误
  DATA_OGM_DETECTION_ERROR = 10050_l3,
  // 数据接收超时
  DATA_OGM_DETECTION_TIMEOUT = 10051_l3,
  // 数据时间戳异常
  DATA_OGM_DETECTION_TIME_ABNORMAL = 10052_l3,
  // 数据延迟过大 (接收时间 - 里程计时间 > 阈值)
  DATA_OGM_DETECTION_TIME_DELAY = 10053_l3,
  // 数据前后帧时间差过大 (当前帧时间 - 上一帧时间 >
  // 阈值(默认0.04s))
  DATA_OGM_DETECTION_FRAME_TIME_ERROR = 10054_l3,

  // 局部检测数据订阅
  // 数据错误
  DATA_LOCAL_DETECTION_ERROR = 10060_l3,
  // 数据接收超时
  DATA_LOCAL_DETECTION_TIMEOUT = 10061_l3,
  // 数据时间戳异常
  DATA_LOCAL_DETECTION_TIME_ABNORMAL = 10062_l3,
  // 数据延迟过大 (接收时间 - 里程计时间 > 阈值)
  DATA_LOCAL_DETECTION_TIME_DELAY = 10063_l3,
  // 数据前后帧时间差过大 (当前帧时间 - 上一帧时间 >
  // 阈值(默认0.04s))
  DATA_LOCAL_DETECTION_FRAME_TIME_ERROR = 10064_l3,

  // 全局轨迹数据订阅
  // 数据错误
  DATA_GLOBAL_TRAJECTORY_ERROR = 10070_l3,
  // 数据接收超时
  DATA_GLOBAL_TRAJECTORY_TIMEOUT = 10071_l3,
  // 数据时间戳异常
  DATA_GLOBAL_TRAJECTORY_TIME_ABNORMAL = 10072_l3,
  // 数据延迟过大 (接收时间 - 里程计时间 > 阈值)
  DATA_GLOBAL_TRAJECTORY_TIME_DELAY = 10073_l3,
  // 数据前后帧时间差过大 (当前帧时间 - 上一帧时间 >
  // 阈值(默认0.04s))
  DATA_GLOBAL_TRAJECTORY_FRAME_TIME_ERROR = 10074_l3,

  // 局部轨迹数据订阅
  // 数据错误
  DATA_LOCAL_TRAJECTORY_ERROR = 10080_l3,
  // 数据接收超时
  DATA_LOCAL_TRAJECTORY_TIMEOUT = 10081_l3,
  // 数据时间戳异常
  DATA_LOCAL_TRAJECTORY_TIME_ABNORMAL = 10082_l3,
  // 数据延迟过大 (接收时间 - 里程计时间 > 阈值)
  DATA_LOCAL_TRAJECTORY_TIME_DELAY = 10083_l3,
  // 数据前后帧时间差过大 (当前帧时间 - 上一帧时间 >
  // 阈值(默认0.04s))
  DATA_LOCAL_TRAJECTORY_FRAME_TIME_ERROR = 10084_l3,

  // 局部状态数据订阅
  // 数据错误
  DATA_TRAJECTORY_STATE_ERROR = 10090_l3,
  // 数据接收超时
  DATA_TRAJECTORY_STATE_TIMEOUT = 10091_l3,
  // 数据时间戳异常
  DATA_TRAJECTORY_STATE_TIME_ABNORMAL = 10092_l3,
  // 数据延迟过大 (接收时间 - 里程计时间 > 阈值)
  DATA_TRAJECTORY_STATE_TIME_DELAY = 10093_l3,
  // 数据前后帧时间差过大 (当前帧时间 - 上一帧时间 >
  // 阈值(默认0.04s))
  DATA_TRAJECTORY_STATE_FRAME_TIME_ERROR = 10094_l3,

  // 车辆控制数据订阅
  // 数据错误
  DATA_CONTROL_ERROR = 10100_l3,
  // 数据接收超时
  DATA_CONTROL_TIMEOUT = 10101_l3,
  // 数据时间戳异常
  DATA_CONTROL_TIME_ABNORMAL = 10102_l3,
  // 数据延迟过大 (接收时间 - 里程计时间 > 阈值)
  DATA_CONTROL_TIME_DELAY = 10103_l3,
  // 数据前后帧时间差过大 (当前帧时间 - 上一帧时间 >
  // 阈值(默认0.04s))
  DATA_CONTROL_FRAME_TIME_ERROR = 10104_l3,

  // 车辆底盘反馈数据订阅
  // 数据错误
  DATA_CAR_ORI_ERROR = 10110_l3,
  // 数据接收超时
  DATA_CAR_ORI_TIMEOUT = 10111_l3,
  // 数据时间戳异常
  DATA_CAR_ORI_TIME_ABNORMAL = 10112_l3,
  // 数据延迟过大 (接收时间 - 里程计时间 > 阈值)
  DATA_CAR_ORI_TIME_DELAY = 10113_l3,
  // 数据前后帧时间差过大 (当前帧时间 - 上一帧时间 >
  // 阈值(默认0.04s))
  DATA_CAR_ORI_FRAME_TIME_ERROR = 10114_l3,

  // 车辆到达终点数据订阅
  // 数据错误
  DATA_CROSS_GOAL_ERROR = 10120_l3,
  // 数据接收超时
  DATA_CROSS_GOAL_TIMEOUT = 10121_l3,
  // 数据时间戳异常
  DATA_CROSS_GOAL_TIME_ABNORMAL = 10122_l3,
  // 数据延迟过大 (接收时间 - 里程计时间 > 阈值)
  DATA_CROSS_GOAL_TIME_DELAY = 10123_l3,
  // 数据前后帧时间差过大 (当前帧时间 - 上一帧时间 >
  // 阈值(默认0.04s))
  DATA_CROSS_GOAL_FRAME_TIME_ERROR = 10124_l3,

  // 机械臂状态数据订阅
  // 数据错误
  DATA_ARM_ORI_ERROR = 10130_l3,
  // 数据接收超时
  DATA_ARM_ORI_TIMEOUT = 10131_l3,
  // 数据时间戳异常
  DATA_ARM_ORI_TIME_ABNORMAL = 10132_l3,
  // 数据延迟过大 (接收时间 - 里程计时间 > 阈值)
  DATA_ARM_ORI_TIME_DELAY = 10133_l3,
  // 数据前后帧时间差过大 (当前帧时间 - 上一帧时间 >
  // 阈值(默认0.04s))
  DATA_ARM_ORI_FRAME_TIME_ERROR = 10134_l3,

  // 机械臂控制数据订阅
  // 数据错误
  DATA_ARM_CONTROL_ERROR = 10140_l3,
  // 数据接收超时
  DATA_ARM_CONTROL_TIMEOUT = 10141_l3,
  // 数据时间戳异常
  DATA_ARM_CONTROL_TIME_ABNORMAL = 10142_l3,
  // 数据延迟过大 (接收时间 - 里程计时间 > 阈值)
  DATA_ARM_CONTROL_TIME_DELAY = 10143_l3,
  // 数据前后帧时间差过大 (当前帧时间 - 上一帧时间 >
  // 阈值(默认0.04s))
  DATA_ARM_CONTROL_FRAME_TIME_ERROR = 10144_l3,

  // 机械臂任务状态数据订阅
  // 数据错误
  DATA_ARM_TASK_STATE_ERROR = 10150_l3,
  // 数据接收超时
  DATA_ARM_TASK_STATE_TIMEOUT = 10151_l3,
  // 数据时间戳异常
  DATA_ARM_TASK_STATE_TIME_ABNORMAL = 10152_l3,
  // 数据延迟过大 (接收时间 - 里程计时间 > 阈值)
  DATA_ARM_TASK_STATE_TIME_DELAY = 10153_l3,
  // 数据前后帧时间差过大 (当前帧时间 - 上一帧时间 >
  // 阈值(默认0.04s))
  DATA_ARM_TASK_STATE_FRAME_TIME_ERROR = 10154_l3,


  // 任务终点数据订阅
  // 数据错误
  DATA_TASK_GOAL_ERROR = 10160_l3,
  // 数据接收超时
  DATA_TASK_GOAL_TIMEOUT = 10161_l3,
  // 数据时间戳异常
  DATA_TASK_GOAL_TIME_ABNORMAL = 10162_l3,
  // 数据延迟过大 (接收时间 - 里程计时间 > 阈值)
  DATA_TASK_GOAL_TIME_DELAY = 10163_l3,
  // 数据前后帧时间差过大 (当前帧时间 - 上一帧时间 >
  // 阈值(默认0.04s))
  DATA_TASK_GOAL_FRAME_TIME_ERROR = 10164_l3,

  // 任务类型数据订阅
  // 数据错误
  DATA_TASK_TYPE_ERROR = 10170_l3,
  // 数据接收超时
  DATA_TASK_TYPE_TIMEOUT = 10171_l3,
  // 数据时间戳异常
  DATA_TASK_TYPE_TIME_ABNORMAL = 10172_l3,
  // 数据延迟过大 (接收时间 - 里程计时间 > 阈值)
  DATA_TASK_TYPE_TIME_DELAY = 10173_l3,
  // 数据前后帧时间差过大 (当前帧时间 - 上一帧时间 >
  // 阈值(默认0.04s))
  DATA_TASK_TYPE_FRAME_TIME_ERROR = 10174_l3,
  
  // Guardian
  //**** 这几个文档未定义，先用l1等级 ****
  GUARDIAN_TOPICS_TIMEOUT = 6000_l1,
  GUARDIAN_AEB = 6002_l1,
  GUARDIAN_LOCALIZATION_JUMPING = 6003_l1,
  GUARDIAN_SEASIDE = 6004_l1,
  GUARDIAN_SNAKING = 6005_l1,
  GUARDIAN_CHASSIS_DELAY = 6006_l1,
  GUARDIAN_SHARP_STEERING = 6007_l1,
  GUARDIAN_OBJECTS_CHANGE_COLLISION = 6008_l1,
  GUARDIAN_TIMEOUT_VEHICLE_INFO2 = 6020_l1,
  GUARDIAN_TIMEOUT_VEHICLE_STATE = 6021_l1,
  GUARDIAN_TIMEOUT_OG = 6022_l1,
  GUARDIAN_TIMEOUT_OBJECTS = 6023_l1,
  GUARDIAN_TIMEOUT_PLANNING_CMD = 6024_l1,
  GUARDIAN_TIMEOUT_VEHICLE_CMD = 6025_l1,
  GUARDIAN_OFFLINE = 6998_l1,
  GUARDIAN_OTHERS = 6999_l1,
  //**** 这几个文档未定义，先用l1等级 ****

  GLOBAL_PATH_PLANNING_LAUNCH_CONFIG_LOAD_FAILED = 9001_l3,
  // 1.1.1 文件不存在
  GLOBAL_PATH_PLANNING_LAUNCH_CONFIG_FILE_NOT_FOUND = 9002_l3,
  // 1.1.2 文件参数错误
  GLOBAL_PATH_PLANNING_LAUNCH_CONFIG_FILE_PARAM_ERROR = 9003_l3,
  // 1.2 ROS参数加载失败
  GLOBAL_PATH_PLANNING_LAUNCH_PARAM_LOAD_FAILED = 9010_l3,
  // 1.2.1 参数获取失败
  GLOBAL_PATH_PLANNING_LAUNCH_PARAM_GET_FAILED = 9011_l3,
  // 1.2.2 参数值错误
  GLOBAL_PATH_PLANNING_LAUNCH_PARAM_VALUE_ERROR = 9012_l3,
  
  //GPS
  RTK_LAUNCH_CONFIG_LOAD_FAILED = 10001_l3,
  // 1.1.1 文件不存在
  RTK_LAUNCH_CONFIG_FILE_NOT_FOUND = 10002_l3,
  // 1.1.2 文件参数错误
  RTK_LAUNCH_CONFIG_FILE_PARAM_ERROR = 10003_l3,
  // 1.2 ROS参数加载失败
  RTK_LAUNCH_PARAM_LOAD_FAILED = 10010_l3,
  // 1.2.1 参数获取失败
  RTK_LAUNCH_PARAM_GET_FAILED = 10011_l3,
  // 1.2.2 参数值错误
  RTK_LAUNCH_PARAM_VALUE_ERROR = 10012_l3,

  //slam ndt
  SLAM_NDT_LAUNCH_CONFIG_LOAD_FAILED = 10101_l3,
  // 1.1.1 文件不存在
  SLAM_NDT_LAUNCH_CONFIG_FILE_NOT_FOUND = 10102_l3,
  // 1.1.2 文件参数错误
  SLAM_NDT_LAUNCH_CONFIG_FILE_PARAM_ERROR = 10103_l3,
  // 1.2 ROS参数加载失败
  SLAM_NDT_LAUNCH_PARAM_LOAD_FAILED = 10110_l3,
  // 1.2.1 参数获取失败
  SLAM_NDT_LAUNCH_PARAM_GET_FAILED = 10111_l3,
  // 1.2.2 参数值错误
  SLAM_NDT_LAUNCH_PARAM_VALUE_ERROR = 10112_l3,

  //fusion ndt
  FUSION_NDT_LAUNCH_CONFIG_LOAD_FAILED = 10201_l3,
  // 1.1.1 文件不存在
  FUSION_NDT_LAUNCH_CONFIG_FILE_NOT_FOUND = 10202_l3,
  // 1.1.2 文件参数错误
  FUSION_NDT_LAUNCH_CONFIG_FILE_PARAM_ERROR = 10203_l3,
  // 1.2 ROS参数加载失败
  FUSION_NDT_LAUNCH_PARAM_LOAD_FAILED = 10210_l3,
  // 1.2.1 参数获取失败
  FUSION_NDT_LAUNCH_PARAM_GET_FAILED = 10211_l3,
  // 1.2.2 参数值错误
  FUSION_NDT_LAUNCH_PARAM_VALUE_ERROR = 10212_l3,

  //V2N
  V2N_LAUNCH_CONFIG_LOAD_FAILED = 10301_l3,
  // 1.1.1 文件不存在
  V2N_LAUNCH_CONFIG_FILE_NOT_FOUND = 10302_l3,
  // 1.1.2 文件参数错误
  V2N_LAUNCH_CONFIG_FILE_PARAM_ERROR = 10303_l3,
  // 1.2 ROS参数加载失败
  V2N_LAUNCH_PARAM_LOAD_FAILED = 10310_l3,
  // 1.2.1 参数获取失败
  V2N_LAUNCH_PARAM_GET_FAILED = 10311_l3,
  // 1.2.2 参数值错误
  V2N_LAUNCH_PARAM_VALUE_ERROR = 10312_l3,

  //local planning
  LOCAL_PLANNING_LAUNCH_CONFIG_LOAD_FAILED = 10401_l3,
  // 1.1.1 文件不存在
  LOCAL_PLANNING_LAUNCH_CONFIG_FILE_NOT_FOUND = 10402_l3,
  // 1.1.2 文件参数错误
  LOCAL_PLANNING_LAUNCH_CONFIG_FILE_PARAM_ERROR = 10403_l3,
  // 1.2 ROS参数加载失败
  LOCAL_PLANNING_LAUNCH_PARAM_LOAD_FAILED = 10410_l3,
  // 1.2.1 参数获取失败
  LOCAL_PLANNING_LAUNCH_PARAM_GET_FAILED = 10411_l3,
  // 1.2.2 参数值错误
  LOCAL_PLANNING_LAUNCH_PARAM_VALUE_ERROR = 10412_l3,

  //轨迹跟踪
  TRAJECTORY_TRACKING_LAUNCH_CONFIG_LOAD_FAILED = 10501_l3,
  // 1.1.1 文件不存在
  TRAJECTORY_TRACKING_LAUNCH_CONFIG_FILE_NOT_FOUND = 10502_l3,
  // 1.1.2 文件参数错误
  TRAJECTORY_TRACKING_LAUNCH_CONFIG_FILE_PARAM_ERROR = 10503_l3,
  // 1.2 ROS参数加载失败
  TRAJECTORY_TRACKING_LAUNCH_PARAM_LOAD_FAILED = 10510_l3,
  // 1.2.1 参数获取失败
  TRAJECTORY_TRACKING_LAUNCH_PARAM_GET_FAILED = 10511_l3,
  // 1.2.2 参数值错误
  TRAJECTORY_TRACKING_LAUNCH_PARAM_VALUE_ERROR = 10512_l3,

  //perception
  PERCEPTION_LAUNCH_CONFIG_LOAD_FAILED = 10601_l3,
  // 1.1.1 文件不存在
  PERCEPTION_LAUNCH_CONFIG_FILE_NOT_FOUND = 10602_l3,
  // 1.1.2 文件参数错误
  PERCEPTION_LAUNCH_CONFIG_FILE_PARAM_ERROR = 10603_l3,
  // 1.2 ROS参数加载失败
  PERCEPTION_LAUNCH_PARAM_LOAD_FAILED = 10610_l3,
  // 1.2.1 参数获取失败
  PERCEPTION_LAUNCH_PARAM_GET_FAILED = 10611_l3,
  // 1.2.2 参数值错误
  PERCEPTION_LAUNCH_PARAM_VALUE_ERROR = 10612_l3,

  //fork_arm_control
  FORK_ARM_CONTROL_LAUNCH_CONFIG_LOAD_FAILED = 10701_l3,
  // 1.1.1 文件不存在
  FORK_ARM_CONTROL_LAUNCH_CONFIG_FILE_NOT_FOUND = 10702_l3,
  // 1.1.2 文件参数错误
  FORK_ARM_CONTROL_LAUNCH_CONFIG_FILE_PARAM_ERROR = 10703_l3,
  // 1.2 ROS参数加载失败
  FORK_ARM_CONTROL_LAUNCH_PARAM_LOAD_FAILED = 10710_l3,
  // 1.2.1 参数获取失败
  FORK_ARM_CONTROL_LAUNCH_PARAM_GET_FAILED = 10711_l3,
  // 1.2.2 参数值错误
  FORK_ARM_CONTROL_LAUNCH_PARAM_VALUE_ERROR = 10712_l3,

  //car_ori_data
  CAR_ORI_DATA_LAUNCH_CONFIG_LOAD_FAILED = 10801_l3,
  // 1.1.1 文件不存在
  CAR_ORI_DATA_LAUNCH_CONFIG_FILE_NOT_FOUND = 10802_l3,
  // 1.1.2 文件参数错误
  CAR_ORI_DATA_LAUNCH_CONFIG_FILE_PARAM_ERROR = 10803_l3,
  // 1.2 ROS参数加载失败
  CAR_ORI_DATA_LAUNCH_PARAM_LOAD_FAILED = 10810_l3,
  // 1.2.1 参数获取失败
  CAR_ORI_DATA_LAUNCH_PARAM_GET_FAILED = 10811_l3,
  // 1.2.2 参数值错误
  CAR_ORI_DATA_LAUNCH_PARAM_VALUE_ERROR = 10812_l3,

  //car_ori_control
  CAR_ORI_CONTROL_LAUNCH_CONFIG_LOAD_FAILED = 10901_l3,
  // 1.1.1 文件不存在
  CAR_ORI_CONTROL_LAUNCH_CONFIG_FILE_NOT_FOUND = 10902_l3,
  // 1.1.2 文件参数错误
  CAR_ORI_CONTROL_LAUNCH_CONFIG_FILE_PARAM_ERROR = 10903_l3,
  // 1.2 ROS参数加载失败
  CAR_ORI_CONTROL_LAUNCH_PARAM_LOAD_FAILED = 10910_l3,
  // 1.2.1 参数获取失败
  CAR_ORI_CONTROL_LAUNCH_PARAM_GET_FAILED = 10911_l3,
  // 1.2.2 参数值错误
  CAR_ORI_CONTROL_LAUNCH_PARAM_VALUE_ERROR = 10912_l3,
};

// 算法初始化 异常
// 算法入参 输入值 输入时间 异常
// 算法计算逻辑 异常
// 算法输出值 异常
}  // namespace common
}  // namespace tju