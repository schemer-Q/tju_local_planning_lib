#include "common/util/motion.h"

namespace tju {
namespace common {

const Eigen::Isometry3f GetTF(const geometry_msgs::msg::PoseStamped& priorPose,
                              const geometry_msgs::msg::PoseStamped& postPose) {
  struct Pose prior, post;
  prior.position(0) = priorPose.pose.position.x;
  prior.position(1) = priorPose.pose.position.y;
  prior.position(2) = priorPose.pose.position.z;
  prior.orientation.x() = priorPose.pose.orientation.x;
  prior.orientation.y() = priorPose.pose.orientation.y;
  prior.orientation.z() = priorPose.pose.orientation.z;
  prior.orientation.w() = priorPose.pose.orientation.w;
  post.position(0) = postPose.pose.position.x;
  post.position(1) = postPose.pose.position.y;
  post.position(2) = postPose.pose.position.z;
  post.orientation.x() = postPose.pose.orientation.x;
  post.orientation.y() = postPose.pose.orientation.y;
  post.orientation.z() = postPose.pose.orientation.z;
  post.orientation.w() = postPose.pose.orientation.w;
  prior.toMatrix();
  post.toMatrix();
  Eigen::Matrix4f TF = post.mat.inverse() * prior.mat;
  Eigen::Isometry3f tf = Eigen::Isometry3f::Identity();
  tf.rotate(TF.block<3, 3>(0, 0));
  tf.pretranslate(TF.block<3, 1>(0, 3));
  return tf;
}

}  // namespace common
}  // namespace tju
