#pragma once

#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Eigen>
#include <geometry_msgs/msg/pose_stamped.hpp>

namespace tju {
namespace common {

struct Pose {
  EIGEN_MAKE_ALIGNED_OPERATOR_NEW

  double timestamp = 0.0;

  Eigen::Vector3f position;

  Eigen::Quaternionf orientation;

  Eigen::Matrix4f mat = Eigen::Matrix4f::Identity();

  void toMatrix() {
    mat.block<3, 3>(0, 0) = orientation.matrix();
    mat.block<3, 1>(0, 3) = position;
  }
};

typedef std::shared_ptr<Pose> PosePtr;
typedef std::shared_ptr<const Pose> PoseConstPtr;

const Eigen::Isometry3f GetTF(const geometry_msgs::msg::PoseStamped& priorPose,
                              const geometry_msgs::msg::PoseStamped& postPose);

}  // namespace common
}  // namespace tju
