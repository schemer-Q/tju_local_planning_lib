#ifndef SUNTAE_COMMON_SINGLETON_H
#define SUNTAE_COMMON_SINGLETON_H

#include <memory>
#include <mutex>

#include <utility>

namespace tju {
namespace common {
template <typename T>
class Singleton {
 public:
  static T& GetInstance() {
    static std::unique_ptr<T> instance = std::make_unique<T>();
    return *instance;
  }

  Singleton(const Singleton&) = delete;
  Singleton(Singleton&&) = delete;
  Singleton& operator=(const Singleton&) = delete;
  Singleton& operator=(Singleton&&) = delete;

 protected:
  Singleton() = default;
  ~Singleton() = default;
};

}  // namespace common
}  // namespace tju

#endif  // SUNTAE_COMMON_SINGLETON_H