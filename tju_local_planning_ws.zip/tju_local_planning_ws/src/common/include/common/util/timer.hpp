#pragma once

#include <chrono>

namespace tju {
namespace common {

class Timer {
 public:
  Timer() : start_(std::chrono::high_resolution_clock::now()) {}

  void Reset() { start_ = std::chrono::high_resolution_clock::now(); }

  /**
   * @brief 获取经过的时间
   * @return 毫秒
   */
  [[nodiscard]] long long Elapsed() const {
    auto end = std::chrono::high_resolution_clock::now();
    return std::chrono::duration_cast<std::chrono::milliseconds>(end - start_).count();
  }

 private:
  std::chrono::time_point<std::chrono::high_resolution_clock> start_;
};

}}