#pragma once

#include <string>
#ifdef OLD_GCC
#include <experimental/filesystem>
#else
#include <filesystem>
#endif

/**
 * @brief 判断文件是否存在
 * 
 * @param path [in] 文件路径
 * @return true 文件存在
 * @return false 文件不存在
 */
inline bool is_file_exist(const std::string& path) {
#ifdef OLD_GCC
    return std::experimental::filesystem::exists(path);
#else
    return std::filesystem::exists(path);
#endif
}


// // 处理单个 MyStruct
// void process(const LocalPath& s) {
//     std::cout << "Struct: " << s.value << ", " << s.name << "\n";
// }

// void process(const TaskType& s) {
//     std::cout << "Struct: " << s.value << ", " << s.name << "\n";
// }

// // 处理其他类型
// template<typename T>
// void process(const T& value) {
//     std::cout << "Other: " << value << "\n";
// }

// // 可变参数模板函数
// template<typename T, typename... Args>
// std::uint32_t Run(T first, Args&&... args) {
//     (process(std::forward<Args>(args)), ...);  // 折叠表达式调用 process
// }


// #include <utility>
// #include <cstdint>
// #include <iostream>

// // 处理特定类型的函数（示例）
// std::uint32_t process(const LocalPath& s) {
//     std::cout << "Processing LocalPath: " << s.value << ", " << s.name << "\n";
//     return 0; // 成功处理返回0
// }

// std::uint32_t process(const TaskType& s) {
//     std::cout << "Processing TaskType: " << s.value << ", " << s.name << "\n";
//     return 0; // 成功处理返回0
// }

// // 处理其他类型的函数模板
// template<typename T>
// std::uint32_t process(const T& value) {
//     std::cout << "Unsupported type: " << typeid(value).name() << "\n";
//     return 1; // 未处理类型返回错误码1
// }

// // 可变参数模板函数，收集所有处理结果
// template<typename... Args>
// std::uint32_t Run(Args&&... args) {
//     std::uint32_t results[] = {process(std::forward<Args>(args))...};
    
//     // 检查是否有非零返回值（错误）
//     for (auto result : results) {
//         if (result != 0) return result;
//     }
    
//     return 0; // 全部成功
// }