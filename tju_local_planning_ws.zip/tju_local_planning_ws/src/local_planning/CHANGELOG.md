# CHANGELOG

所有项目的显著变更都将记录在此文件中。

格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.0.0/)

> Added 新添加的功能。
> Changed 对现有功能的变更。
> Deprecated 已经不建议使用，即将移除的功能。
> Removed 已经移除的功能。
> Fixed 对 bug 的修复。
> Security 对安全性的改进。

并且本项目遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

> 主版本号：当你做了不兼容的 API 修改，
> 次版本号：当你做了向下兼容的功能性新增，
> 修订号：当你做了向下兼容的问题修正。

## [Unreleased]

## [0.4.1] - 2025-01-23
### Fixed
- 修改环视目标与融合目标匹配逻辑，解决非fov边界处侧向、后向融合目标丢失问题（着重关注 非激光fov边界处 目标丢失问题）[VTI-15113][VTI-15115][VTI-15127][VTI-15119]
- 优化目标存在性更新逻辑，解决环视目标闪烁（短暂丢失）,毫米波测量存在的情况下融合目标丢失问题
- 优化车道线跟踪参数,解决跟踪丢失跳变问题
### Dependencies
- trunk_perception = 0.4.1

## [0.4.0] - 2025-01-22
### Added
- 增加前向多模态检测任务(默认关闭,模型性能评估完成具备上线标准后再替换前向激光模型)
### Fixed
- 图像数据接收延迟诊断阈值从0.2s调整到0.25s[VTI-15068]
- ### Dependencies
- trunk_perception = 0.4.0
- pointpillar-sparse4d-1l1v = 0.0.1 (新增)
- detectionnetsdk = 0.0.4

## [0.3.5] - 2025-01-21
### Changed
- 修改环视视觉与激光雷达时间戳差值判断阈值，解决融合无环视输出问题
### Fixed
- 修改角毫米波使用区域划分逻辑
- 优化融合逻辑中目标存在性逻辑，解决融合无环视输出问题
### Dependencies
- trunk_perception = 0.3.5

## [0.3.4] - 2025-01-21
### Changed
- 跟踪目标中添加bbox confidence
- 跟踪目标中添加bbox theta confidence
- 跟踪目标中添加velocity confidence
- 跟踪目标中添加目标相对于自车的运动方向
- 跟踪算法中滤除速度异常的跟踪目标以减少检测不稳定导致的跟踪异常目标
- 跟踪算法中对目标预测添加约束已解决目标预测横飞的问题[VTI-14421][VTI-14688][VTI-14471]

## [0.3.3] - 2025-01-20
### Added
- 后融合中增加环视，激光建立的目标运动到自车后方，无激光测量后，也可维持正常输出
- 后融合中增加角毫米波
- 录制话题文件中增加环视相关话题名
### Fixed
- 激光匹配逻辑中，增加自车坐标系下横向位置差值限制，解决激光误匹配问题造成目标跳动：VTI-14613
- 后融合中修改前向毫米波使用策略，解决由于毫米波反射点位于目标车辆不同位置（后中点、侧后方、侧方）造成的融合目标跳动
### Dependencies
- trunk_perception = 0.3.3

## [0.3.2] - 2025-01-20
### Added
- 车道线更新为120m版本
- 车道线增加置信度输出
- 车道线后处理关闭hold on
### Dependencies
- trunk_perception = 0.3.2
- sdkbevlaneconedethighway = 0.3.3.8
- bevlaneconemodel = 1.4.23

## [0.3.1] - 2025-01-16
### Added
- 增加车道线2D Debug图像输出[VTI-14820]

## [0.3.0] - 2025-01-15
### Added
- 增加side_vision_detection任务，用于检测环视视觉目标
- 增加主从机启动文件,`sany_1_master.launch`和`sany_1_slave.launch`,节点名称分别为`per_master`和`per_slave`
- 物体类别定义变更, 新增TRICYCLE=5, CONE=6, BARRAL=7,OTHERS=40
- 添加dr前后帧时间差的诊断(默认阈值为0.04s),故障码为4264_l3
- 激光模型增加了cone被barrel输出
### Changed
- 调整dr数据断流诊断阈值为0.1s
- 激光模型优化了绿化带等背景误检问题
- 车道线修复偏左问题
- 激光跟踪优化预测导致的横向误检问题
- 后融合优化毫米波雷达噪点误匹配问题
- 后融合优化近距离目标入侵车道问题
- 后融合优化激光误检导致的虚假漂移目标问题
- 后融合优化激光模型输出的角度跳变导致的入侵车道问题
- 后融合修复目标theta角度归一化bug可能导致未知异常
### Dependencies
- trunk_perception = 0.3.1
- detectionnetsdk = 0.0.3
- sparse4d = 1.3.0
- lidarnetsdk = 1.0.5
- hw_dsvt_model = 1.1.12
- bevlaneconemodel = 1.1.7

## [0.2.0] - 2025-01-03
### Added
- 后融合中增加前向视觉
- 后融合对激光测量类型、前向视觉测量类型增加滑动窗口滤波
- 后融合增加1L1R1V(基于前向激光测量、前向视觉测量、前向毫米波测量)的融合目标存在性更新逻辑
### Fixed
- 修改激光测量与融合目标的匹配阈值
- 修改前向毫米波测量与融合目标的匹配距离计算逻辑
- 优化融合目标角点计算逻辑
### Dependencies
- trunk_perception = 0.2.0

## [0.1.3] - 2025-01-02
### Fixed
- 更新模型到v1.1.11
- 修复DSVT模型fp32和fp16精度有差异的问题，发版fp32精度的模型
### Dependencies
- hw_dsvt_model = 1.1.11

## [0.1.3] - 2025-01-03
### Added
- 后融合中增加前向视觉
- 对激光测量类型、前向视觉测量类型增加滑动窗口滤波
- 增加1L1R1V(基于前向激光测量、前向视觉测量、前向毫米波测量)的融合目标存在性更新逻辑
### Fixed
- 修改激光测量与融合目标的匹配阈值
- 修改前向毫米波测量与融合目标的匹配距离计算逻辑
- 优化融合目标角点计算逻辑
### Dependencies
- trunk_perception = 0.2.0

## [0.1.2] - 2024-12-12
### Fixed
- 更新模型到v1.1.10
- 优化老年代步车、三轮车漏检的问题
- 优化货车怼脸丢失的问题
- 相机数据接收latency阈值调整到0.2s
- 修复若干算法库中的不规范代码
### Dependencies
- trunk_perception = 0.1.9
- hw_dsvt_model = 1.1.10

## [0.1.1] - 2024-12-09
### Fixed
- 修复为彪角毫米波数量问题导致的per崩溃问题
- 修复FATAL等级日志无法落盘问题
### Dependencies
- trunk_perception = 0.1.8

## [0.1.0] - 2024-12-06
### Added
- 添加前向视觉检测任务和后处理跟踪任务(关闭状态，待下游适配完成可开启)
- 增加角毫米波可视化节点
### Dependencies
- trunk_perception = 0.1.7

## [0.0.10] - 2024-12-05
### Fixed
- 修复近距离货车激光测量丢失后融合无输出问题
### Dependencies
- trunk_perception = 0.1.6

## [0.0.9] - 2024-11-27
### Fixed
- 适配为彪角雷达传感器
### Dependencies
- trunk_perception = 0.1.5

## [0.0.8] - 2024-11-22
### Changed
- 调整传感器数据超时诊断阈值(lidar:0.5s、camera:0.5s、dr:0.2s、radar:0.7s)
### Added
- 添加地面检测和聚类检测功能(默认关闭，可通过参数打开)
### Fixed
- 车道线conf临时赋值1
### Dependencies
- trunk_perception = 0.1.4

## [0.0.7] - 2024-11-19
### Fixed
- 适配不同参数的相机畸变模型
### Dependencies
- trunk_perception = 0.1.2

## [0.0.6] - 2024-11-18
### Fixed
- 关闭角毫米波雷达相关诊断
- 修复后融合模块ID池耗尽问题
### Dependencies
- trunk_perception = 0.1.1

## [0.0.5] - 2024-11-1
### Added
- 增加后融合模块
### Dependencies
- trunk_perception = 0.1.0

## [0.0.4] - 2024-10-24
### Fixed
- 由于点云类型内存对齐导致未获取到点云强度信息(解决模型结果退化问题)

## [0.0.3] - 2024-10-22
### Added
- 添加感知软件启动错误、上游数据错误、激光处理相关算法错误的故障诊断

## [0.0.2] - 2024-10-17
### Changed
- 添加并使用基于CV模型的尾边中点跟踪方法
- 优化匹配算法解决相邻两个目标存在误匹配导致出现较大横向速度的问题

## [0.0.1] - 2024-10-16

### Added

- 初始版本发布
