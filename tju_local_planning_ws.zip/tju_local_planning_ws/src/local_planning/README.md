# 局部规划模块

## 开发进展

## 使用

### 编译

### 运行

#### 系统集成


#### 开发测试
subscriber.hpp
data_manager.hpp
publisher

# 启动lidar驱动等必要节点,例如:


# 如果使用roslaunch启动，则运行:
ros2 launch local_planning local_planning.launch.py

# 输入
# 1.全局轨迹
话题名称：/planning/global_trajectory
消息定义（全局轨迹）：tju_auto/src/tju_msgs/planning_msgs/msg/TrajectoryPoints.msg
# 2.融合定位
话题名称：/location/fusion_location
消息定义：nav_msgs/msg/Odommetry
# 3.底盘反馈
话题名称：/chassis/car_ori_data
消息定义：tju_auto/src/tju_msgs/chassis_msgs/msg/CarOriInterface.msg
# 4.OG
话题名称：/perception/og_points
OG点消息定义：tju_auto/src/tju_msgs/perception_msgs/msg/OgmPoint.msg 
# 5.智驾感知
话题名称：/perception/objects
消息定义：tju_auto/src/tju_msgs/perception_msgs/msg/Object.msg  
# 6.局部检测
话题名称：/perception_task/align_target
目标位姿定义：tju_auto/src/perception_task_msgs/msg/TargetPose.msg
# 7.到达终点
话题名称：/control/cross_goal
消息定义：tju_auto/src/tju_msgs/control_msgs/CrossGoal.msg

# 输出
# 1.局部轨迹
  话题名称：/planning/local_trajectory
  局部轨迹消息定义：tju_auto/src/tju_msgs/planning_msgs/msg/LocalTrajectoryPoints.msg

# 2.局部状态 
  话题名称：/planning/trajectory_state
  消息定义：tju_auto/src/tju_msgs/planning_msgs/msg/TrajectoryState.msg


## 故障处理

- 故障码代码定义: [error_code.h](../common/include/common/error_code.h)

### 故障码定义

> 此处主要列出设计逻辑，具体故障码定义请参考手册或代码定义。
> 当没有必要创建子类别时，可以直接用大类的故障码及其对应逻辑。


### 故障码添加

1. 在故障查询手册中添加故障码定义
2. 在代码中添加故障码定义
3. 在代码中添加故障码判断逻辑和故障上报逻辑
4. 提交代码并联系`PNC`同学添加故障处理逻辑
