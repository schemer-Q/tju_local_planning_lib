#pragma once

#include "rclcpp/rclcpp.hpp"
#include "local_planning/t_log.hpp"

namespace local_planning {

inline bool InitLogger(std::shared_ptr<rclcpp::Node> node) {
  // 从节点参数中读取日志路径
  // std::string local_planning_log_path = node->get_parameter("Log.LocalPlanningPath").as_string();
  // std::string common_log_path = node->get_parameter("Log.CommonPath").as_string();
  std::string local_planning_log_path = "/home/nvidia/tju_local_planning_ws/log/local_planning/local_planning.log";
  std::string common_log_path = "/home/nvidia/tju_local_planning_ws/log/common/common.log";
  // 如果路径为空，使用默认值
  if (local_planning_log_path.empty()) {
    return false;  // 如果本地规划日志路径为空，返回false
  }
  
  if (common_log_path.empty()) {
    return false;  // 如果公共日志路径为空，返回false
  }
  
  LOGINIT(local_planning_log_path.c_str(), jian::logging::level_enum::info, 20, "local_planning");
  LOGINIT(common_log_path.c_str(), jian::logging::level_enum::info, 20, "common");
  
  NTINFO << "[Init] Log initialized: log path " << local_planning_log_path;
  NTINFO << "[Init] Log initialized: log path " << common_log_path;
  return true;
}

}  // namespace local_planning
