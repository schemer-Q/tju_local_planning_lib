#pragma once

#include "jian/jian.h"
namespace local_planning {
class TLog {
 public:

    static void init(const char* log_file_path = "/var/log/common.log",
                     int32_t level = jian::logging::level_enum::trace,
                     int32_t max_file_num = 20,
                     const char* logger_name = "common") {
        auto my_term_sink = jian::logging::create_sink<jian::logging::sinks::stdout_color_sink_st>();
        auto my_file_sink = jian::logging::create_sink<jian::logging::sinks::rotating_dispatch_files_sink_mt>(
            log_file_path, 1 << 20, max_file_num);
        auto my_logger = jian::logging::register_logger(logger_name, {my_term_sink, my_file_sink});
        my_logger->set_level(static_cast<jian::logging::level_enum>(level));
        my_logger->flush_on(jian::logging::level_enum::err);
    }
};


/**
 * @brief log init function, use it when your process started
 * @param log_file_path [const char *] log file saved path, default: "/var/log/port_local_planning.log"
 * @param level [int32_t] minimum level to logging, default: jian::logging::level_enum::trace
 * @param max_file_num [int32_t] max file number (each file's max size is 1Mb), default: 20
 */
#define LOGINIT(...) TLog::init(__VA_ARGS__)


/**
 * @brief trace level log, e.g. NTTRACE << "trace info";
 * @ingroup tools_t_log
 */
#define NTTRACE JLOGGER_TRACE_S("local_planning")
/**
 * @brief debug level log, e.g. NTDEBUG << "debug info";
 * @ingroup tools_t_log
 */
#define NTDEBUG JLOGGER_DEBUG_S("local_planning")
/**
 * @brief info level log, e.g. NTINFO << "info info";
 *  @ingroup tools_t_log
 */
#define NTINFO JLOGGER_INFO_S("local_planning")
/**
 * @brief warning level log, e.g. NTWARNING << "info info";
 * @ingroup tools_t_log
 */
#define NTWARNING JLOGGER_WARN_S("local_planning")
/**
 * @brief error level log, e.g. NTERROR << "error info";
 * @ingroup tools_t_log
 */
#define NTERROR JLOGGER_ERROR_S("local_planning")
/**
 * @brief fatal level log, e.g. NTFATAL << "fatal info";
 * @ingroup tools_t_log
 */
#define NTFATAL JLOGGER_CRITICAL_S("local_planning")
}

