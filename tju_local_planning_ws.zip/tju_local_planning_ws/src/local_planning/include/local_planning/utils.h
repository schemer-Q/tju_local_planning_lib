#pragma once

#include <cstddef>
#include <string>
#include <iostream>
#include <any>
#include <cmath>
#include "local_planning/log.h"
#include "rclcpp/rclcpp.hpp"
#include "planning_msgs/msg/trajectory_points.hpp"
#include <nav_msgs/msg/odometry.hpp>
#include "chassis_msgs/msg/car_ori_interface.hpp"
#include "perception_msgs/msg/ogm_points.hpp"
#include "perception_msgs/msg/objects.hpp"
#include "perception_task_msgs/msg/target_pose.hpp"
#include "control_msgs/msg/cross_goal.hpp"

#include "planning_msgs/msg/local_trajectory_points.hpp"
#include "planning_msgs/msg/trajectory_state.hpp"

// 包含已安装库中的结构体定义
#include "tju_local_planning/common/types/pose_point.h"
#include "tju_local_planning/common/types/target_pose.h"
#include "tju_local_planning/common/types/odometry.h"
#include "tju_local_planning/common/types/local_trajectory_points.h"
#include "tju_local_planning/common/types/trajectory_state.h"
#include "tju_local_planning/common/types/trajectory_points.h"
#include "tju_local_planning/common/types/cross_goal.h"
#include "tju_local_planning/common/types/ogm_points.h"
#include "tju_local_planning/common/types/objects.h"
#include "tju_local_planning/common/types/car_ori_interface.h"

TJU_LOCAL_PLANNING_LIB_APP_NAMESPACE_BEGIN
// using namespace TJU_LOCAL_PLANNING_LIB_COMMON_NAMESPACE;

namespace local_planning {
tju::local_planning::common::TrajectoryPoints CovertMsgToParam1(const planning_msgs::msg::TrajectoryPoints::ConstSharedPtr data){
    if(!data){
      std::cerr<<"utils.hpp:: "<<"全局路径为空"<<std::endl;
      return tju::local_planning::common::TrajectoryPoints{};
    }
  
    // 创建库中定义的轨迹点结构体
    tju::local_planning::common::TrajectoryPoints result;
    
    // 复制时间戳和坐标系信息
    result.header.frame_id = data->header.frame_id;
    result.points_cnt = data->points_cnt;
    result.step_length = data->step_length;
    result.replan_counter = data->replan_counter;
    result.plan_state = data->plan_state;
    
    // 复制轨迹点数据
    if (!data->trajectory.empty()) {
      result.trajectory.resize(data->trajectory.size());
      for (size_t i = 0; i < data->trajectory.size(); ++i) {
        auto& point = result.trajectory[i];
        // 基于PosePoint定义进行赋值
        point.x = data->trajectory[i].x;
        point.y = data->trajectory[i].y;
        point.z = data->trajectory[i].z;
        point.pitch = data->trajectory[i].pitch;
        point.roll = data->trajectory[i].roll;
        point.yaw = data->trajectory[i].yaw;
        point.speed = data->trajectory[i].speed;
        point.curve = data->trajectory[i].curve;
        point.acc = data->trajectory[i].acc;
        point.gear = data->trajectory[i].gear;
      }
    }
    
    return result;
  }

  tju::local_planning::common::Odometry CovertMsgToParam2(const nav_msgs::msg::Odometry::ConstSharedPtr data){
    if(!data){
      std::cerr<<"utils.hpp:: "<<"定位为空"<<std::endl;
      return tju::local_planning::common::Odometry{};
    }

    // 创建库中定义的里程计结构体
    tju::local_planning::common::Odometry result;
    
    // 直接填充位置信息
    result.position.x() = data->pose.pose.position.x;
    result.position.y() = data->pose.pose.position.y;
    result.position.z() = data->pose.pose.position.z;
    
    //test
    // std::cerr<<"CovertMsgToParam2: old_position.x = "<<data->pose.pose.position.x<<std::endl;
    // std::cerr<<"CovertMsgToParam2: new_position.x = "<<result.position.x()<<std::endl;
    // 直接填充姿态信息（四元数）
    result.orientation.x() = data->pose.pose.orientation.x;
    result.orientation.y() = data->pose.pose.orientation.y;
    result.orientation.z() = data->pose.pose.orientation.z;
    result.orientation.w() = data->pose.pose.orientation.w;
    
    // 直接填充线速度信息
    result.linear.x() = data->twist.twist.linear.x;
    result.linear.y() = data->twist.twist.linear.y;
    result.linear.z() = data->twist.twist.linear.z;
    
    // 直接填充角速度信息
    result.angular.x() = data->twist.twist.angular.x;
    result.angular.y() = data->twist.twist.angular.y;
    result.angular.z() = data->twist.twist.angular.z;
    
    // 可以根据需要设置wheel_speed和speed_scale
    // 这里暂时设置为0，实际使用时可能需要从其他消息源获取
    result.wheel_speed = 0.0;
    result.speed_scale = 0.0;
    
    return result;
  }
  tju::local_planning::common::CarOriInterface CovertMsgToParam3(const chassis_msgs::msg::CarOriInterface::ConstSharedPtr data){
    if(!data){
      std::cerr<<"utils.hpp:: "<<"底盘反馈为空"<<std::endl;
      return tju::local_planning::common::CarOriInterface{};
    }

    // 创建库中定义的车辆接口结构体
    tju::local_planning::common::CarOriInterface result;
    
    // 根据readme.txt中的定义填充字段
    result.header.frame_id = data->header.frame_id;
    result.angle = data->angle;
    result.acc = data->acc;
    result.open_gas = data->open_gas;
    result.drive_mode = data->drive_mode;
    result.e_stop_trigger = data->e_stop_trigger;
    result.gear = data->gear;
    result.car_speed = data->car_speed;
    result.motor_torque = data->motor_torque;
    result.yk_f = data->yk_f;
    result.yk_h = data->yk_h;
    result.fault1 = data->fault1;
    result.fault2 = data->fault2;
    result.fault3 = data->fault3;
    result.fault4 = data->fault4;
    result.mileage = data->mileage;
    result.brake_pressure = data->brake_pressure;
    result.lr_wheelspeed = data->lr_wheelspeed;
    result.rr_wheelspeed = data->rr_wheelspeed;
    result.soc = data->soc;
    result.carsts1 = data->carsts1;
    result.carsts2 = data->carsts2;
    result.lx_hight = data->lx_hight;
    result.pitching = data->pitching;
    result.carstartstate = data->carstartstate;
    result.vcu_service_voltage = data->vcu_service_voltage;
    result.vcu_sts = data->vcu_sts;
    result.fault = data->fault;
    result.flag_end_wire = data->flag_end_wire;
    result.msg_from_wire_to_plan = data->msg_from_wire_to_plan;
    
    return result;
  }

  tju::local_planning::common::OgmPoints CovertMsgToParam4(const perception_msgs::msg::OgmPoints::ConstSharedPtr data){
    std::cout<<"---------OGM PROCESS----------"<<std::endl;
    if(!data){
      std::cerr<<"utils.hpp:: "<<"OGM为空"<<std::endl;
      return tju::local_planning::common::OgmPoints{};
    }

    // 创建库中定义的栅格地图结构体
    tju::local_planning::common::OgmPoints result;
    
    // 填充坐标系信息
    result.header.frame_id = data->header.frame_id;
    
    // 复制OG点数据
    result.points.resize(data->points.size());
    for (size_t i = 0; i < data->points.size(); ++i) {
      result.points[i].x = data->points[i].x;
      result.points[i].y = data->points[i].y;
      result.points[i].z = data->points[i].z;
      result.points[i].p = data->points[i].p;
      result.points[i].type = data->points[i].type;
    }
    
    return result;
  }

  tju::local_planning::common::Objects CovertMsgToParam5(const perception_msgs::msg::Objects::ConstSharedPtr data){
    if(!data){
      std::cerr<<"utils.hpp:: "<<"障碍物为空"<<std::endl;
      return tju::local_planning::common::Objects{};
    }
  
    // 创建库中定义的障碍物对象结构体
    tju::local_planning::common::Objects result;
    
    // 填充坐标系信息
    result.header.frame_id = data->header.frame_id;
    
    // 复制障碍物数据
    result.objects.resize(data->objects.size());
    for (size_t i = 0; i < data->objects.size(); ++i) {
      auto& obj = result.objects[i];
      
      // 根据Object结构体定义填充字段
      // 移除错误的timestamp赋值，改为header赋值
      obj.header.frame_id = ""; // 如果ROS消息中有header
      
      obj.sensor_id = data->objects[i].sensor_id;
      obj.id = data->objects[i].id;
      obj.tracking_status = data->objects[i].tracking_status;
      obj.classification = data->objects[i].classification;
      obj.moving_status = data->objects[i].moving_status;
      obj.age = data->objects[i].age;
      obj.exist_confidence = data->objects[i].exist_confidence;
      obj.heading = data->objects[i].heading;
      obj.heading_cov = data->objects[i].heading_cov;
      obj.length = data->objects[i].length;
      obj.width = data->objects[i].width;
      obj.height = data->objects[i].height;
      obj.length_cov = data->objects[i].length_cov;
      obj.width_cov = data->objects[i].width_cov;
      obj.height_cov = data->objects[i].height_cov;
      obj.dx = data->objects[i].dx;
      obj.dy = data->objects[i].dy;
      obj.abs_vx = data->objects[i].abs_vx;
      obj.abs_vy = data->objects[i].abs_vy;
      obj.dx_cov = data->objects[i].dx_cov;
      obj.dy_cov = data->objects[i].dy_cov;
      obj.vx_cov = data->objects[i].vx_cov;
      obj.vy_cov = data->objects[i].vy_cov;
      obj.ax = data->objects[i].ax;
      obj.ay = data->objects[i].ay;
      obj.ax_cov = data->objects[i].ax_cov;
      obj.ay_cov = data->objects[i].ay_cov;
      obj.light = data->objects[i].light;
      
      // 复制轮廓点
      if (!data->objects[i].contour_points.empty()) {
        obj.contour_points.resize(data->objects[i].contour_points.size());
        for (size_t j = 0; j < data->objects[i].contour_points.size(); ++j) {
          obj.contour_points[j].x = data->objects[i].contour_points[j].x;
          obj.contour_points[j].y = data->objects[i].contour_points[j].y;
          obj.contour_points[j].z = data->objects[i].contour_points[j].z;
        }
      }
    }
    
    return result;
  }

  tju::local_planning::common::TargetPose CovertMsgToParam6(const perception_task_msgs::msg::TargetPose::ConstSharedPtr data){
    if(!data){
      std::cerr<<"utils.hpp:: "<<"目标为空"<<std::endl;
      return tju::local_planning::common::TargetPose{};
    }

    // 创建库中定义的目标点结构体
    tju::local_planning::common::TargetPose result;
    
    // 填充坐标系信息
    result.header.frame_id = data->header.frame_id;
    
    // 填充align_target信息
    result.align_target.x = data->align_target.x;
    result.align_target.y = data->align_target.y;
    result.align_target.z = data->align_target.z;
    result.align_target.pitch = data->align_target.pitch;
    result.align_target.roll = data->align_target.roll;
    result.align_target.yaw = data->align_target.yaw;
    result.align_target.speed = data->align_target.speed;
    result.align_target.curve = data->align_target.curve;
    result.align_target.acc = data->align_target.acc;
    result.align_target.gear = data->align_target.gear;
    
    return result;
  }

  tju::local_planning::common::CrossGoal CovertMsgToParam7(const control_msgs::msg::CrossGoal::ConstSharedPtr data){
    if(!data){
      std::cerr<<"utils.hpp:: "<<"CROSS GOAL为空"<<std::endl;
      return tju::local_planning::common::CrossGoal{};
    }

    // 创建库中定义的路口目标结构体
    tju::local_planning::common::CrossGoal result;
    
    // 填充坐标系信息
    result.header.frame_id = data->header.frame_id;
    
    // 根据readme.txt中的CrossGoal.msg定义填充字段
    result.vin = data->vin;
    result.work_state = data->work_state;
    result.tra_track_state = data->tra_track_state;
    
    // 填充目标点信息
    result.target_point.x = data->target_point.x;
    result.target_point.y = data->target_point.y;
    result.target_point.z = data->target_point.z;
    result.target_point.pitch = data->target_point.pitch;
    result.target_point.roll = data->target_point.roll;
    result.target_point.yaw = data->target_point.yaw;
    result.target_point.speed = data->target_point.speed;
    result.target_point.curve = data->target_point.curve;
    result.target_point.acc = data->target_point.acc;
    result.target_point.gear = data->target_point.gear;
    
    // 填充终点信息
    result.end_point.x = data->end_point.x;
    result.end_point.y = data->end_point.y;
    result.end_point.z = data->end_point.z;
    result.end_point.pitch = data->end_point.pitch;
    result.end_point.roll = data->end_point.roll;
    result.end_point.yaw = data->end_point.yaw;
    result.end_point.speed = data->end_point.speed;
    result.end_point.curve = data->end_point.curve;
    result.end_point.acc = data->end_point.acc;
    result.end_point.gear = data->end_point.gear;
    
    return result;
  }

  planning_msgs::msg::TrajectoryState ConvertToTrajectoryState(const std::any& data) {
    planning_msgs::msg::TrajectoryState result;
    try {
      // 尝试将 std::any 中的对象转换为库中定义的结构体
      // 注意使用正确的命名空间路径
      const tju::local_planning::common::TrajectoryState& traj_state = 
          std::any_cast<const tju::local_planning::common::TrajectoryState&>(data);
      
      // 设置头信息
      result.header.stamp = rclcpp::Clock().now();
      result.header.frame_id = traj_state.header.frame_id;
      
      // 根据TrajectoryState.msg定义填充字段
      // 填充实时轨迹点信息 - 使用正确的Odometry结构
      result.real_time_point.pose.pose.position.x = traj_state.real_time_point.position.x();
      result.real_time_point.pose.pose.position.y = traj_state.real_time_point.position.y();
      result.real_time_point.pose.pose.position.z = traj_state.real_time_point.position.z();
      
      // 转换四元数
      result.real_time_point.pose.pose.orientation.x = traj_state.real_time_point.orientation.x();
      result.real_time_point.pose.pose.orientation.y = traj_state.real_time_point.orientation.y();
      result.real_time_point.pose.pose.orientation.z = traj_state.real_time_point.orientation.z();
      result.real_time_point.pose.pose.orientation.w = traj_state.real_time_point.orientation.w();
      
      // 转换线速度和角速度
      result.real_time_point.twist.twist.linear.x = traj_state.real_time_point.linear.x();
      result.real_time_point.twist.twist.linear.y = traj_state.real_time_point.linear.y();
      result.real_time_point.twist.twist.linear.z = traj_state.real_time_point.linear.z();
      
      result.real_time_point.twist.twist.angular.x = traj_state.real_time_point.angular.x();
      result.real_time_point.twist.twist.angular.y = traj_state.real_time_point.angular.y();
      result.real_time_point.twist.twist.angular.z = traj_state.real_time_point.angular.z();
      
      // 复制标志位和索引
      result.idx_in_global = traj_state.idx_in_global;
      result.real_sensor_on_flag = traj_state.real_sensor_on_flag;
      result.real_forklift_up_flag = traj_state.real_forklift_up_flag;
      result.real_arrive_goal_pose = traj_state.real_arrive_goal_pose;
      
    } catch (const std::bad_any_cast& e) {
      RCLCPP_ERROR(rclcpp::get_logger("local_planning"), 
                  "Failed to cast std::any to TrajectoryState: %s", e.what());
    }
    return result;
  }

  planning_msgs::msg::LocalTrajectoryPoints ConvertToLocalTrajectoryPoints(const std::any& data) {
    planning_msgs::msg::LocalTrajectoryPoints result;
    try {
      // 尝试将 std::any 中的对象转换为库中定义的结构体 LocalTrajectory
      const tju::local_planning::common::LocalTrajectory& local_traj = 
          std::any_cast<const tju::local_planning::common::LocalTrajectory&>(data);
      
      // 设置头信息
      result.header.stamp = rclcpp::Clock().now();
      result.header.frame_id = local_traj.header.frame_id;
      
      // 根据LocalTrajectoryPoints.msg定义填充字段
      result.task_type = local_traj.task_type;
      result.points_cnt = local_traj.points_cnt;
      result.step_length = local_traj.step_length;
      result.replan_counter = local_traj.replan_counter;
      result.plan_state = local_traj.plan_state;
      
      // 转换轨迹点
      result.trajectory.resize(local_traj.trajectory.size());
      for (size_t i = 0; i < local_traj.trajectory.size(); ++i) {
        result.trajectory[i].x = local_traj.trajectory[i].x;
        result.trajectory[i].y = local_traj.trajectory[i].y;
        result.trajectory[i].z = local_traj.trajectory[i].z;
        result.trajectory[i].pitch = local_traj.trajectory[i].pitch;
        result.trajectory[i].roll = local_traj.trajectory[i].roll;
        result.trajectory[i].yaw = local_traj.trajectory[i].yaw;
        result.trajectory[i].speed = local_traj.trajectory[i].speed;
        result.trajectory[i].curve = local_traj.trajectory[i].curve;
        result.trajectory[i].acc = local_traj.trajectory[i].acc;
        result.trajectory[i].gear = local_traj.trajectory[i].gear;
      }
      
    } catch (const std::bad_any_cast& e) {
      RCLCPP_ERROR(rclcpp::get_logger("local_planning"), 
                  "Failed to cast std::any to LocalTrajectoryPoints: %s", e.what());
    }
    return result;
  }

}  // namespace local_planning
TJU_LOCAL_PLANNING_LIB_APP_NAMESPACE_END