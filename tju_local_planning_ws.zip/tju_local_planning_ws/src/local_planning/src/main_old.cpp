#include <yaml-cpp/yaml.h>
#include <csignal>
#include <rclcpp/rclcpp.hpp>
#include <unistd.h>
#include <ament_index_cpp/get_package_prefix.hpp>

#include "local_planning/log.h"
#include "local_planning/utils.h"

#include "common/util/diagnosis.h"
#include "common/data_manager/data_manager.hpp"
#include "common/subscriber/subscribe.hpp"
#include "common/publisher/publish.hpp"

#include "tju_local_planning/app/local_planning_QuinticPolynomialPlanner/forklift_local_planner_base.h"


using namespace local_planning;

std::atomic<bool> Running{true};

void signalHandler(int signum) {
  switch (signum) {
    case SIGINT:
      NTWARNING << "SIGINT signal received.";
      ;
      break;
    case SIGTERM:
      NTWARNING << "SIGTERM signal received.";
      break;
    case SIGABRT:
      NTWARNING << "SIGABRT signal received.";
      break;
    case SIGFPE:
      NTWARNING << "SIGFPE signal received.";
      break;
    case SIGSEGV:
      NTWARNING << "SIGSEGV signal received.";
      break;
    default:
      NTWARNING << "Unknown signal received: " << signum;
      break;
  }
  Running.store(false);
}

bool CheckConfig(const YAML::Node &config) {
  if (!config["Subscriber"].IsDefined()) {
    NTWARNING << "[Init][CheckConfig] Subscriber is missing";
    return false;
  }

  if (!config["Publisher"].IsDefined()) {
    NTWARNING << "[Init][CheckConfig] Subscriber is missing";
    return false;
  }

  if (!config["TaskTriggerMode"].IsDefined()) {
    NTWARNING << "[Init][CheckConfig] TaskTriggerMode is missing";
    return false;
  }
  return true;
}

int main(int argc, char *argv[]) {
  rclcpp::init(argc, argv);
  rclcpp::NodeOptions options;
  options.allow_undeclared_parameters(false);
  options.automatically_declare_parameters_from_overrides(false);
  auto node = std::make_shared<rclcpp::Node>("local_planning_node", options);
  auto &repoter = tju::common::Singleton<tju::common::DiagnosisReporter>::GetInstance();
  tju::diagnosis::start("local_planning_node");
  signal(SIGINT, signalHandler);  // 必须放在ros::init后面，否则signal捕捉会被ros::init覆盖
  if (!InitLogger(node)) {
    tju::diagnosis::report(tju::common::ErrorCode::LOCAL_PLANNING_LAUNCH_PARAM_GET_FAILED);
    return -1;
  } else {
    tju::diagnosis::restore(tju::common::ErrorCode::LOCAL_PLANNING_LAUNCH_PARAM_GET_FAILED);
  }
  std::string config_file = "/home/nvidia/tju_local_planning_ws/src/local_planning/config/data.yaml";
  node->declare_parameter<std::string>("config_file", config_file);
  if (node->has_parameter("config_file")) {
    config_file = node->get_parameter("config_file").as_string();
    tju::diagnosis::restore(tju::common::ErrorCode::LOCAL_PLANNING_LAUNCH_PARAM_GET_FAILED);
  } else {
    tju::diagnosis::report(tju::common::ErrorCode::LOCAL_PLANNING_LAUNCH_PARAM_GET_FAILED);
    NTFATAL << "[Init] Failed to get param 'config_file'";
    return -1;
  }
  auto config = YAML::LoadFile(config_file);
  if (!CheckConfig(config)) {
    tju::diagnosis::report(tju::common::ErrorCode::LOCAL_PLANNING_LAUNCH_CONFIG_LOAD_FAILED);
    return -1;
  } else {
    tju::diagnosis::restore(tju::common::ErrorCode::LOCAL_PLANNING_LAUNCH_CONFIG_LOAD_FAILED);
  }

  // Init data manager
  std::string sensors_cfile = "/" + config["SensorsConfig"].as<std::string>();
  std::string package_prefix = ament_index_cpp::get_package_prefix("common");
  sensors_cfile = package_prefix + sensors_cfile;
  NTINFO << "[Init] common package path : " << package_prefix;
  NTINFO << "[Init] SensorsConfig: " << sensors_cfile;
  REGISTER_SENSORS_BY_FILE(sensors_cfile);
  SET_NODE_NAME(node->get_name());
  SET_VEHICLE_NAME(config["vel"].as<std::string>());

  // Load trigger mode
  auto trigger_mode = config["TaskTriggerMode"].as<std::string>();
  if (trigger_mode != "Topic" && trigger_mode != "Time") {
    tju::diagnosis::report(tju::common::ErrorCode::LOCAL_PLANNING_LAUNCH_CONFIG_FILE_PARAM_ERROR);
    NTFATAL << "[Run] Invalid TaskTriggerMode: " << trigger_mode;
    return -1;
  } else {
    tju::diagnosis::restore(tju::common::ErrorCode::LOCAL_PLANNING_LAUNCH_CONFIG_FILE_PARAM_ERROR);
  }
  std::string trigger_sensor = "";
  if (trigger_mode == "Topic") {
    if (config["TriggertTopic"].IsDefined()) {
      trigger_sensor = config["TriggertTopic"].as<std::string>();
      tju::diagnosis::restore(tju::common::ErrorCode::LOCAL_PLANNING_LAUNCH_CONFIG_FILE_PARAM_ERROR);
    } else {
      tju::diagnosis::report(tju::common::ErrorCode::LOCAL_PLANNING_LAUNCH_CONFIG_FILE_PARAM_ERROR);
      NTFATAL << "[Run] TriggerSensor is missing";
      return -1;
    }
  }

  // Start subscribe data
  NTINFO << "[Init] Start to subscribe data.";
  std::unique_ptr<tju::common::Subscriber> subscriber = std::make_unique<tju::common::Subscriber>(node);
  if (!subscriber->Start(config["Subscriber"], trigger_sensor)) {
    tju::diagnosis::report(tju::common::ErrorCode::LOCAL_PLANNING_LAUNCH_CONFIG_LOAD_FAILED);
    return -1;
  } else {
    tju::diagnosis::restore(tju::common::ErrorCode::LOCAL_PLANNING_LAUNCH_CONFIG_LOAD_FAILED);
  }

  // Start publishe data
  NTINFO << "[Init] Start to publishe data.";
  std::unique_ptr<tju::common::Publisher> publisher = std::make_unique<tju::common::Publisher>(node);
  if (publisher->registerByYaml(config["Publisher"])) {
    tju::diagnosis::report(tju::common::ErrorCode::LOCAL_PLANNING_LAUNCH_CONFIG_LOAD_FAILED);
    return -1;
  } else {
    tju::diagnosis::restore(tju::common::ErrorCode::LOCAL_PLANNING_LAUNCH_CONFIG_LOAD_FAILED);
  }

  // Start Init algo tju::local_planning::app::ForkLiftLocalPlannerBase
  NTINFO << "[Init] Start to init algo.";
  std::unique_ptr<tju::local_planning::app::ForkLiftLocalPlannerBase> local_planning = std::make_unique<tju::local_planning::app::ForkLiftLocalPlannerBase>();
  std::string algo_config_file;
  if(!config["AlgoConfig"].IsDefined()) {
    tju::diagnosis::report(tju::common::ErrorCode::LOCAL_PLANNING_LAUNCH_CONFIG_FILE_PARAM_ERROR);
    NTFATAL << "[Init] AlgoConfig is missing!";
    return -1;
  }
  else {
    tju::diagnosis::restore(tju::common::ErrorCode::LOCAL_PLANNING_LAUNCH_CONFIG_FILE_PARAM_ERROR);
    algo_config_file = config["AlgoConfig"].as<std::string>();
  }

  NTINFO << "AlgoConfig: " << algo_config_file;
  auto algo_config = YAML::LoadFile(algo_config_file);
  NTINFO << "Full config structure: " << algo_config;  // 先打印整个配置结构
  NTINFO << "AlgoConfig MaxAccel: " << algo_config["Config"]["MaxAccel"];  // 正确访问
  local_planning->Init(algo_config);
  NTINFO << "Successfully loaded algorithm config file";

  int async_threads = 3;
  if (config["ROS"]["AsyncThread"].IsDefined()) {
    async_threads = config["ROS"]["AsyncThread"].as<int>();
  }
  rclcpp::executors::MultiThreadedExecutor executor(rclcpp::ExecutorOptions(), async_threads);
  executor.add_node(node);
  executor.add_node(repoter.get_node_base_interface());
  // trigger all tasks
  sleep(1);
  // 启动执行器线程
  std::thread executor_thread([&executor]() { executor.spin(); });
  auto run_lambda = [&node, &publisher, &local_planning]() {
    double msg_t = rclcpp::Clock().now().seconds();
    std::shared_ptr<GlobalPathData> global_path_data = std::make_shared<GlobalPathData>();
    if(tju::common::ErrorCode::OK == EXTRACT_GENERIC_BY_TIME(GlobalPathData, "GLOBALPATH", msg_t, global_path_data)){
      NTINFO << "Extract GLOBALPATH successfully, msg time: " <<  global_path_data->time << "; system time: " << msg_t;
    }

    std::shared_ptr<OdometryData> fusion_odom_data = std::make_shared<OdometryData>();
    if(tju::common::ErrorCode::OK == EXTRACT_GENERIC_BY_TIME(OdometryData, "FUSIONLOCATION", msg_t, fusion_odom_data)){
      NTINFO << "Extract FUSIONLOCATION successfully, msg time: " <<  fusion_odom_data->time << "; system time: " << msg_t;
    }

    std::shared_ptr<CarOriData> car_ori_data = std::make_shared<CarOriData>();
    if(tju::common::ErrorCode::OK == EXTRACT_GENERIC_BY_TIME(CarOriData, "CARORI", msg_t, car_ori_data)){
      NTINFO << "Extract CARORI successfully, msg time: " <<  car_ori_data->time << "; system time: " << msg_t;
    }

    std::shared_ptr<OgmPointsData> ogm_data = std::make_shared<OgmPointsData>();
    if(tju::common::ErrorCode::OK == EXTRACT_GENERIC_BY_TIME(OgmPointsData, "OGMPOINTS", msg_t, ogm_data)){
      NTINFO << "Extract OGMPOINTS successfully, msg time: " <<  ogm_data->time << "; system time: " << msg_t;
    }

    std::shared_ptr<ObjectsData> objects_data = std::make_shared<ObjectsData>();
    if(tju::common::ErrorCode::OK == EXTRACT_GENERIC_BY_TIME(ObjectsData, "OBJECTS", msg_t, objects_data)){
      NTINFO << "Extract OBJECTS successfully, msg time: " <<  objects_data->time << "; system time: " << msg_t;
    }

    std::shared_ptr<TargetPoseData> target_pose_data = std::make_shared<TargetPoseData>();
    if(tju::common::ErrorCode::OK == EXTRACT_GENERIC_BY_TIME(TargetPoseData, "LOCALPERCEPTION", msg_t, target_pose_data)){
      NTINFO << "Extract LOCALPERCEPTION successfully, msg time: " <<  target_pose_data->time << "; system time: " << msg_t;
    }

    std::shared_ptr<CrossGoalData> cross_goal_data = std::make_shared<CrossGoalData>();
    if(tju::common::ErrorCode::OK == EXTRACT_GENERIC_BY_TIME(CrossGoalData, "CROSSGOAL", msg_t, cross_goal_data)){
      NTINFO << "Extract CROSSGOAL successfully, msg time: " <<  cross_goal_data->time << "; system time: " << msg_t;
    }

    // 将ROS消息转换为算法内部数据结构
    tju::local_planning::common::TrajectoryPoints GlobalTrajectory = tju::local_planning::app::local_planning::CovertMsgToParam1(global_path_data->data);
    tju::local_planning::common::Odometry  FusionLocation = tju::local_planning::app::local_planning::CovertMsgToParam2(fusion_odom_data->data);

    //std::cerr<<"fusionlocation"<<FusionLocation.position.x()<<","<<FusionLocation.position.y()<<std::endl;

    tju::local_planning::common::CarOriInterface CarOrientation = tju::local_planning::app::local_planning::CovertMsgToParam3(car_ori_data->data);
    tju::local_planning::common::OgmPoints OgPoints = tju::local_planning::app::local_planning::CovertMsgToParam4(ogm_data->data);
    tju::local_planning::common::Objects Obstacles = tju::local_planning::app::local_planning::CovertMsgToParam5(objects_data->data);
    tju::local_planning::common::TargetPose AlignTarget = tju::local_planning::app::local_planning::CovertMsgToParam6(target_pose_data->data);
    tju::local_planning::common::CrossGoal CrossGoal = tju::local_planning::app::local_planning::CovertMsgToParam7(cross_goal_data->data);

    NTINFO <<"[Run] Converting ROS messages to algorithm data structures completed.";
    NTINFO <<"[Run] GlobalTrajectory points count: " << GlobalTrajectory.trajectory.size();
    // 使用转换后的数据调用本地规划算法
    uint32_t result = local_planning->Run(
        CrossGoal,
        GlobalTrajectory,
        CarOrientation,
        AlignTarget,
        Obstacles,
        OgPoints,
        FusionLocation
    );
    if (result != tju::local_planning::common::ErrorCode::SUCCESS) {
      NTWARNING << "[Run] Run() method returned error code: " << result;}
    
    // 获取本地规划结果
    auto local_trajectory = std::any_cast<tju::local_planning::common::LocalTrajectory>(local_planning->GetData("local_trajectory"));
    auto trajectory_state = std::any_cast<tju::local_planning::common::TrajectoryState>(local_planning->GetData("trajectory_state"));
    std::cerr<<"main.cpp:"<<"local_trajectory.trajectory.size()"<<local_trajectory.trajectory.size()<<std::endl;

    // if (local_trajectory.trajectory.empty()) {
    //   NTERROR << "Local trajectory is empty!";
    //   return;
    // }
    // 将算法结果转换回ROS消息并发布
    auto message_local_trajectory = tju::local_planning::app::local_planning::ConvertToLocalTrajectoryPoints(local_trajectory);
    message_local_trajectory.header.stamp = node->get_clock()->now();
    message_local_trajectory.header.frame_id = "map_link";
    if(tju::common::ErrorCode::OK != publisher->publish<planning_msgs::msg::LocalTrajectoryPoints>("LOCALPATH", message_local_trajectory)){
      NTFATAL << "Publishe LOCALPATH msg failed! Msg type is: " << "planning_msgs::msg::LocalTrajectoryPoints";
      std::cerr<<"main.cpp:"<<"message_local_trajectory.trajectory.size()"<<message_local_trajectory.trajectory.size()<<std::endl;
    }

    auto message = tju::local_planning::app::local_planning::ConvertToTrajectoryState(trajectory_state);
    message.header.stamp = node->get_clock()->now();
    if(tju::common::ErrorCode::OK != publisher->publish<planning_msgs::msg::TrajectoryState>("LOCALPATHSTATE", message)){
      NTFATAL << "Publishe LOCALPATHSTATE msg failed! Msg type is: " << "planning_msgs::msg::TrajectoryState";
    }
  };
  if (trigger_mode == "Topic") {
    std::chrono::steady_clock::time_point consumed_trigger_time;  // 防止计算时间太短，导致重复触发
    while (rclcpp::ok() && Running.load()) {
      auto now = std::chrono::steady_clock::now();
      bool triggered = false;
      {
        std::unique_lock<std::mutex> lk(tju::common::lock);
        triggered = tju::common::cv.wait_for(lk, std::chrono::seconds(1), [&] {
          auto diff = std::chrono::duration_cast<std::chrono::milliseconds>(now - tju::common::last_trigger_time).count();
          return !(Running.load()) || (tju::common::ready && diff <= 50 && tju::common::last_trigger_time != consumed_trigger_time);
        });
      }
      if (!Running.load()) break;
      if (triggered) {
        NTINFO << "[Run] Trigger mode !";
        consumed_trigger_time = tju::common::last_trigger_time;
        run_lambda();
      }
    }
  } else {
    rclcpp::Rate rate(1);
    while (rclcpp::ok()) {
      //std::cerr<<"run_lambda()"<<std::endl;
      run_lambda();
      rate.sleep();
    }
  }

  executor.cancel();
  if (executor_thread.joinable()) {
    executor_thread.join();
  }
  rclcpp::shutdown();
  return 0;
}
