from launch import LaunchDescription
from launch_ros.actions import Node
import os
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    package_dir = get_package_share_directory('path_publisher')
    
    return LaunchDescription([
        Node(
            package='path_publisher',
            executable='path_publisher_node',
            name='path_publisher',
            output='screen',
            parameters=[{
                'json_path': '../tju_local_planning_ws/src/path_data9.json',
                'publish_rate': 100.0
            }]
        )
    ])