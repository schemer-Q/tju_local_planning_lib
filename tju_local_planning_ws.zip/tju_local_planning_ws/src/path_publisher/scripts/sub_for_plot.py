#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
import matplotlib.pyplot as plt
from planning_msgs.msg import LocalTrajectoryPoints
import numpy as np
# 设置中文字体（使用Matplotlib内置的字体）
plt.rcParams['font.sans-serif'] = ['SimHei']  # 或者 ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

class TrajectorySubscriber(Node):
    def __init__(self):
        super().__init__('trajectory_subscriber')
        
        # 存储接收到的轨迹数据
        self.trajectory_data = None
        self.received = False
        
        # 创建订阅者，只接收一次消息
        self.subscription = self.create_subscription(
            LocalTrajectoryPoints,
            '/planning/local_trajectory',
            self.listener_callback,
            10)  # QoS profile depth
        
        self.get_logger().info('等待接收 /planning/local_trajectory 消息...')
    
    def listener_callback(self, msg):
        if self.received:
            return
            
        self.get_logger().info('收到轨迹消息，开始处理...')
        
        # 存储消息数据
        self.trajectory_data = {
            'header': msg.header,
            'trajectory': msg.trajectory,
            'task_type': msg.task_type,
            'points_cnt': msg.points_cnt,
            'step_length': msg.step_length,
            'replan_counter': msg.replan_counter,
            'plan_state': msg.plan_state
        }
        
        self.received = True
        self.subscription.destroy()  # 取消订阅
        
        # 处理并绘制轨迹
        self.process_and_plot_trajectory()
    
    def process_and_plot_trajectory(self):
        if not self.trajectory_data:
            self.get_logger().error('没有轨迹数据可供处理')
            return
        
        # 提取轨迹点数据
        trajectory = self.trajectory_data['trajectory']
        x_coords = [point.x for point in trajectory]
        y_coords = [point.y for point in trajectory]
        yaws = [point.yaw for point in trajectory]
        speeds = [point.speed for point in trajectory]
        accs = [point.acc for point in trajectory]
        curves = [point.curve for point in trajectory]
        
        # 规范化 yaw 到 [0, 2π) 范围
        yaws = np.array(yaws)  # 转为 numpy array 方便计算
        yaws = yaws % (2 * np.pi)  # 取模运算，确保在 [0, 2π) 范围内
        # 计算路径长度（累计距离）
        distances = [0.0]
        for i in range(1, len(x_coords)):
            dx = x_coords[i] - x_coords[i-1]
            dy = y_coords[i] - y_coords[i-1]
            distances.append(distances[-1] + np.sqrt(dx**2 + dy**2))
        
        # 打印一些基本信息
        self.get_logger().info(f'收到轨迹点数量: {len(trajectory)}')
        self.get_logger().info(f'任务类型: {self.trajectory_data["task_type"]}')
        self.get_logger().info(f'规划状态: {self.trajectory_data["plan_state"]}')
        self.get_logger().info(f'重新规划次数: {self.trajectory_data["replan_counter"]}')
        
        # 创建包含4个子图的图形
        plt.figure(figsize=(15, 12))
        
        # 子图1: 轨迹路径
        plt.subplot(2, 2, 1)
        plt.plot(x_coords, y_coords, 'b-', label='local_trajecotry')
        plt.plot(x_coords, y_coords, 'ro', markersize=3, label='points')
        plt.plot(x_coords[0], y_coords[0], 'go', markersize=8, label='start')
        plt.plot(x_coords[-1], y_coords[-1], 'yo', markersize=8, label='end')
        
        # 绘制方向箭头（每隔5个点绘制一个）
        for i in range(0, len(x_coords), 5):
            dx = 0.5 * np.cos(yaws[i])
            dy = 0.5 * np.sin(yaws[i])
            plt.arrow(x_coords[i], y_coords[i], dx, dy, 
                     head_width=0.3, head_length=0.5, fc='g', ec='g')
        
        plt.title(f'trajectory (task_type: {self.trajectory_data["task_type"]})')
        plt.xlabel('X  (m)')
        plt.ylabel('Y  (m)')
        plt.axis('equal')
        plt.grid(True)
        plt.legend()
        
        # 子图2: Yaw角变化
        plt.subplot(2, 2, 2)
        plt.plot(distances, yaws, 'b-')
        plt.title('Yaw')
        plt.xlabel('distance (m)')
        plt.ylabel('yaw (rad)')
        plt.grid(True)
        
        # 子图3: 速度变化
        plt.subplot(2, 2, 3)
        plt.plot(distances, speeds, 'g-')
        plt.title('speed')
        plt.xlabel('distance (m)')
        plt.ylabel('speed (m/s)')
        plt.grid(True)
        
        # 子图4: 曲率变化
        plt.subplot(2, 2, 4)
        plt.plot(distances, curves, 'r-')
        plt.title('curvature')
        plt.xlabel('distance (m)')
        plt.ylabel('curvature (1/m)')
        plt.grid(True)
        
        # 调整子图间距
        plt.tight_layout()
        
        # 显示图表
        plt.show()
        
        self.get_logger().info('轨迹处理完成，显示图表。')

def main(args=None):
    rclpy.init(args=args)
    
    trajectory_subscriber = TrajectorySubscriber()
    
    # 等待接收消息
    while rclpy.ok() and not trajectory_subscriber.received:
        rclpy.spin_once(trajectory_subscriber)
    
    # 清理节点
    trajectory_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()


#!/usr/bin/env python3

# import rclpy
# from rclpy.node import Node
# import matplotlib.pyplot as plt
# from planning_msgs.msg import LocalTrajectoryPoints, TrajectoryPoints
# #from geometry_msgs.msg import Pose
# import numpy as np
# from matplotlib import rcParams

# class TrajectoryVisualizer(Node):
#     def __init__(self):
#         super().__init__('trajectory_visualizer')
        
#         # 设置中文字体
#         rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'WenQuanYi Zen Hei']
#         rcParams['axes.unicode_minus'] = False
        
#         # 存储接收到的数据
#         self.local_data = None
#         self.global_data = None
#         self.local_received = False
#         self.global_received = False
        
#         # 创建本地轨迹订阅者
#         self.local_sub = self.create_subscription(
#             LocalTrajectoryPoints,
#             '/planning/local_trajectory',
#             self.local_callback,
#             10)
        
#         # 创建全局轨迹订阅者
#         self.global_sub = self.create_subscription(
#             TrajectoryPoints,
#             '/planning/global_trajectory',
#             self.global_callback,
#             10)
        
#         self.get_logger().info('等待接收轨迹数据...')
    
#     def local_callback(self, msg):
#         if self.local_received:
#             return
            
#         self.get_logger().info('收到局部轨迹消息')
        
#         # 存储本地轨迹数据
#         self.local_data = {
#             'header': msg.header,
#             'trajectory': msg.trajectory,
#             'task_type': msg.task_type,
#             'points_cnt': msg.points_cnt,
#             'step_length': msg.step_length,
#             'replan_counter': msg.replan_counter,
#             'plan_state': msg.plan_state
#         }
        
#         self.local_received = True
#         self.check_and_plot()
    
#     def global_callback(self, msg):
#         if self.global_received:
#             return
            
#         self.get_logger().info('收到全局轨迹消息')
        
#         # 存储全局轨迹数据
#         self.global_data = {
#             'header': msg.header,
#             'trajectory': msg.trajectory,
#             'points_cnt': msg.points_cnt,
#             'step_length': msg.step_length,
#             'replan_counter': msg.replan_counter,
#             'plan_state': msg.plan_state
#         }
        
#         self.global_received = True
#         self.check_and_plot()
    
#     def check_and_plot(self):
#         # 只有两个消息都收到时才绘图
#         if self.local_received and self.global_received:
#             self.plot_trajectories()
            
#             # 重置接收状态以便下次接收
#             self.local_received = False
#             self.global_received = False
#             self.local_data = None
#             self.global_data = None
    
#     def plot_trajectories(self):
#         # 创建图形
#         plt.figure(figsize=(15, 10))
        
#         # 绘制全局轨迹
#         if self.global_data and self.global_data['trajectory']:
#             global_traj = self.global_data['trajectory']
#             gx = [point.x for point in global_traj]
#             gy = [point.y for point in global_traj]
            
#             plt.plot(gx, gy, 'b-', linewidth=2, label='global_trajectory')
#             plt.plot(gx[0], gy[0], 'go', markersize=10, label='global_start')
#             plt.plot(gx[-1], gy[-1], 'bo', markersize=10, label='global_end')
        
#         # 绘制局部轨迹
#         if self.local_data and self.local_data['trajectory']:
#             local_traj = self.local_data['trajectory']
#             lx = [point.x for point in local_traj]
#             ly = [point.y for point in local_traj]
            
#             plt.plot(lx, ly, 'r-', linewidth=2, label='local_split')
#             plt.plot(lx[0], ly[0], 'mo', markersize=8, label='local_split_start')
#             plt.plot(lx[-1], ly[-1], 'ro', markersize=8, label='local_split_end')
            
#             # 绘制局部轨迹方向箭头
#             yaws = [point.yaw % (2*np.pi) for point in local_traj]
#             # for i in range(0, len(lx), 5):
#             #     dx = 0.5 * np.cos(yaws[i])
#             #     dy = 0.5 * np.sin(yaws[i])
#             #     plt.arrow(lx[i], ly[i], dx, dy, 
#             #              head_width=0.3, head_length=0.5, fc='r', ec='r')
        
#         # 添加图表元素
#         plt.title('path')
#         plt.xlabel('X (m)')
#         plt.ylabel('Y (m)')
#         plt.axis('equal')
#         plt.grid(True)
#         plt.legend(loc='upper right')
        
#         # 显示图表
#         plt.tight_layout()
#         plt.show()
#         self.get_logger().info('轨迹对比图已显示')

# def main(args=None):
#     rclpy.init(args=args)
#     visualizer = TrajectoryVisualizer()
    
#     try:
#         rclpy.spin(visualizer)
#     except KeyboardInterrupt:
#         pass
#     finally:
#         visualizer.destroy_node()
#         rclpy.shutdown()

# if __name__ == '__main__':
#     main()