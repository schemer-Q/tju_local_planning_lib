#include <rclcpp/rclcpp.hpp>
#include <planning_msgs/msg/trajectory_points.hpp>
#include <nlohmann/json.hpp>
#include <fstream>
#include <chrono>

using namespace std::chrono_literals;

class JsonToPath : public rclcpp::Node {
public:
    JsonToPath() : Node("jsontopath") {
        publisher_ = this->create_publisher<planning_msgs::msg::TrajectoryPoints>(
            "/planning/global_trajectory", 10);
        
        timer_ = this->create_wall_timer(
            100ms, std::bind(&JsonToPath::publishTrajectory, this));
            
        // Load JSON file
        std::string file_path = "../tju_local_planning_ws/src/path_publisher/src/path_data42.json";
        std::ifstream file(file_path);
        
        if (!file.is_open()) {
            RCLCPP_ERROR(this->get_logger(), "Failed to open JSON file: %s", file_path.c_str());
            return;
        }
        
        try {
            json_data_ = nlohmann::json::parse(file);
        } catch (const std::exception& e) {
            RCLCPP_ERROR(this->get_logger(), "JSON parse error: %s", e.what());
            return;
        }
        
        RCLCPP_INFO(this->get_logger(), "Successfully loaded JSON file");
    }

private:
    void publishTrajectory() {
        auto message = planning_msgs::msg::TrajectoryPoints();
        
        // Set header
        message.header.stamp = this->now();
        message.header.frame_id = json_data_["header"]["frame_id"];
        
        // 提取轨迹基本信息
        message.plan_state = json_data_["plan_state"];
        message.points_cnt = json_data_["points_cnt"];
        message.replan_counter = json_data_["replan_counter"];
        message.step_length = json_data_["step_length"];

        // Set trajectory points
        for (const auto& point : json_data_["trajectory"]) {
            common_msgs::msg::PosePoint trajectory_point;
            trajectory_point.x = point["x"];
            trajectory_point.y = point["y"];
            trajectory_point.z = point["z"];
            trajectory_point.yaw = point["yaw"];
            trajectory_point.roll = point["roll"];
            trajectory_point.pitch = point["pitch"];
            trajectory_point.speed = point["speed"];
            trajectory_point.acc = point["acc"];
            trajectory_point.curve = point["curve"];
            trajectory_point.gear = point["gear"];
            
            message.trajectory.push_back(trajectory_point);
        }
        
        publisher_->publish(message);
        RCLCPP_DEBUG(this->get_logger(), "Published trajectory with %zu points", message.trajectory.size());
    }
    
    rclcpp::Publisher<planning_msgs::msg::TrajectoryPoints>::SharedPtr publisher_;
    rclcpp::TimerBase::SharedPtr timer_;
    nlohmann::json json_data_;
};

int main(int argc, char** argv) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<JsonToPath>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
