#include <rclcpp/rclcpp.hpp>
#include <planning_msgs/msg/trajectory_points.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <common_msgs/msg/pose_point.hpp>
#include <chassis_msgs/msg/car_ori_interface.hpp>
#include <perception_task_msgs/msg/target_pose.hpp>  // 添加TargetPose消息头文件
#include <fstream>
#include <nlohmann/json.hpp>
#include <cmath>

#include "geometry_msgs/msg/pose_with_covariance_stamped.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "tf2/LinearMath/Quaternion.h"
#include "tf2/LinearMath/Matrix3x3.h"

using namespace std::chrono_literals;
using json = nlohmann::json;

class PathPublisher : public rclcpp::Node {
public:
  PathPublisher() : Node("path_publisher") {
    // 声明参数
    declare_parameter("json_path", "../tju_local_planning_ws/src/path_data9.json");
    declare_parameter("publish_rate", 10.0);
    declare_parameter("point_switch_interval", 1.0);  // 切换到下一个点的时间间隔(秒)
    
    // 获取参数
    json_path_ = get_parameter("json_path").as_string();
    double rate = get_parameter("publish_rate").as_double();
    point_switch_interval_ = get_parameter("point_switch_interval").as_double();
    
    // 创建发布器
    global_path_publisher_ = create_publisher<planning_msgs::msg::TrajectoryPoints>("/planning/global_trajectory", 10);
    odom_publisher_ = create_publisher<nav_msgs::msg::Odometry>("/location/fusion_location", 10);
    car_ori_publisher_ = create_publisher<chassis_msgs::msg::CarOriInterface>("/chassis/car_ori_data", 10);
    target_pose_publisher_ = create_publisher<perception_task_msgs::msg::TargetPose>("/perception_task/align_target", 10);  // 新增TargetPose发布器
    odom_target_publisher_ = create_publisher<nav_msgs::msg::Odometry>("/show_target_pose", 10);
    
    // 初始化轨迹索引
    current_trajectory_index_ = 0;
    last_point_switch_time_ = now();

    sub_ = this->create_subscription<geometry_msgs::msg::PoseWithCovarianceStamped>(
            "/initialpose", 10,
            [this](const geometry_msgs::msg::PoseWithCovarianceStamped::SharedPtr msg) {
                auto current_time = now();
                //nav_msgs::msg::Odometry odom;
//!!!only pose estimate from target, pub target in odom for visualization!!!//
                // odom_target.header = msg->header;
                // odom_target.pose = msg->pose;
                // odom_target.child_frame_id = "base_link";
                // odom_target.twist.twist.linear.x = 0.0;
                // odom_target.twist.twist.linear.y = 0.0;
                // odom_target.twist.twist.linear.z = 0.0;
                // odom_target.twist.twist.angular.x = 0.0;
                // odom_target.twist.twist.angular.y = 0.0;
                // odom_target.twist.twist.angular.z = 0.0;
                // has_odom = true;

                // msg_ptr = msg;
                // const auto& q = msg->pose.pose.orientation;
                // tf2::Quaternion quat(q.x, q.y, q.z, q.w);
                // double roll, pitch, yaw;
                // msg_yaw = yaw;
                // tf2::Matrix3x3(quat).getRPY(roll, pitch, yaw);
                // target_pose_msg_.header.stamp = current_time;
                // target_pose_msg_.header.frame_id = "base_link";
                // target_pose_msg_.align_target.x = msg->pose.pose.position.x;
                // target_pose_msg_.align_target.y = msg->pose.pose.position.y;
                // target_pose_msg_.align_target.z = 0.0;
                // while (yaw > M_PI) yaw -= 2 * M_PI;
                // while (yaw < -M_PI) yaw += 2 * M_PI;
                // target_pose_msg_.align_target.yaw = yaw;
                // has_goal = true;

//！！！pose estimate from odom and target pose, with tf tranformed！！！//
                // if (count_ == 1) {
                //     msg_ptr = msg;
                //     const auto& q = msg->pose.pose.orientation;
                //     const auto& d = odom.pose.pose.orientation;
                //     tf2::Quaternion quat(q.x, q.y, q.z, q.w);
                //     tf2::Quaternion dquat(d.x, d.y, d.z, d.w);
                //     double roll, pitch, yaw;
                //     msg_yaw = yaw;
                //     double droll, dpitch, dyaw;
                //     tf2::Matrix3x3(quat).getRPY(roll, pitch, yaw);
                //     tf2::Matrix3x3(dquat).getRPY(droll, dpitch, dyaw);
                //     double dx = msg->pose.pose.position.x-odom.pose.pose.position.x;
                //     double dy = msg->pose.pose.position.y-odom.pose.pose.position.y;
                //     double x_car =  dx * cos(yaw) + dy * sin(yaw);
                //     double y_car = -dx * sin(yaw) + dy * cos(yaw);
                //     double yaw_body = yaw - dyaw;
                //     target_pose_msg_.header.stamp = current_time;
                //     target_pose_msg_.header.frame_id = "base_link";
                //     target_pose_msg_.align_target.x = x_car;
                //     target_pose_msg_.align_target.y = y_car;
                //     target_pose_msg_.align_target.z = 0.0;
                //     while (yaw_body > M_PI) yaw_body -= 2 * M_PI;
                //     while (yaw_body < -M_PI) yaw_body += 2 * M_PI;
                //     target_pose_msg_.align_target.yaw = yaw_body;
                //     count_++;
                //     has_goal = true;
                // }
                // if (count_ == 0) {
                //     odom.header = msg->header;
                //     odom.pose = msg->pose;
                //     odom.child_frame_id = "base_link";
                //     odom.twist.twist.linear.x = 0.0;
                //     odom.twist.twist.linear.y = 0.0;
                //     odom.twist.twist.linear.z = 0.0;
                //     odom.twist.twist.angular.x = 0.0;
                //     odom.twist.twist.angular.y = 0.0;
                //     odom.twist.twist.angular.z = 0.0;
                //     count_++;
                //     has_odom = true;
                // }
//！！！pose estimate from odom and target pose, without tf tranformed！！！//
                if (count_ == 1) {
                    const auto& q = msg->pose.pose.orientation;
                    tf2::Quaternion quat(q.x, q.y, q.z, q.w);
                    double roll, pitch, yaw;
                    tf2::Matrix3x3(quat).getRPY(roll, pitch, yaw);
                    goal.header.stamp = current_time;
                    goal.header.frame_id = "base_link";
                    goal.align_target.x = msg->pose.pose.position.x;
                    goal.align_target.y = msg->pose.pose.position.y;
                    double yaw_body = yaw;
                    while (yaw_body > M_PI) yaw_body -= 2 * M_PI;
                    while (yaw_body < -M_PI) yaw_body += 2 * M_PI;
                    goal.align_target.yaw = yaw_body;
                    has_goal = true;
                }

                if (count_ == 0) {
                    odom.header = msg->header;
                    odom.pose = msg->pose;
                    odom.child_frame_id = "base_link";
                    odom.twist.twist.linear.x = 0.0;
                    odom.twist.twist.linear.y = 0.0;
                    odom.twist.twist.linear.z = 0.0;
                    odom.twist.twist.angular.x = 0.0;
                    odom.twist.twist.angular.y = 0.0;
                    odom.twist.twist.angular.z = 0.0;
                    count_++;
                    has_odom = true;
                }
                if (has_odom && has_goal) {count_ = 0;}
            }
        );
    
    // 加载JSON数据
    loadJsonData();
    
    // 创建定时器
    timer_ = create_wall_timer(
        std::chrono::milliseconds(static_cast<int>(1000.0 / rate)),
        std::bind(&PathPublisher::timer_callback, this));
    
    RCLCPP_INFO(get_logger(), "Path publisher initialized with JSON path: %s", json_path_.c_str());
  }

private:
void loadJsonData() {
    try {
        // 打开JSON文件
        std::ifstream file(json_path_);
        if (!file.is_open()) {
            RCLCPP_ERROR(get_logger(), "Failed to open JSON file: %s", json_path_.c_str());
            return;
        }
        
        // 解析JSON
        json data;
        file >> data;
        
        // 提取轨迹基本信息
        global_path_.header.frame_id = data["header"]["frame_id"];
        global_path_.plan_state = data["plan_state"];
        global_path_.points_cnt = data["points_cnt"];
        global_path_.replan_counter = data["replan_counter"];
        global_path_.step_length = data["step_length"];
        
        // 填充轨迹点 - 使用TrajectoryPoints.msg的结构
        auto& trajectory = data["trajectory"];
        for (size_t i = 0; i < trajectory.size(); ++i) {
            common_msgs::msg::PosePoint pose_point;
            
            // 基础坐标
            pose_point.x = trajectory[i].value("x", 0.0);
            pose_point.y = trajectory[i].value("y", 0.0);
            pose_point.z = trajectory[i].value("z", 0.0);
            
            // 附加信息
            pose_point.yaw = trajectory[i].value("yaw", 0.0);
            pose_point.roll = trajectory[i].value("roll", 0.0);
            pose_point.pitch = trajectory[i].value("pitch", 0.0);
            pose_point.speed = trajectory[i].value("speed", 0.0);
            pose_point.acc = trajectory[i].value("acc", 0.0);
            pose_point.curve = trajectory[i].value("curve", 0.0);
            pose_point.gear = trajectory[i].value("gear", 1);
            
            global_path_.trajectory.push_back(pose_point);
        }
        
        // 设置目标点姿态为轨迹最后一个点
        // if (!global_path_.trajectory.empty()) {
        //     // 创建TargetPose消息
        //     target_pose_msg_.header.frame_id = global_path_.header.frame_id;
        //     // 将最后一个轨迹点作为目标点
        //     target_pose_msg_.align_target = global_path_.trajectory.back();
            
        //     RCLCPP_INFO(get_logger(), 
        //         "Target pose set to final trajectory point: [%.2f, %.2f, %.2f], Yaw: %.2f°",
        //         target_pose_msg_.align_target.x, 
        //         target_pose_msg_.align_target.y, 
        //         target_pose_msg_.align_target.z,
        //         target_pose_msg_.align_target.yaw);
        // }
        
        RCLCPP_INFO(get_logger(), "Loaded %ld trajectory points from JSON", global_path_.trajectory.size());
    }
    catch (const std::exception& e) {
        RCLCPP_ERROR(get_logger(), "Error parsing JSON: %s", e.what());
    }
}
  
void timer_callback() {
    if (global_path_.trajectory.empty()) {
        RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 5000, "Trajectory is empty");
        return;
    }
    
    // 当前时间戳
    auto current_time = now();
    
    // 检查是否应该切换到下一个轨迹点
    if ((current_time - last_point_switch_time_).seconds() >= point_switch_interval_) {
        // 切换到下一个点
        current_trajectory_index_ = (current_trajectory_index_ + 1) % global_path_.trajectory.size();
        last_point_switch_time_ = current_time;
        
        // 每循环一次完整轨迹打印一次日志
        if (current_trajectory_index_ == 0) {
            RCLCPP_INFO(get_logger(), "Completed one full trajectory loop, restarting from beginning");
        }
    }
    
    // 获取当前轨迹点
    const common_msgs::msg::PosePoint& current_point = global_path_.trajectory[current_trajectory_index_];
    
    // 更新全局路径时间戳
    global_path_.header.stamp = current_time;
// 全局
    // // 创建一个模拟的里程计数据
    // nav_msgs::msg::Odometry odom;
    // odom.header.stamp = current_time;
    // odom.header.frame_id = "map";
    // odom.child_frame_id = "base_link";

    // // 设置位置 - 直接使用轨迹点位置
    // odom.pose.pose.position.x = current_point.x;
    // odom.pose.pose.position.y = current_point.y;
    // odom.pose.pose.position.z = current_point.z;
    
    // // 从yaw角度创建四元数
    // double yaw = current_point.yaw * M_PI / 180.0; // 将度转换为弧度
    // odom.pose.pose.orientation.x = 0.0;
    // odom.pose.pose.orientation.y = 0.0;
    // odom.pose.pose.orientation.z = sin(yaw / 2.0);
    // odom.pose.pose.orientation.w = cos(yaw / 2.0);
    
    // // 设置速度 - 使用轨迹点中的速度，如果为0则使用默认值
    // odom.twist.twist.linear.x = (current_point.speed > 0.001) ? current_point.speed : 1.0;
    // odom.twist.twist.linear.y = 0.0;
    // odom.twist.twist.linear.z = 0.0;
    // odom.twist.twist.angular.x = 0.0;
    // odom.twist.twist.angular.y = 0.0;
    // odom.twist.twist.angular.z = 0.0;
// 全局
    // 接受rviz姿态
    odom.header.stamp = current_time;
    odom.header.frame_id = "map";
    odom.child_frame_id = "base_link";

    // 创建底盘数据
    chassis_msgs::msg::CarOriInterface car_ori;
    car_ori.header.stamp = current_time;
    car_ori.header.frame_id = "base_link";
    
    // 设置底盘数据 - 从当前轨迹点获取
    car_ori.gear = current_point.gear;
    car_ori.car_speed = 0.4;
    car_ori.acc = current_point.acc;
    car_ori.angle = 0.0;  // 方向盘转角
    car_ori.open_gas = 0.3;  // 油门开度
    car_ori.drive_mode = 1;  // 自动驾驶模式
    car_ori.e_stop_trigger = 0;  // 不急停
    car_ori.motor_torque = 10.0;  // 电机扭矩
    car_ori.yk_f = 0;
    car_ori.yk_h = 0;
    car_ori.fault1 = 0;
    car_ori.fault2 = 0;
    car_ori.fault3 = 0;
    car_ori.fault4 = 0;
    car_ori.mileage = 1000.0;  // 累计里程
    car_ori.brake_pressure = 0.0;  // 制动压力
    car_ori.lr_wheelspeed = car_ori.car_speed;  // 左后轮速度
    car_ori.rr_wheelspeed = car_ori.car_speed;  // 右后轮速度
    car_ori.soc = 80.0;  // 电池电量
    car_ori.carsts1 = 0;
    car_ori.carsts2 = 0;
    car_ori.lx_hight = 0.0;
    car_ori.pitching = 0.0;
    car_ori.carstartstate = 1;  // 已启动
    car_ori.vcu_service_voltage = 24.0;  // VCU电压
    car_ori.vcu_sts = 1;  // VCU状态正常
    car_ori.fault = 0;  // 无故障
    car_ori.flag_end_wire = 0;
    car_ori.msg_from_wire_to_plan = 0;
    
    // 更新目标点的时间戳
    target_pose_msg_.header.stamp = current_time;
    goal.header.stamp = current_time;
    // 发布消息
    if (has_goal&&has_odom) {
        std::cout<<"------pose pub-------"<<std::endl;
        global_path_publisher_->publish(global_path_);
        odom_publisher_->publish(odom);
        car_ori_publisher_->publish(car_ori);
        target_pose_publisher_->publish(goal);
        // odom_target_publisher_->publish(odom_target);
        // 打印不同坐标系的目标点
    std::cout<<"path_publisher: "<<"------target pose-------"<<std::endl;
    std::cout<<"path_publisher: odom: "<<"x: "<<odom.pose.pose.position.x<<", y: "<<odom.pose.pose.position.y<<std::endl;
    std::cout<<"path_publisher: target: "<<"x: "<<goal.align_target.x<<", y: "<<goal.align_target.y<<", yaw: "<<goal.align_target.yaw<<std::endl;
    }
    //std::cout<<"------pose pub-------"<<std::endl;
    global_path_publisher_->publish(global_path_);
    odom_publisher_->publish(odom);
    // std::cout<<"path_publisher: odom: "<<"x: "<<odom.pose.pose.position.x<<", y: "<<odom.pose.pose.position.y<<std::endl;
    car_ori_publisher_->publish(car_ori);
    // target_pose_publisher_->publish(target_pose_msg_);
    
    // 每20个点输出一次日志
    if (++log_counter_ % 20 == 0) {
        RCLCPP_INFO(get_logger(), 
            "Publishing point %ld/%ld: [%.2f, %.2f, %.2f], Yaw: %.2f°", 
            current_trajectory_index_, 
            global_path_.trajectory.size() - 1,
            current_point.x, current_point.y, current_point.z, 
            current_point.yaw
        );
    }
}   
  
  std::string json_path_;
  planning_msgs::msg::TrajectoryPoints global_path_;
  rclcpp::Publisher<planning_msgs::msg::TrajectoryPoints>::SharedPtr global_path_publisher_;
  rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr odom_publisher_;
  rclcpp::Publisher<chassis_msgs::msg::CarOriInterface>::SharedPtr car_ori_publisher_;
  rclcpp::Publisher<perception_task_msgs::msg::TargetPose>::SharedPtr target_pose_publisher_;  // 新增TargetPose发布器
  perception_task_msgs::msg::TargetPose target_pose_msg_;  // 目标姿态消息
  rclcpp::TimerBase::SharedPtr timer_;
  
  rclcpp::Subscription<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr sub_;
  int count_ = 0;
  bool has_odom = false, has_goal = false;
  nav_msgs::msg::Odometry odom_target;

  nav_msgs::msg::Odometry odom;
  perception_task_msgs::msg::TargetPose goal;

  geometry_msgs::msg::PoseWithCovarianceStamped::SharedPtr msg_ptr;
  double msg_yaw;
  rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr odom_target_publisher_ ;

  // 轨迹点切换相关变量
  size_t current_trajectory_index_{0};  // 当前轨迹点索引
  rclcpp::Time last_point_switch_time_;  // 上次切换点的时间
  double point_switch_interval_{1.0};  // 点切换的时间间隔(秒)
  int log_counter_{0};  // 用于控制日志打印频率
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<PathPublisher>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}