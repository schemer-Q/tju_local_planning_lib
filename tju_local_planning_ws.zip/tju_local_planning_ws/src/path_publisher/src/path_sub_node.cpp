#include <rclcpp/rclcpp.hpp>
#include <planning_msgs/msg/local_trajectory_points.hpp>
#include <planning_msgs/msg/trajectory_state.hpp>
#include <common_msgs/msg/pose_point.hpp>
#include <fstream>
#include <cmath>


class PathSub : public rclcpp::Node {
public:
  PathSub() : Node("path_sub"){
    // sub
    trajectory_sub_  = this->create_subscription<planning_msgs::msg::LocalTrajectoryPoints>("/planning/local_trajectory",rclcpp::SensorDataQoS(),std::bind(&PathSub::trajectory_callback, this, std::placeholders::_1));
    //auto state_sub = this->create_subscription<planning_msgs::msg::TrajectoryState>("/planning/trajectory_state",10,std::bind(&PathSub::state_callback, this, std::placeholders::_1));
    //file_.open("trajectory_points.txt");
    this->declare_parameter("output_file", "trajectory_points.txt");  // 默认值
    std::string output_file = this->get_parameter("output_file").as_string();
    file_.open(output_file);
  };

  ~PathSub() {
        if (file_.is_open()) file_.close();
    };

private:
  void trajectory_callback(const planning_msgs::msg::LocalTrajectoryPoints::SharedPtr msg)
  { 
    if (msg->trajectory.size() >= 15) {
      count_++;
      if (count_==10) {
        for (const auto& pt : msg->trajectory) {
            file_ << pt.x << " " << pt.y << " " << pt.yaw << std::endl;
      }
        file_ << std::endl; // 分隔每帧
        file_.flush();
      }
    };
    // // std::cout<<"callback"<<std::endl;
    // for (const auto& pt : msg->trajectory) {
    //         // std::cout<<"pt.x"<<pt.x;
    //         file_ << pt.x << " " << pt.y << " " << pt.yaw << std::endl;
    //     }
    //     file_ << std::endl; // 分隔每帧
    //     file_.flush();
    };
  //void state_callback(const planning_msgs::msg::TrajectoryState::SharedPtr msg) const {};
  rclcpp::Subscription<planning_msgs::msg::LocalTrajectoryPoints>::SharedPtr trajectory_sub_;
  std::ofstream file_;
  int count_ = 0;

};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<PathSub>());
  rclcpp::shutdown();
  return 0;
}