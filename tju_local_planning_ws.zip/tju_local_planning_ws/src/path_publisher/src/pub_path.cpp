#include <rclcpp/rclcpp.hpp>
#include <nav_msgs/msg/path.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <tf2/LinearMath/Quaternion.h>


// Include your custom message headers
#include <planning_msgs/msg/local_trajectory_points.hpp>
#include <common_msgs/msg/pose_point.hpp>

class TrajectoryToPathNode : public rclcpp::Node {
public:
    TrajectoryToPathNode() : Node("trajectory_to_path_node") {
        // Publisher for the Path message (for RViz)
        path_pub_ = this->create_publisher<nav_msgs::msg::Path>("/display_path", 10);
        
        // Subscription to the trajectory points
        traj_sub_ = this->create_subscription<planning_msgs::msg::LocalTrajectoryPoints>(
            "/planning/local_trajectory", 10,
            std::bind(&TrajectoryToPathNode::traj_callback, this, std::placeholders::_1)
        );
    }

private:
    void traj_callback(const planning_msgs::msg::LocalTrajectoryPoints::SharedPtr msg) {
        nav_msgs::msg::Path path_msg;
        path_msg.header = msg->header; // Preserve frame and timestamp
        path_msg.header.frame_id = "map"; // Set the frame to map (for RViz)
        for (const auto& pt : msg->trajectory) {
            geometry_msgs::msg::PoseStamped pose_stamped;
            pose_stamped.header = msg->header; // Consistent header for all poses

            // Set position
            pose_stamped.pose.position.x = pt.x;
            pose_stamped.pose.position.y = pt.y;
            pose_stamped.pose.position.z = pt.z;

            // 转换欧拉角为四元数 (俯仰角/滚转角/偏航角)
            tf2::Quaternion quaternion;
            quaternion.setRPY(pt.roll, pt.pitch, pt.yaw);
            
            // 四元数归一化（重要）
            quaternion.normalize();
            
            // 设置方向
            pose_stamped.pose.orientation.x = quaternion.x();
            pose_stamped.pose.orientation.y = quaternion.y();
            pose_stamped.pose.orientation.z = quaternion.z();
            pose_stamped.pose.orientation.w = quaternion.w();

            path_msg.poses.push_back(pose_stamped);
        }
        
        path_pub_->publish(path_msg); // Publish the converted path
    }

    rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr path_pub_;
    rclcpp::Subscription<planning_msgs::msg::LocalTrajectoryPoints>::SharedPtr traj_sub_;
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<TrajectoryToPathNode>());
    rclcpp::shutdown();
    return 0;
}