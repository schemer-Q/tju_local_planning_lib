#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/pose_with_covariance_stamped.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include <perception_task_msgs/msg/target_pose.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include "tf2/LinearMath/Quaternion.h"
#include "tf2/LinearMath/Matrix3x3.h"
#include <common_msgs/msg/pose_point.hpp>

class PoseRelayNode : public rclcpp::Node {
public:
    PoseRelayNode() : Node("pose_relay_node"),count_(0) {
        pub1_ = this->create_publisher<nav_msgs::msg::Odometry>("/location/fusion_location", 10);
        pub2_ = this->create_publisher<perception_task_msgs::msg::TargetPose>("/perception_task/align_target", 10);
        // 订阅 RViz 的 initialpose 话题
        sub_ = this->create_subscription<geometry_msgs::msg::PoseWithCovarianceStamped>(
            "/initialpose", 10,
            [this](const geometry_msgs::msg::PoseWithCovarianceStamped::SharedPtr msg) {
                // 发布到两个自定义话题
                // 当前时间戳
                auto current_time = now();
                if (count_ == 1) {
                    const auto& q = msg->pose.pose.orientation;
                    const auto& d = odom.pose.pose.orientation;
                    tf2::Quaternion quat(q.x, q.y, q.z, q.w);
                    tf2::Quaternion dquat(d.x, d.y, d.z, d.w);
                    double roll, pitch, yaw;
                    double droll, dpitch, dyaw;
                    tf2::Matrix3x3(quat).getRPY(roll, pitch, yaw);
                    tf2::Matrix3x3(dquat).getRPY(droll, dpitch, dyaw);
                    double dx = msg->pose.pose.position.x-odom.pose.pose.position.x;
                    double dy = msg->pose.pose.position.y-odom.pose.pose.position.y;
                    double x_car =  dx * cos(yaw) + dy * sin(yaw);
                    double y_car = -dx * sin(yaw) + dy * cos(yaw);
                    double yaw_body = yaw - dyaw;
                    goal.header.stamp = current_time;
                    goal.header.frame_id = "base_link";
                    goal.align_target.x = x_car;
                    goal.align_target.y = y_car;
                    while (yaw_body > M_PI) yaw_body -= 2 * M_PI;
                    while (yaw_body < -M_PI) yaw_body += 2 * M_PI;
                    goal.align_target.yaw = yaw_body;
                    count_++;
                    has_goal = true;
                }
                if (count_ == 0) {
                    odom.header = msg->header;
                    odom.pose = msg->pose;
                    odom.child_frame_id = "base_link";
                    odom.twist.twist.linear.x = 0.0;
                    odom.twist.twist.linear.y = 0.0;
                    odom.twist.twist.linear.z = 0.0;
                    odom.twist.twist.angular.x = 0.0;
                    odom.twist.twist.angular.y = 0.0;
                    odom.twist.twist.angular.z = 0.0;
                    count_++;
                    has_odom = true;
                }
            }
        );

        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(100), // 10Hz
            [this]() {
                if (has_odom && has_goal) {std::cout<<"pose pub"<<std::endl;pub1_->publish(odom);pub2_->publish(goal);}
            }
        );

    }
private:
    rclcpp::Subscription<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr sub_;
    rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr pub1_;
    rclcpp::Publisher<perception_task_msgs::msg::TargetPose>::SharedPtr pub2_;
    int count_ = 0;
    nav_msgs::msg::Odometry odom;
    perception_task_msgs::msg::TargetPose goal;
    bool has_odom = false, has_goal = false;
    rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<PoseRelayNode>());
    rclcpp::shutdown();
    return 0;
}