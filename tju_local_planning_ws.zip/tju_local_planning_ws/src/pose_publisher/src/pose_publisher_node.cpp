
#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/pose_with_covariance_stamped.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include <perception_task_msgs/msg/target_pose.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include "tf2/LinearMath/Quaternion.h"
#include "tf2/LinearMath/Matrix3x3.h"
#include <common_msgs/msg/pose_point.hpp>
#include "tf2_ros/transform_broadcaster.h"
#include "geometry_msgs/msg/transform_stamped.hpp"
#include <planning_msgs/msg/trajectory_points.hpp>

class PoseRelayNode : public rclcpp::Node {
public:
    PoseRelayNode() : Node("pose_relay_node"),count_(0) {
        pub1_ = create_publisher<nav_msgs::msg::Odometry>("/location/fusion_location", 10);
        pub2_ = create_publisher<perception_task_msgs::msg::TargetPose>("/perception_task/align_target", 10);
        pub3_ = create_publisher<planning_msgs::msg::TrajectoryPoints>("/planning/global_trajectory", 10);

        // 新增TF广播器
        tf_broadcaster_ = std::make_shared<tf2_ros::TransformBroadcaster>(this);

        sub_ = this->create_subscription<geometry_msgs::msg::PoseWithCovarianceStamped>(
            "/initialpose", 10,
            [this](const geometry_msgs::msg::PoseWithCovarianceStamped::SharedPtr msg) {
                auto current_time = now();
                // if (count_ == 1) {
                //     const auto& q = msg->pose.pose.orientation;
                //     const auto& d = odom.pose.pose.orientation;
                //     tf2::Quaternion quat(q.x, q.y, q.z, q.w);
                //     tf2::Quaternion dquat(d.x, d.y, d.z, d.w);
                //     double roll, pitch, yaw;
                //     double droll, dpitch, dyaw;
                //     tf2::Matrix3x3(quat).getRPY(roll, pitch, yaw);
                //     tf2::Matrix3x3(dquat).getRPY(droll, dpitch, dyaw);
                //     double dx = msg->pose.pose.position.x-odom.pose.pose.position.x;
                //     double dy = msg->pose.pose.position.y-odom.pose.pose.position.y;
                //     double x_car =  dx * cos(yaw) + dy * sin(yaw);
                //     double y_car = -dx * sin(yaw) + dy * cos(yaw);
                //     double yaw_body = yaw - dyaw;
                //     goal.header.stamp = current_time;
                //     goal.header.frame_id = "base_link";
                //     goal.align_target.x = x_car;
                //     goal.align_target.y = y_car;
                //     while (yaw_body > M_PI) yaw_body -= 2 * M_PI;
                //     while (yaw_body < -M_PI) yaw_body += 2 * M_PI;
                //     goal.align_target.yaw = yaw_body;
                //     count_++;
                //     has_goal = true;
                // }

                if (count_ == 1) {
                    const auto& q = msg->pose.pose.orientation;
                    tf2::Quaternion quat(q.x, q.y, q.z, q.w);
                    double roll, pitch, yaw;
                    tf2::Matrix3x3(quat).getRPY(roll, pitch, yaw);
                    goal.header.stamp = current_time;
                    goal.header.frame_id = "base_link";
                    goal.align_target.x = msg->pose.pose.position.x;
                    goal.align_target.y = msg->pose.pose.position.y;
                    double yaw_body = yaw;
                    while (yaw_body > M_PI) yaw_body -= 2 * M_PI;
                    while (yaw_body < -M_PI) yaw_body += 2 * M_PI;
                    goal.align_target.yaw = yaw_body;
                    count_++;
                    has_goal = true;
                }

                if (count_ == 0) {
                    odom.header = msg->header;
                    odom.pose = msg->pose;
                    odom.child_frame_id = "base_link";
                    odom.twist.twist.linear.x = 0.0;
                    odom.twist.twist.linear.y = 0.0;
                    odom.twist.twist.linear.z = 0.0;
                    odom.twist.twist.angular.x = 0.0;
                    odom.twist.twist.angular.y = 0.0;
                    odom.twist.twist.angular.z = 0.0;
                    count_++;
                    has_odom = true;
                }
                if (count_ == 2) {count_ = 0;}
            }
        );
        // 模拟全局路径
        global_path_.header.frame_id = "map";
        global_path_.points_cnt = 2;
        global_path_.trajectory.resize(2);
        global_path_.trajectory[0].x = 0.0;
        global_path_.trajectory[0].y = 0.0;
        global_path_.trajectory[0].z = 0.0;
        global_path_.trajectory[0].yaw = 1.0;
        global_path_.trajectory[1].x = 1.0;
        global_path_.trajectory[1].y = 1.0;
        global_path_.trajectory[1].z = 0.0;
        global_path_.trajectory[1].yaw = 0.0;

        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(100), // 10Hz
            [this]() {
                if (has_odom && has_goal) {
                    std::cout<<"pose pub"<<std::endl;
                    pub1_->publish(odom);
                    pub2_->publish(goal);
                    pub3_->publish(global_path_);
                    // 发布 odom->base_link 的TF
                    geometry_msgs::msg::TransformStamped t;
                    t.header.stamp = this->now();
                    t.header.frame_id = "odom";
                    t.child_frame_id = "base_link";
                    t.transform.translation.x = odom.pose.pose.position.x;
                    t.transform.translation.y = odom.pose.pose.position.y;
                    t.transform.translation.z = odom.pose.pose.position.z;
                    t.transform.rotation = odom.pose.pose.orientation;
                    tf_broadcaster_->sendTransform(t);
                }
            }
        );
    }
private:
    rclcpp::Subscription<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr sub_;
    rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr pub1_;
    rclcpp::Publisher<perception_task_msgs::msg::TargetPose>::SharedPtr pub2_;
    rclcpp::Publisher<planning_msgs::msg::TrajectoryPoints>::SharedPtr pub3_;
    nav_msgs::msg::Odometry odom;
    perception_task_msgs::msg::TargetPose goal;
    bool has_odom = false, has_goal = false;
    rclcpp::TimerBase::SharedPtr timer_;
    std::shared_ptr<tf2_ros::TransformBroadcaster> tf_broadcaster_; // 新增成员
    int count_;
    planning_msgs::msg::TrajectoryPoints global_path_;
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<PoseRelayNode>());
    rclcpp::shutdown();
    return 0;
}