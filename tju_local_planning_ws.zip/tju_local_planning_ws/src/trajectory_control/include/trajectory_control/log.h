#pragma once

#include "rclcpp/rclcpp.hpp"

#include "trajectory_control/t_log.hpp"

namespace trajectory_control {

inline bool InitLogger(std::shared_ptr<rclcpp::Node> node) {
  std::string project_base_dir, project_log_folder, log_path;
  project_base_dir = "/home/nvidia/tju_local_planning_ws";
  project_log_folder = "log";
  try {
    std::string key = "/project/base_dir";
    if(node->has_parameter(key)){
      project_base_dir = node->get_parameter(key).as_string();
    }
  } catch (const std::exception& e) {
    std::cout<<"[Per][Init] load /project/base_dir failed"<<std::endl;
    return false;
  }

  try {
    std::string key = "/project/log_folder";
    if(node->has_parameter(key)){
      project_log_folder = node->get_parameter("/project/log_folder").as_string();
    }
  } catch (const std::exception& e) {
    std::cout<<"[Per][Init] load /project/log_folder failed"<<std::endl;
    return false;
  }
  log_path = project_base_dir + "/" + project_log_folder + "/trajectory_control/trajectory_control.log";
  try {
    std::string key = "/project/base_dir";
    if(node->has_parameter(key)){
      log_path = node->get_parameter("/project/base_dir").as_string();
    }
  } catch (const std::exception& e) {
    std::cout<<"[Per][Init] load /project/base_dir failed"<<std::endl;
    return false;
  }
  // log_path = "/home/jkroly/Jkroly/Code/Truck/NewTruckSoftWare/NewCottonDetect/log/local_planning/local_planning.log";
  // std::string project_base_dir = "/home/txs/workspace/suntae/suntae_global_planning";
  // std::string project_log_folder = "install/global_planning/log";
  // log_path = project_base_dir + "/" + project_log_folder + "/global_planning/global_planning.log";
  LOGINIT(log_path.c_str(), jian::logging::level_enum::trace, 20, "trajectory_control");
  std::string common_log_path = "/home/nvidia/tju_local_planning_ws/common_log/common.log";
  LOGINIT(common_log_path.c_str(), jian::logging::level_enum::info, 20, "common");
  // RCLCPP_INFO("[Per][Init] Log initialized at: %s", log_path.c_str());
  NTINFO << "[Init] Log initialized: log path " << log_path;
  NTINFO << "[Init] Log initialized: log path " << common_log_path;
  return true;
}

}  // namespace local_planning
