#pragma once

#include <cstddef>
#include <string>
#include <iostream>
#include <any>
#include <cmath>
#include "trajectory_control/log.h"
#include "rclcpp/rclcpp.hpp"

// 入参ros消息定义
#include "planning_msgs/msg/local_trajectory_points.hpp"
#include <nav_msgs/msg/odometry.hpp>
#include "chassis_msgs/msg/car_ori_interface.hpp"
#include "sensing_msgs/msg/imu_data.hpp"

// 出参ros消息定义
#include "control_msgs/msg/cross_goal.hpp"
#include "control_msgs/msg/pathspeedctrl_interface.hpp"

// 包含已安装库中的结构体定义
#include "tju_trajectory_control/common/types/trajectory_control_types.h"


// using namespace trajectory_control;

namespace trajectory_control {

// 四元数结构
struct Quaternion {
    double x;
    double y;
    double z;
    double w;
};

// 欧拉角结构
struct EulerAngle {
    double roll;  
    double pitch; 
    double yaw;   
};

// 将四元数转换为欧拉角
EulerAngle quaternionToEuler(const Quaternion& q) {
    EulerAngle ea;

    // 计算 Roll 角度
    ea.roll = std::atan2(2 * (q.w * q.x + q.y * q.z), 1 - 2 * (q.x * q.x + q.y * q.y));

    // 计算 Pitch 角度
    double sinPitch = 2 * (q.w * q.y - q.z * q.x);
    if (std::abs(sinPitch) >= 1) {
        ea.pitch = std::copysign(M_PI / 2, sinPitch); // 纠正 Pitch 角度在 90 度或 -90 度的情况
    } else {
        ea.pitch = std::asin(sinPitch);
    }

    // 计算 Yaw 角度
    ea.yaw = std::atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z));

    return ea;
}

trajectory_control::LocalTrajectory CovertMsgToParam1(const planning_msgs::msg::LocalTrajectoryPoints::ConstSharedPtr data){
    if(!data){
      NTWARNING<<"[RUN] 局部路径为空";
      // printf("局部路径为空");
      return trajectory_control::LocalTrajectory{};
    }
  
    // 创建库中定义的轨迹点结构体
    trajectory_control::LocalTrajectory result;
    
    // 复制时间戳和坐标系信息
    result.header.frame_id = data->header.frame_id;
    result.task_type = data->task_type;
    result.points_cnt = data->points_cnt;
    result.points_cnt = data->points_cnt;
    result.replan_counter = data->replan_counter;
    result.plan_state = data->plan_state;

    // 复制轨迹点数据
    if (!data->trajectory.empty()) {
      result.trajectory.resize(data->trajectory.size());
      for (size_t i = 0; i < data->trajectory.size(); ++i) {
        auto& point = result.trajectory[i];
        // 基于PosePoint定义进行赋值
        point.x = data->trajectory[i].x;
        point.y = data->trajectory[i].y;
        point.z = data->trajectory[i].z;
        point.pitch = data->trajectory[i].pitch;
        point.roll = data->trajectory[i].roll;
        point.yaw = data->trajectory[i].yaw;
        point.speed = data->trajectory[i].speed;
        point.curve = data->trajectory[i].curve;
        point.acc = data->trajectory[i].acc;
        point.gear = data->trajectory[i].gear;
      }
    }
    
    return result;
  }

  trajectory_control::Odommetry CovertMsgToParam2(const nav_msgs::msg::Odometry::ConstSharedPtr data){
    if(!data){
      NTWARNING<<"[RUN] 定位数据为空";
      // printf("定位数据为空");
      return trajectory_control::Odommetry{};
    }

    // 创建库中定义的里程计结构体
    trajectory_control::Odommetry result;
    
    // 直接填充位置信息
    result.x = data->pose.pose.position.x;
    result.y = data->pose.pose.position.y;
    result.z = data->pose.pose.position.z;
    
    // 填充姿态信息（四元数转欧拉角）
    // Quaternion qua = (data->pose.pose.orientation.x,data->pose.pose.orientation.y,data->pose.pose.orientation.z,data->pose.pose.orientation.w);
    trajectory_control::Quaternion qua{
    data->pose.pose.orientation.x,
    data->pose.pose.orientation.y,
    data->pose.pose.orientation.z,
    data->pose.pose.orientation.w
    };
    auto ea = trajectory_control::quaternionToEuler(qua);

    result.roll = ea.roll;
    result.pitch = ea.pitch;
    result.yaw = ea.yaw;
    
    // 直接填充线速度信息
    result.vx = data->twist.twist.linear.x;
    result.vy = data->twist.twist.linear.y;
    result.vz = data->twist.twist.linear.z;
    
    // 直接填充角速度信息
    result.wx = data->twist.twist.angular.x;
    result.wy = data->twist.twist.angular.y;
    result.wz = data->twist.twist.angular.z;

    
    return result;
  }

  trajectory_control::ChassisData CovertMsgToParam3(const chassis_msgs::msg::CarOriInterface::ConstSharedPtr data){
    if(!data){
      NTWARNING<<"[RUN] 底盘反馈为空";
      // printf("底盘反馈为空");
      return trajectory_control::ChassisData{};
    }

    // 创建库中定义的车辆接口结构体
    trajectory_control::ChassisData result;
    
    // 根据readme.txt中的定义填充字段
    result.header.frame_id = data->header.frame_id;
    result.angle = data->angle;
    result.acc = data->acc;
    result.open_gas = data->open_gas;
    result.drive_mode = data->drive_mode;
    result.e_stop_trigger = data->e_stop_trigger;
    result.gear = data->gear;
    result.car_speed = data->car_speed;
    result.motor_torque = data->motor_torque;
    result.yk_f = data->yk_f;
    result.yk_h = data->yk_h;
    result.fault1 = data->fault1;
    result.fault2 = data->fault2;
    result.fault3 = data->fault3;
    result.fault4 = data->fault4;
    result.mileage = data->mileage;
    result.brake_pressure = data->brake_pressure;
    result.lr_wheelspeed = data->lr_wheelspeed;
    result.rr_wheelspeed = data->rr_wheelspeed;
    result.soc = data->soc;
    result.carsts1 = data->carsts1;
    result.carsts2 = data->carsts2;
    result.lx_hight = data->lx_hight;
    result.pitching = data->pitching;
    result.carstartstate = data->carstartstate;
    result.vcu_service_voltage = data->vcu_service_voltage;
    result.vcu_sts = data->vcu_sts;
    result.fault = data->fault;
    result.flag_end_wire = data->flag_end_wire;
    result.msg_from_wire_to_plan = data->msg_from_wire_to_plan;
    
    return result;
  }


  trajectory_control::IMUData CovertMsgToParam4(const sensing_msgs::msg::ImuData::ConstSharedPtr data){
    if(!data){
      NTWARNING<<"[RUN] IMU数据为空";
      // printf("IMU数据为空");
      return trajectory_control::IMUData{};
    }

    // 创建库中定义的路口目标结构体
    trajectory_control::IMUData result;
    
    // 填充坐标系信息
    result.header.frame_id = data->header.frame_id;
    
    // 填充data
    result.angular_velocity.x = data->angular_velocity.x;
    result.angular_velocity.y = data->angular_velocity.y;
    result.angular_velocity.z = data->angular_velocity.z;
    result.linear_acceleration.x = data->linear_acceleration.x;
    result.linear_acceleration.y = data->linear_acceleration.x;
    result.linear_acceleration.z = data->linear_acceleration.x;
    result.angular_velocity_corrected.x = data->angular_velocity_corrected.x;
    result.angular_velocity_corrected.y = data->angular_velocity_corrected.y;
    result.angular_velocity_corrected.z = data->angular_velocity_corrected.z;
    result.linear_acceleration_corrected.x = data->linear_acceleration_corrected.x;
    result.linear_acceleration_corrected.y = data->linear_acceleration_corrected.y;
    result.linear_acceleration_corrected.z = data->linear_acceleration_corrected.z;
    result.orientation.x = data->orientation.x;
    result.orientation.y = data->orientation.y;
    result.orientation.z = data->orientation.z;
    result.orientation.w = data->orientation.w;

    return result;
  }

  control_msgs::msg::PathspeedctrlInterface ConvertToPathspeedctrlInterface(const std::any& data) {
    control_msgs::msg::PathspeedctrlInterface result;
    try {
      // 尝试将 std::any 中的对象转换为库中定义的结构体
      // 注意使用正确的命名空间路径
      const trajectory_control::TrackCtrlSignal& ctrl_signal = 
          std::any_cast<const trajectory_control::TrackCtrlSignal&>(data);
      

      result.timestamp = rclcpp::Clock().now().seconds();
      result.target_velocity = ctrl_signal.target_velocity;
      result.target_steering_angle = ctrl_signal.target_steering_angle;
      result.target_gear = ctrl_signal.target_gear;
      
    } catch (const std::bad_any_cast& e) {
      RCLCPP_ERROR(rclcpp::get_logger("trajectory_control"), 
                  "Failed to cast std::any to TrackCtrlSignal: %s", e.what());
    }
    return result;
  }

  // ！！！注意：控制算法输出与框架期望输出不符，CrossGoal结构体内容的填充逻辑需要后续补充
  control_msgs::msg::CrossGoal ConvertToCrossGoal(const std::any& data) {
    control_msgs::msg::CrossGoal result;
    try {
      // 由于输出不匹配，此处填充空内容以保证程序运行
      // trajectory_control::PosePoint point = {};

      const trajectory_control::TrackCrossGoal& track_cross_goal = 
          std::any_cast<const trajectory_control::TrackCrossGoal&>(data);
      

      result.header.stamp = rclcpp::Clock().now();
      result.work_state = track_cross_goal.work_state;
      result.tra_track_state = track_cross_goal.tra_track_state;

      result.target_point.x = track_cross_goal.target_point.x;
      result.target_point.y = track_cross_goal.target_point.y;
      result.target_point.speed = track_cross_goal.target_point.speed;
      result.target_point.yaw = track_cross_goal.target_point.yaw;


      
    } catch (const std::bad_any_cast& e) {
      RCLCPP_ERROR(rclcpp::get_logger("trajectory_control"), 
                  "Failed to cast std::any to TrackCtrlPerform: %s", e.what());
    }
    return result;
  }

}  // namespace trajectory_control
