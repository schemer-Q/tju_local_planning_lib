#include <yaml-cpp/yaml.h>
#include <csignal>
#include <rclcpp/rclcpp.hpp>
#include <unistd.h>
#include <ament_index_cpp/get_package_prefix.hpp>

#include "trajectory_control/log.h"
#include "trajectory_control/utils.h"

#include "common/util/diagnosis.h"
#include "common/data_manager/data_manager.hpp"
#include "common/subscriber/subscribe.hpp"
#include "common/publisher/publish.hpp"

// #include "tju_local_planning/app/local_planning_QuinticPolynomialPlanner/forklift_local_planner_base.h"
#include "tju_trajectory_control/trajectory_control.h"
#include "tju_trajectory_control/delayMPC.h"
#include "tju_trajectory_control/controller_manager.h"

using namespace trajectory_control;

std::atomic<bool> Running{true};

void signalHandler(int signum) {
  switch (signum) {
    case SIGINT:
      NTWARNING << "SIGINT signal received.";
      ;
      break;
    case SIGTERM:
      NTWARNING << "SIGTERM signal received.";
      break;
    case SIGABRT:
      NTWARNING << "SIGABRT signal received.";
      break;
    case SIGFPE:
      NTWARNING << "SIGFPE signal received.";
      break;
    case SIGSEGV:
      NTWARNING << "SIGSEGV signal received.";
      break;
    default:
      NTWARNING << "Unknown signal received: " << signum;
      break;
  }
  Running.store(false);
}

bool CheckConfig(const YAML::Node &config) {
  if (!config["Subscriber"].IsDefined()) {
    NTWARNING << "[Init][CheckConfig] Subscriber is missing";
    return false;
  }

  if (!config["Publisher"].IsDefined()) {
    NTWARNING << "[Init][CheckConfig] Subscriber is missing";
    return false;
  }

  if (!config["TaskTriggerMode"].IsDefined()) {
    NTWARNING << "[Init][CheckConfig] TaskTriggerMode is missing";
    return false;
  }
  return true;
}

int main(int argc, char *argv[]) {
  rclcpp::init(argc, argv);
  rclcpp::NodeOptions options;
  options.allow_undeclared_parameters(false);
  options.automatically_declare_parameters_from_overrides(false);
  auto node = std::make_shared<rclcpp::Node>("trajectory_control_node", options);
  auto &repoter = tju::common::Singleton<tju::common::DiagnosisReporter>::GetInstance();
  tju::diagnosis::start("trajectory_control_node");
  signal(SIGINT, signalHandler);  // 必须放在ros::init后面，否则signal捕捉会被ros::init覆盖
  if (!InitLogger(node)) {
    tju::diagnosis::report(tju::common::ErrorCode::TRAJECTORY_TRACKING_LAUNCH_PARAM_GET_FAILED);
    return -1;
  } else {
    tju::diagnosis::restore(tju::common::ErrorCode::TRAJECTORY_TRACKING_LAUNCH_PARAM_GET_FAILED);
  }
  //std::cout<<"----------------------------1---------------------------------"<<std::endl;
  std::string config_file = "/home/nvidia/tju_local_planning_ws/src/trajectory_control/config/data.yaml";
  //std::string config_file = "/home/endiyin/3/tju_trajectory_control_ws/src/trajectory_control/config/data.yaml";
  node->declare_parameter<std::string>("config_file", config_file);
  if (node->has_parameter("config_file")) {
    config_file = node->get_parameter("config_file").as_string();
    tju::diagnosis::restore(tju::common::ErrorCode::TRAJECTORY_TRACKING_LAUNCH_PARAM_GET_FAILED);
  } else {
    tju::diagnosis::report(tju::common::ErrorCode::TRAJECTORY_TRACKING_LAUNCH_PARAM_GET_FAILED);
    NTFATAL << "[Init] Failed to get param 'config_file'";
    return -1;
  }
    //std::cout<<"----------------------------2---------------------------------"<<std::endl;
  auto config = YAML::LoadFile(config_file);
  if (!CheckConfig(config)) {
    tju::diagnosis::report(tju::common::ErrorCode::TRAJECTORY_TRACKING_LAUNCH_CONFIG_LOAD_FAILED);
    return -1;
  } else {
    tju::diagnosis::restore(tju::common::ErrorCode::TRAJECTORY_TRACKING_LAUNCH_CONFIG_LOAD_FAILED);
  }
    //std::cout<<"----------------------------3---------------------------------"<<std::endl;
  // Init data manager
  std::string sensors_cfile = "/" + config["SensorsConfig"].as<std::string>();
  std::string package_prefix = ament_index_cpp::get_package_prefix("common");
  sensors_cfile = package_prefix + sensors_cfile;
  NTINFO << "[Init] common package path : " << package_prefix;
  NTINFO << "[Init] SensorsConfig: " << sensors_cfile;
  REGISTER_SENSORS_BY_FILE(sensors_cfile);
  SET_NODE_NAME(node->get_name());
  SET_VEHICLE_NAME(config["vel"].as<std::string>());
    //std::cout<<"----------------------------4---------------------------------"<<std::endl;
  // Load trigger mode
  auto trigger_mode = config["TaskTriggerMode"].as<std::string>();
  if (trigger_mode != "Topic" && trigger_mode != "Time") {
    tju::diagnosis::report(tju::common::ErrorCode::TRAJECTORY_TRACKING_LAUNCH_CONFIG_FILE_PARAM_ERROR);
    NTFATAL << "[Run] Invalid TaskTriggerMode: " << trigger_mode;
    return -1;
  } else {
    tju::diagnosis::restore(tju::common::ErrorCode::TRAJECTORY_TRACKING_LAUNCH_CONFIG_FILE_PARAM_ERROR);
  }
      //std::cout<<"----------------------------5---------------------------------"<<std::endl;
  std::string trigger_sensor = "";
  if (trigger_mode == "Topic") {
    if (config["TriggertTopic"].IsDefined()) {
      trigger_sensor = config["TriggertTopic"].as<std::string>();
      tju::diagnosis::restore(tju::common::ErrorCode::TRAJECTORY_TRACKING_LAUNCH_CONFIG_FILE_PARAM_ERROR);
    } else {
      tju::diagnosis::report(tju::common::ErrorCode::TRAJECTORY_TRACKING_LAUNCH_CONFIG_FILE_PARAM_ERROR);
      NTFATAL << "[Run] TriggerSensor is missing";
      return -1;
    }
  }
//std::cout<<"----------------------------6---------------------------------"<<std::endl;
  // Start subscribe data
  NTINFO << "[Init] Start to subscribe data.";
  std::unique_ptr<tju::common::Subscriber> subscriber = std::make_unique<tju::common::Subscriber>(node);
  if (!subscriber->Start(config["Subscriber"], trigger_sensor)) {
    tju::diagnosis::report(tju::common::ErrorCode::TRAJECTORY_TRACKING_LAUNCH_CONFIG_LOAD_FAILED);
    return -1;
  } else {
    tju::diagnosis::restore(tju::common::ErrorCode::TRAJECTORY_TRACKING_LAUNCH_CONFIG_LOAD_FAILED);
  }
//std::cout<<"----------------------------7---------------------------------"<<std::endl;
  // Start publishe data
  NTINFO << "[Init] Start to publishe data.";
  std::unique_ptr<tju::common::Publisher> publisher = std::make_unique<tju::common::Publisher>(node);
  if (publisher->registerByYaml(config["Publisher"])) {
    tju::diagnosis::report(tju::common::ErrorCode::TRAJECTORY_TRACKING_LAUNCH_CONFIG_LOAD_FAILED);
    return -1;
  } else {
    tju::diagnosis::restore(tju::common::ErrorCode::TRAJECTORY_TRACKING_LAUNCH_CONFIG_LOAD_FAILED);
  }

  // Start Init algo trajectory_control::TrajectoryController
  NTINFO << "[Init] Start to init algo.";
  // std::unique_ptr<trajectory_control::TrajectoryController> trajectory_control = std::make_unique<trajectory_control::TrajectoryController>();
  std::unique_ptr<trajectory_control::Controller_Manager> trajectory_control_ptr = std::make_unique<trajectory_control::Controller_Manager>(0);
  std::string algo_config_file;
  if(!config["AlgoConfig"].IsDefined()) {
    tju::diagnosis::report(tju::common::ErrorCode::TRAJECTORY_TRACKING_LAUNCH_CONFIG_FILE_PARAM_ERROR);
    NTFATAL << "[Init] AlgoConfig is missing!";
    return -1;
  }
  else {
    tju::diagnosis::restore(tju::common::ErrorCode::TRAJECTORY_TRACKING_LAUNCH_CONFIG_FILE_PARAM_ERROR);
    algo_config_file = config["AlgoConfig"].as<std::string>();
  }

  NTINFO << "AlgoConfig: " << algo_config_file;
  auto algo_config = YAML::LoadFile(algo_config_file);
  NTINFO << "Full config structure: " << algo_config;  // 先打印整个配置结构
  NTINFO << "AlgoConfig MaxAccel: " << algo_config["Config"]["MaxAccel"];  // 正确访问
  trajectory_control_ptr->Init(algo_config);
  NTINFO << "Successfully loaded algorithm config file";

  int async_threads = 3;
  if (config["ROS"]["AsyncThread"].IsDefined()) {
    async_threads = config["ROS"]["AsyncThread"].as<int>();
  }
  rclcpp::executors::MultiThreadedExecutor executor(rclcpp::ExecutorOptions(), async_threads);
  executor.add_node(node);
  executor.add_node(repoter.get_node_base_interface());
  // trigger all tasks

  trajectory_control::LocalTrajectory LocalTrajectory ;
  trajectory_control::Odommetry  FusionLocation ;
  trajectory_control::ChassisData CarOrientation ;
  trajectory_control::IMUData Imu ;
  sleep(1);
  // 启动执行器线程
  std::thread executor_thread([&executor]() { executor.spin(); });
  auto run_lambda = [&node, &publisher, &trajectory_control_ptr, &LocalTrajectory, &FusionLocation, &CarOrientation, &Imu]() {
    double msg_t = rclcpp::Clock().now().seconds();
    std::shared_ptr<LocalPathData> local_path_data = std::make_shared<LocalPathData>();
    if(tju::common::ErrorCode::OK == EXTRACT_GENERIC_BY_TIME(LocalPathData, "LOCALPATH", msg_t, local_path_data)){
      NTINFO << "Extract LOCALPATH successfully, msg time: " <<  local_path_data->time << "; system time: " << msg_t;
      LocalTrajectory = trajectory_control::CovertMsgToParam1(local_path_data->data);
    }

    std::shared_ptr<OdometryData> fusion_odom_data = std::make_shared<OdometryData>();
    if(tju::common::ErrorCode::OK == EXTRACT_GENERIC_BY_TIME(OdometryData, "FUSIONLOCATION", msg_t, fusion_odom_data)){
      NTINFO << "Extract FUSIONLOCATION successfully, msg time: " <<  fusion_odom_data->time << "; system time: " << msg_t;
      FusionLocation = trajectory_control::CovertMsgToParam2(fusion_odom_data->data);
    }

    std::shared_ptr<CarOriData> car_ori_data = std::make_shared<CarOriData>();
    if(tju::common::ErrorCode::OK == EXTRACT_GENERIC_BY_TIME(CarOriData, "CARORI", msg_t, car_ori_data)){
      NTINFO << "Extract CARORI successfully, msg time: " <<  car_ori_data->time << "; system time: " << msg_t;
      CarOrientation = trajectory_control::CovertMsgToParam3(car_ori_data->data);
    }

    std::shared_ptr<ImuData> imu_data = std::make_shared<ImuData>();
    if(tju::common::ErrorCode::OK == EXTRACT_GENERIC_BY_TIME(ImuData, "IMU", msg_t, imu_data)){
      NTINFO << "Extract IMU successfully, msg time: " <<  imu_data->time << "; system time: " << msg_t;
      Imu = trajectory_control::CovertMsgToParam4(imu_data->data);
    }

    // 将ROS消息转换为算法内部数据结构
    // trajectory_control::LocalTrajectory LocalTrajectory = trajectory_control::CovertMsgToParam1(local_path_data->data);
    // trajectory_control::Odommetry  FusionLocation = trajectory_control::CovertMsgToParam2(fusion_odom_data->data);
    // trajectory_control::ChassisData CarOrientation = trajectory_control::CovertMsgToParam3(car_ori_data->data);
    // trajectory_control::IMUData Imu = trajectory_control::CovertMsgToParam4(imu_data->data);


    NTINFO <<"[Run] Converting ROS messages to algorithm data structures completed.";
    // 使用转换后的数据调用本地算法
    uint32_t result = trajectory_control_ptr->Run(
        LocalTrajectory,
        FusionLocation,
        CarOrientation,
        Imu
    );
    // if (result != tju::local_planning::common::ErrorCode::SUCCESS) {
    //   NTWARNING << "[Run] Run() method returned error code: " << result;}
    
    // 获取本地规划结果
    auto track_control = std::any_cast<trajectory_control::TrackCtrlSignal>(trajectory_control_ptr->GetData("track_control"));
    // auto track_perform = std::any_cast<trajectory_control::TrackCtrlPerform>(trajectory_control->GetData("track_perform"));
    auto track_cross_goal = std::any_cast<trajectory_control::TrackCrossGoal>(trajectory_control_ptr->GetData("track_cross_goal"));
    // if (local_trajectory.trajectory.empty()) {
    //   NTERROR << "Local trajectory is empty!";
    //   return;
    // }
    // 将算法结果转换回ROS消息并发布
    auto message_PathspeedctrlInterface = trajectory_control::ConvertToPathspeedctrlInterface(track_control);
    message_PathspeedctrlInterface.timestamp = node->get_clock()->now().seconds();

    if(tju::common::ErrorCode::OK != publisher->publish<control_msgs::msg::PathspeedctrlInterface>("CONTROL", message_PathspeedctrlInterface)){
      NTFATAL << "Publishe CONTROL msg failed! Msg type is: " << "control_msgs::msg::PathspeedctrlInterface";
    }

    auto message_CrossGoal = trajectory_control::ConvertToCrossGoal(track_cross_goal);
    message_CrossGoal.header.stamp = node->get_clock()->now();
    if(tju::common::ErrorCode::OK != publisher->publish<control_msgs::msg::CrossGoal>("CROSSGOAL", message_CrossGoal)){
      NTFATAL << "Publishe CROSSGOAL msg failed! Msg type is: " << "control_msgs::msg::CrossGoal";
    }
  };
  if (trigger_mode == "Topic") {
    std::chrono::steady_clock::time_point consumed_trigger_time;  // 防止计算时间太短，导致重复触发
    while (rclcpp::ok() && Running.load()) {
      auto now = std::chrono::steady_clock::now();
      bool triggered = false;
      {
        std::unique_lock<std::mutex> lk(tju::common::lock);
        triggered = tju::common::cv.wait_for(lk, std::chrono::seconds(1), [&] {
          auto diff = std::chrono::duration_cast<std::chrono::milliseconds>(now - tju::common::last_trigger_time).count();
          return !(Running.load()) || (tju::common::ready && diff <= 50 && tju::common::last_trigger_time != consumed_trigger_time);
        });
      }
      if (!Running.load()) break;
      if (triggered) {
        NTINFO << "[Run] Trigger mode !";
        consumed_trigger_time = tju::common::last_trigger_time;
        run_lambda();
      }
    }
  } else {
    rclcpp::Rate rate(10);
    while (rclcpp::ok()) {
      run_lambda();
      rate.sleep();
    }
  }

  executor.cancel();
  if (executor_thread.joinable()) {
    executor_thread.join();
  }
  rclcpp::shutdown();
  return 0;
}
